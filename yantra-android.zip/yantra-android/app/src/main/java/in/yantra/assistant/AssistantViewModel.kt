package `in`.yantra.assistant

import `in`.yantra.assistant.actions.ClockApp
import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import `in`.yantra.assistant.actions.ActionExecutor
import `in`.yantra.assistant.brain.Brain
import `in`.yantra.assistant.actions.Answers
import `in`.yantra.assistant.brain.Thought
import `in`.yantra.assistant.mind.LocalModel
import `in`.yantra.assistant.mind.Memory
import `in`.yantra.assistant.mind.Mind
import `in`.yantra.assistant.mind.Plan
import `in`.yantra.assistant.mind.Prompts
import `in`.yantra.assistant.mind.Reasoner
import `in`.yantra.assistant.mind.Risk
import `in`.yantra.assistant.mind.TextModel
import `in`.yantra.assistant.mind.Turn
import `in`.yantra.assistant.router.Ctx
import `in`.yantra.assistant.router.Parsed
import `in`.yantra.assistant.router.Router
import `in`.yantra.assistant.speech.Speaker
import `in`.yantra.assistant.speech.VoiceChoice
import `in`.yantra.assistant.ui.ClockKind
import `in`.yantra.assistant.ui.ClockPick
import `in`.yantra.assistant.util.AppSettings
import `in`.yantra.assistant.util.Prefs
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatMsg(
    val fromUser: Boolean,
    val text: String,
    val stamp: Long = System.nanoTime(),
    /** Set on looked-up answers: where they came from, and the page to read more. */
    val source: String = "",
    val link: String = ""
)

class AssistantViewModel(app: Application) : AndroidViewModel(app) {

    private val executor = ActionExecutor(app)
    private val prefs = Prefs(app)
    private val settings = AppSettings(prefs)
    private val brain = Brain()
    val speaker = Speaker(app)
    private val localModel = LocalModel(app, prefs)
    private val memory = Memory()

    val messages = mutableStateListOf(
        ChatMsg(
            false,
            "Yantra here. A small brain that lives on your phone, no cloud — say \"help\" for the full list."
        )
    )

    // ------------------------------------------------ what Settings shows

    var language by mutableStateOf(settings.language)
        private set
    var themeMode by mutableStateOf(settings.theme)
        private set
    var speakReplies by mutableStateOf(settings.speakReplies)
        private set
    var smartReplies by mutableStateOf(settings.smartReplies)
        private set
    var lookupAnswers by mutableStateOf(settings.lookupAnswers)
        private set
    var speechRate by mutableStateOf(speaker.rate)
        private set
    var speechPitch by mutableStateOf(speaker.pitch)
        private set
    var voiceChoices by mutableStateOf<List<VoiceChoice>>(emptyList())
        private set
    var selectedVoice by mutableStateOf("")
        private set
    var languageHasVoices by mutableStateOf(true)
        private set
    var shortcutCount by mutableStateOf(0)
        private set
    var displayName by mutableStateOf(prefs.name())
        private set

    // the thinking layer: an optional on-device language model, and what you asked Yantra to remember
    var useModel by mutableStateOf(settings.useModel)
        private set
    var modelStatus by mutableStateOf("")
        private set
    var modelBusy by mutableStateOf(false)
        private set
    var modelInstalled by mutableStateOf(false)
        private set
    var memoryCount by mutableStateOf(0)
        private set
    /** What Yantra remembers, one readable line each, for the Settings list. */
    var memoryLines by mutableStateOf<List<String>>(emptyList())
        private set

    // Valley, the browser Yantra hands searches and links to
    var preferValley by mutableStateOf(settings.preferValley)
        private set
    var valleyInstalled by mutableStateOf(false)
        private set

    var listening by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var timerLeft by mutableStateOf("")
        private set

    /** Set while the timer or alarm picker is on screen. */
    var clockSheet by mutableStateOf<ClockKind?>(null)
        private set
    /** The Clock app the picker saves to, shown in the picker. */
    var clockAppName by mutableStateOf("Clock")
        private set
    var lastSpoken by mutableStateOf("")
        private set

    /** Live words from the recogniser while the mic is open. */
    var transcript by mutableStateOf("")
        private set

    /** A short, non-conversational message: "I heard nothing", "mic permission missing". */
    var notice by mutableStateOf("")

    /**
     * Goes up each time Yantra asks a yes or no question and wants the mic opened for a short
     * answer. The wake-up screen waits for the question to be spoken, then listens for a few seconds.
     */
    var followUp by mutableIntStateOf(0)
        private set

    /** The command a waiting "do you want me to ...?" will run on yes. */
    private var offered: String? = null
        private set

    private var lastUser: String? = null
    private var lastBot: String? = null
    private var lastTarget: String? = null

    // timer state
    private var timerJob: Job? = null
    private var timerEndsAt = 0L
    private var timerRemaining = 0L
    private var timerPaused = false
    private var timerLabel = ""
    /** When Android's alarm for Yantra's own timer is due, or 0 when none is set. */
    private var timerAlarmAt = 0L

    init {
        brain.loadTaught(prefs.list("taught"))
        shortcutCount = brain.taughtCount()
        brain.onTaughtChanged = {
            prefs.saveList("taught", brain.taughtItems())
            shortcutCount = brain.taughtCount()
        }
        memory.load(prefs.list("memory"))
        memoryCount = memory.count()
        memoryLines = memory.lines()
        memory.onChanged = {
            prefs.saveList("memory", memory.items())
            memoryCount = memory.count()
            memoryLines = memory.lines()
        }
        // "my name is Vidya" also changes what Yantra calls you
        memory.onName = { saveName(it) }
        valleyInstalled = executor.valleyInstalled()
        modelStatus = describeModel()
        if (useModel) loadModel()
        // voices are only known once the engine has started
        speaker.init { refreshVoices() }
    }

    // ------------------------------------------------- the language model

    private fun describeModel(): String {
        modelInstalled = localModel.installedFile() != null
        return describe()
    }

    private fun describe(): String = when {
        localModel.installedFile() == null ->
            "No model installed. Yantra works without one; a model adds free-form understanding and real answers."
        localModel.ready -> localModel.installedLabel() + " is loaded and ready."
        localModel.lastError.isNotEmpty() -> "Could not load " + localModel.installedLabel() + ": " + localModel.lastError
        else -> localModel.installedLabel() + " is installed."
    }

    private fun loadModel() {
        if (localModel.installedFile() == null || modelBusy) {
            modelStatus = describeModel()
            return
        }
        viewModelScope.launch {
            modelBusy = true
            modelStatus = "Loading " + localModel.installedLabel() + "\u2026"
            localModel.load()
            modelStatus = describeModel()
            modelBusy = false
        }
    }

    fun toggleModel(on: Boolean) {
        settings.useModel = on
        useModel = on
        if (on) loadModel() else viewModelScope.launch {
            localModel.unload()
            modelStatus = describeModel()
        }
    }

    /** The person picked a model file in Settings. */
    fun importModel(uri: Uri) {
        if (modelBusy) return
        viewModelScope.launch {
            modelBusy = true
            modelStatus = "Copying the model\u2026 0%"
            val error = localModel.import(uri) { pct -> modelStatus = "Copying the model\u2026 $pct%" }
            if (error.isNotEmpty()) {
                modelStatus = error
                modelBusy = false
                return@launch
            }
            modelStatus = "Loading " + localModel.installedLabel() + "\u2026"
            localModel.load()
            if (localModel.ready) {
                settings.useModel = true
                useModel = true
            }
            modelStatus = describeModel()
            modelBusy = false
        }
    }

    fun removeModel() {
        if (modelBusy) return
        viewModelScope.launch {
            modelBusy = true
            localModel.remove()
            modelStatus = describeModel()
            modelBusy = false
        }
    }

    fun forgetMemory() {
        memory.clear()
    }

    /** Removes one line of the memory list in Settings. */
    fun forgetMemoryAt(index: Int) {
        memory.removeAt(index)
    }

    fun togglePreferValley(on: Boolean) {
        settings.preferValley = on
        preferValley = on
    }

    private fun activeModel(): TextModel? = if (useModel && localModel.ready) localModel else null

    // ------------------------------------------------------------ settings
    // Named chooseX/changeX/toggleX rather than setX: the properties above
    // already claim the setX JVM signatures.

    fun refreshVoices() {
        voiceChoices = speaker.voiceChoices()
        selectedVoice = speaker.currentVoiceName() ?: ""
        languageHasVoices = speaker.hasVoicesForLanguage()
        speechRate = speaker.rate
        speechPitch = speaker.pitch
        shortcutCount = brain.taughtCount()
        displayName = prefs.name()
        valleyInstalled = executor.valleyInstalled()
    }

    fun chooseLanguage(tag: String) {
        val ok = speaker.setLanguage(tag)
        settings.language = speaker.languageTag
        language = speaker.languageTag
        refreshVoices()
        if (ok) speaker.preview("Hello, this is how I sound now.")
    }

    fun chooseVoice(name: String) {
        if (speaker.chooseVoice(name)) selectedVoice = name
    }

    fun changeRate(value: Float) {
        speaker.rate = value
        speechRate = speaker.rate
    }

    fun changePitch(value: Float) {
        speaker.pitch = value
        speechPitch = speaker.pitch
    }

    /** Plays a sample at the current speed and pitch, e.g. when a slider is released. */
    fun previewSpeech() = speaker.preview("This is how I sound.")

    fun chooseTheme(mode: String) {
        settings.theme = mode
        themeMode = mode
    }

    fun toggleSpeak(on: Boolean) {
        settings.speakReplies = on
        speaker.enabled = on
        speakReplies = on
        if (!on) speaker.stop()
    }

    fun toggleSmart(on: Boolean) {
        settings.smartReplies = on
        smartReplies = on
    }

    fun toggleLookup(on: Boolean) {
        settings.lookupAnswers = on
        lookupAnswers = on
    }

    fun saveName(value: String) {
        prefs.set("name", value.trim())
        displayName = value
    }

    fun forgetShortcuts() {
        brain.clearTaught()
    }

    fun installVoices(): Boolean = speaker.openVoiceInstall()

    /** Not `setListening`: the `listening` property already claims that JVM signature. */
    fun markListening(value: Boolean) {
        listening = value
        if (value) notice = ""
    }

    // Not `setTranscript` / `setNotice`: the properties above already claim those signatures.
    fun updateTranscript(text: String) { transcript = text }
    fun showNotice(text: String) { notice = text }

    /** A line from Yantra that is not a reply to anything the person said. */
    fun addNote(text: String) {
        if (text.isNotBlank()) messages.add(ChatMsg(false, text))
    }

    /** Runs one command end to end. */
    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        notice = ""
        transcript = ""
        messages.add(ChatMsg(true, text))

        viewModelScope.launch {
            busy = true
            try {
                process(text)
            } catch (e: Exception) {
                reply("Something went wrong: ${e.message ?: "unknown error"}.")
            } finally {
                busy = false
            }
        }
    }

    private fun ctx() = Ctx(
        now = System.currentTimeMillis(),
        lastUser = lastUser,
        lastBot = lastBot,
        lastTarget = lastTarget
    )

    /** Does the router understand this as a command? Used before saving a taught shortcut. */
    private fun understood(command: String): Boolean = Router.routeAll(command, Ctx()).all {
        it.action != "unknown" && it.action != "ask" && it.action != "empty"
    }

    /**
     * True when the router had nothing real: no command matched, or the text only
     * fell through to the catch-all web search for a question. An explicit
     * "search for ..." is a command and is left alone.
     */
    private fun fellThrough(commands: List<Parsed>, text: String): Boolean {
        if (commands.size != 1) return false
        val p = commands[0]
        if (p.action == "unknown") return true
        return p.action == "search" && !EXPLICIT_SEARCH.containsMatchIn(Router.normalize(text))
    }

    private suspend fun process(text: String) {
        // someone who is struggling comes before everything else
        Brain.crisis(text)?.let { reply(it.text); return }

        // a waiting "open it in the browser?": yes runs it, no drops it, anything else is a new request
        offered?.let { cmd ->
            offered = null
            val n = Router.normalize(text).replace(Regex("[^a-z ]"), " ").trim().replace(Regex("\\s+"), " ")
            if (OFFER_YES.matches(n)) {
                runCommands(cmd, Router.routeAll(cmd, ctx()))
                return
            }
            if (OFFER_NO.matches(n)) {
                reply("Okay, leaving it.")
                return
            }
        }

        if (smartReplies) {
            brain.userName = prefs.name()

            // a waiting "did you mean ...?" gets the first word, since "yes" and "ok" mean other things to the router
            brain.answerPending(text)?.let { if (act(it)) return }
            // teaching, listing and forgetting shortcuts
            brain.learn(text) { understood(it) }?.let { if (act(it)) return }
            // shortcuts you taught, which may override a built-in phrase
            brain.recall(text)?.let { if (act(it)) return }
            // "another one"
            brain.more(text)?.let { if (act(it)) return }
            // "remember that ...", "I am in 9th grade", "show my memories", "forget my ..."
            memory.handle(text, passive = true)?.let { reply(it); return }
        } else if (memory.isListRequest(text)) {
            // the list is always available, even with smart replies off
            reply(memory.listing())
            return
        }

        val commands = Router.routeAll(text, ctx())

        if (smartReplies && fellThrough(commands, text)) {
            if (think(text)) return
        } else {
            brain.forgetTopic()
        }

        runCommands(text, commands)
    }

    /**
     * What to try when the router found nothing, cheapest and most certain first:
     * exact arithmetic, then the small brain, then the language model if one is loaded.
     * True when something answered; false falls through to the old web search.
     */
    private suspend fun think(text: String): Boolean {
        Reasoner.evaluate(text)?.let { reply(it); return true }
        if (act(brain.think(text))) return true
        val model = activeModel() ?: return false
        return askModel(model, text)
    }

    private fun history(): List<Turn> =
        messages.dropLast(1).drop(1).takeLast(Prompts.MAX_HISTORY).map { Turn(it.fromUser, it.text) }

    private suspend fun askModel(model: TextModel, text: String): Boolean {
        val past = history()
        val facts = memory.promptBlock()

        if (Mind.looksFactual(text)) {
            // look it up first so the model answers from a source instead of from memory
            val found = if (lookupAnswers) Answers.lookup(text) else null
            val said = Mind.answer(model, text, past, facts, found?.text)
            if (said != null) {
                reply(said, source = found?.source ?: "", link = found?.link ?: "")
                return true
            }
            if (found != null) {
                reply(found.text, found.speak, found.source, found.link)
                return true
            }
            return false
        }

        val plan = Mind.plan(model, text, past, facts, prefs.name(), { understood(it) }) ?: return false
        return runPlan(text, plan)
    }

    /**
     * Runs what the model proposed. Anything that messages or calls someone, or
     * deletes something, waits for an explicit yes first.
     */
    private suspend fun runPlan(text: String, plan: Plan): Boolean {
        if (plan.commands.isEmpty()) {
            if (plan.say.isBlank()) return false
            reply(plan.say)
            return true
        }
        val safe = ArrayList<Parsed>()
        val ran = ArrayList<String>()
        for (cmd in plan.commands) {
            val routed = Router.routeAll(cmd, ctx())
            if (routed.any { Risk.needsConfirm(it) }) {
                if (safe.isNotEmpty()) runCommands(text, safe, prefix = "Taking that as " + quoted(ran) + ".\n")
                brain.expect(cmd)
                reply("I would run \"$cmd\". Say yes to go ahead, or no to leave it.")
                return true
            }
            safe.addAll(routed)
            ran.add(cmd)
        }
        runCommands(text, safe, prefix = "Taking that as " + quoted(ran) + ".\n")
        return true
    }

    private fun quoted(commands: List<String>): String = commands.joinToString(", ") { "\"$it\"" }

    /** Shows what the brain decided. False means it had nothing, so the normal path continues. */
    private suspend fun act(t: Thought): Boolean {
        when (t) {
            is Thought.Reply -> reply(t.text)
            is Thought.Confirm -> reply(t.prompt)
            is Thought.Run -> {
                val commands = Router.routeAll(t.command, ctx())
                runCommands(t.command, commands, prefix = "Taking that as \"${t.command}\".\n")
            }
            Thought.Pass -> return false
        }
        return true
    }

    private suspend fun runCommands(text: String, commands: List<Parsed>, prefix: String = "") {
        val shown = ArrayList<String>()
        val spoken = ArrayList<String>()
        var link = ""
        var source = ""
        var offer = ""
        for (parsed in commands) {
            // timer actions live in the view model, not the executor
            val handledInVm = handleTimerAction(parsed)
            if (handledInVm != null) {
                shown.add(handledInVm)
                spoken.add(handledInVm)
            } else {
                val result = executor.run(parsed)
                if (result.text.isNotEmpty()) {
                    shown.add(result.text)
                    spoken.add(result.speak)
                    if (result.offer.isNotEmpty()) offer = result.offer
                    if (result.link.isNotEmpty()) {
                        link = result.link
                        source = result.source
                    }
                }
            }
        }
        if (shown.isNotEmpty()) reply(prefix + shown.joinToString("\n"), spoken.joinToString(" "), source, link)
        if (offer.isNotEmpty()) {
            // a question is on screen: remember what yes means and let the mic open briefly for the answer
            offered = offer
            followUp++
        }

        // what "a bit more" or "turn it up" should act on next
        lastTarget = when {
            commands.lastOrNull()?.action?.startsWith("brightness") == true -> "brightness"
            commands.lastOrNull()?.action?.startsWith("volume") == true -> "volume"
            else -> null
        }
        lastUser = text
    }

    private fun reply(text: String, speak: String = text, source: String = "", link: String = "") {
        messages.add(ChatMsg(false, text, source = source, link = link))
        lastBot = text
        lastSpoken = speak
        speaker.say(speak)
    }

    // ------------------------------------------------------------- timers

    private fun handleTimerAction(p: Parsed): String? = when (p.action) {
        // the phone's Clock app runs timers; Yantra only counts down itself when there is no Clock app
        "timer" -> {
            // p.a only holds the words that were said ("10 minutes"), not a name for the timer
            val viaClock = executor.setTimer(p.num)
            if (viaClock != null) viaClock.text
            else {
                startTimer(p.num, p.a.ifEmpty { "timer" })
                "Timer set for ${human(p.num)}."
            }
        }
        // "set a timer" / "set an alarm" with no time: ask with the picker
        "timer-ui" -> openClockSheet(ClockKind.TIMER)
        "alarm-ui" -> openClockSheet(ClockKind.ALARM)
        // the speaker belongs to the view model, so voice commands live here
        "voice" -> when (p.a) {
            "next" -> when (speaker.voiceCount()) {
                0 -> "My voice is still starting up, or this phone has no English voices yet. Say \"install a voice\"."
                1 -> "Only one English voice is installed. Say \"install a voice\" to get more natural ones."
                else -> (speaker.nextVoice() ?: "I could not switch voices.") + " This is how I sound now."
            }
            "list" -> speaker.voiceSummary()
            "install" ->
                if (speaker.openVoiceInstall())
                    "Opening the voice downloads. Pick an English voice, then say \"change your voice\"."
                else
                    "I could not open them. Try Settings, System, Languages, Text-to-speech output."
            "deeper" -> { speaker.shiftPitch(-0.1f); "Okay, a little deeper." }
            "higher" -> { speaker.shiftPitch(0.1f); "Okay, a little higher." }
            "reset" -> { speaker.resetVoice(); "Voice reset to automatic." }
            else -> null
        }
        // speaking speed lives with the speaker, which the view model owns
        "pref" -> if (p.a == "rate") {
            speaker.rate = if (p.b == "slow") 0.8f else 1.3f
            if (p.b == "slow") "Okay, I will speak more slowly." else "Okay, I will speak faster."
        } else null
        "timer-pause" -> {
            if (timerJob == null) executor.showTimers().text
            else {
                timerRemaining = (timerEndsAt - System.currentTimeMillis()).coerceAtLeast(0)
                timerPaused = true
                cancelTimerAlarm()
                timerJob?.cancel()
                timerJob = null
                "Paused with ${human(timerRemaining)} left."
            }
        }
        "timer-resume" -> {
            if (!timerPaused || timerRemaining <= 0) executor.showTimers().text
            else {
                timerPaused = false
                runTimer(timerRemaining)
                "Resumed, ${human(timerRemaining)} left."
            }
        }
        "timer-cancel" -> {
            if (timerJob == null && !timerPaused) executor.showTimers().text
            else {
                cancelTimerAlarm()
                timerJob?.cancel()
                timerJob = null
                timerPaused = false
                timerLeft = ""
                "Timer cancelled."
            }
        }
        "timer-status" -> {
            val left = when {
                timerPaused -> timerRemaining
                timerJob != null -> (timerEndsAt - System.currentTimeMillis()).coerceAtLeast(0)
                else -> 0
            }
            if (left <= 0) executor.showTimers().text
            else "${human(left)} left on the $timerLabel" + if (timerPaused) " (paused)." else "."
        }
        else -> null
    }

    private fun openClockSheet(kind: ClockKind): String {
        clockAppName = executor.clockAppName() ?: "Yantra"
        clockSheet = kind
        return if (kind == ClockKind.TIMER) "Pick a time for the timer." else "Pick a time for the alarm."
    }

    fun dismissClockSheet() {
        clockSheet = null
    }

    /** The picker's play button: hand the choice to the Clock app and say what happened. */
    fun startFromClockSheet(pick: ClockPick) {
        clockSheet = null
        when (pick) {
            is ClockPick.Timer -> {
                val ms = pick.seconds * 1000L
                val result = executor.setTimer(ms, pick.label)
                if (result != null) reply(result.text, result.speak)
                else {
                    startTimer(ms, pick.label.ifBlank { "timer" })
                    reply("No Clock app answered (${ClockApp.lastProblem ?: "no reason given"}), so Yantra is running this timer: ${human(ms)}.")
                }
            }
            is ClockPick.Alarm -> {
                val result = executor.setAlarm(pick.hour, pick.minute, pick.label)
                reply(result.text, result.speak)
            }
        }
    }

    private fun startTimer(ms: Long, label: String) {
        timerJob?.cancel()
        timerLabel = label
        timerPaused = false
        timerRemaining = 0
        runTimer(ms)
    }

    private fun runTimer(ms: Long) {
        timerEndsAt = System.currentTimeMillis() + ms
        armTimerAlarm(timerEndsAt)
        timerJob = viewModelScope.launch {
            while (true) {
                val left = timerEndsAt - System.currentTimeMillis()
                timerLeft = if (left <= 0) "" else human(left)
                if (left <= 0) break
                delay(250)
            }
            timerJob = null
            timerAlarmAt = 0L // it has rung (or is ringing) on its own
            reply("Your $timerLabel is done.", "Your $timerLabel is done.")
        }
    }

    /**
     * Yantra's own timer also gets an Android alarm, so it still rings if the app is closed or
     * killed. The countdown on screen is only a display; this is what makes it reliable.
     */
    private fun armTimerAlarm(at: Long) {
        cancelTimerAlarm()
        val ctx = getApplication<Application>()
        val am = ctx.getSystemService(android.content.Context.ALARM_SERVICE) as android.app.AlarmManager
        val pi = `in`.yantra.assistant.service.AlarmReceiver.pending(ctx, at, "Your $timerLabel is done.")
        try {
            am.setAlarmClock(android.app.AlarmManager.AlarmClockInfo(at, pi), pi)
            timerAlarmAt = at
        } catch (e: SecurityException) { /* the on-screen countdown still runs */ }
    }

    private fun cancelTimerAlarm() {
        if (timerAlarmAt == 0L) return
        val ctx = getApplication<Application>()
        val am = ctx.getSystemService(android.content.Context.ALARM_SERVICE) as android.app.AlarmManager
        am.cancel(`in`.yantra.assistant.service.AlarmReceiver.pending(ctx, timerAlarmAt, "Your $timerLabel is done."))
        timerAlarmAt = 0L
    }

    private fun human(ms: Long): String {
        val s = (ms / 1000).toInt()
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return buildString {
            if (h > 0) append("${h}h ")
            append("${m}m ")
            append(if (sec < 10) "0$sec" else "$sec")
            append("s")
        }
    }

    fun userName(): String = prefs.name()

    private companion object {
        val OFFER_YES = Regex("(?:yes|yeah|yep|yup|sure|ok|okay|please|go ahead|do it|open it|open|ok sure|yes please|sure thing|of course|why not)")
        val OFFER_NO = Regex("(?:no|nope|nah|no thanks|no thank you|dont|do not|cancel|leave it|never mind|nevermind|stop|not now)")
        val EXPLICIT_SEARCH = Regex("^(?:search|google|look up|lookup|find|define|meaning of|translate)\\b")
    }

    override fun onCleared() {
        super.onCleared()
        speaker.shutdown()
        localModel.shutdown()
        timerJob?.cancel()
    }
}
