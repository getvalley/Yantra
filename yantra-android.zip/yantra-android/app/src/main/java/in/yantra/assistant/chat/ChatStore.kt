package `in`.yantra.assistant.chat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Previous chats, kept on the phone and nowhere else.
 *
 * One small JSON file per chat in the app's private storage (backup is off in the manifest),
 * so the main app and the summon bubble can both save without overwriting each other.
 * A write goes to a temporary file and is renamed into place, so a crash never leaves half a chat.
 * Anything that cannot be read is skipped rather than breaking the list.
 */
class ChatStore(context: Context) {

    private val dir = File(context.applicationContext.filesDir, "chats").apply { mkdirs() }

    private fun fileOf(id: Long) = File(dir, "$id.json")

    /** Pins and names the person chose, kept apart from the chats so saving a chat never undoes them. */
    private val metaFile = File(dir, "meta.dat")

    private class Meta(val pinned: Boolean, val name: String)

    private fun readMeta(): MutableMap<Long, Meta> {
        val out = HashMap<Long, Meta>()
        try {
            if (metaFile.exists()) {
                val o = JSONObject(metaFile.readText())
                for (key in o.keys()) {
                    val id = key.toLongOrNull() ?: continue
                    val m = o.getJSONObject(key)
                    out[id] = Meta(m.optBoolean("p"), m.optString("n"))
                }
            }
        } catch (e: Exception) { /* unreadable: start without them */ }
        return out
    }

    private fun writeMeta(meta: Map<Long, Meta>) {
        val o = JSONObject()
        for ((id, m) in meta) {
            if (!m.pinned && m.name.isEmpty()) continue
            o.put(id.toString(), JSONObject().put("p", m.pinned).put("n", m.name))
        }
        val tmp = File(dir, "meta.tmp")
        tmp.writeText(o.toString())
        if (!tmp.renameTo(metaFile)) { metaFile.writeText(o.toString()); tmp.delete() }
    }

    @Synchronized
    fun setPinned(id: Long, pinned: Boolean) {
        val meta = readMeta()
        meta[id] = Meta(pinned, meta[id]?.name.orEmpty())
        writeMeta(meta)
    }

    /** A blank name goes back to the automatic one. */
    @Synchronized
    fun rename(id: Long, name: String) {
        val meta = readMeta()
        meta[id] = Meta(meta[id]?.pinned ?: false, name.trim())
        writeMeta(meta)
    }

    @Synchronized
    fun write(chat: Chat) {
        val msgs = JSONArray()
        for (m in chat.messages) {
            msgs.put(
                JSONObject()
                    .put("u", m.fromUser)
                    .put("t", m.text)
                    .apply {
                        if (m.source.isNotEmpty()) put("s", m.source)
                        if (m.link.isNotEmpty()) put("l", m.link)
                    }
            )
        }
        val json = JSONObject()
            .put("id", chat.id)
            .put("title", chat.title)
            .put("updated", chat.updated)
            .put("messages", msgs)
        val tmp = File(dir, "${chat.id}.tmp")
        tmp.writeText(json.toString())
        if (!tmp.renameTo(fileOf(chat.id))) {
            fileOf(chat.id).writeText(json.toString())
            tmp.delete()
        }
        prune()
    }

    @Synchronized
    fun read(id: Long): Chat? {
        val chat = parse(fileOf(id)) ?: return null
        val name = readMeta()[id]?.name.orEmpty()
        return if (name.isEmpty()) chat else chat.copy(title = name)
    }

    /** Newest first. */
    @Synchronized
    fun list(): List<ChatSummary> {
        val meta = readMeta()
        return files().mapNotNull { parse(it) }.map { chat ->
            val m = meta[chat.id]
            val base = ChatLog.summary(chat)
            if (m == null) base
            else base.copy(
                title = if (m.name.isNotEmpty()) m.name else base.title,
                pinned = m.pinned,
                renamed = m.name.isNotEmpty()
            )
        }.sortedByDescending { it.updated }
    }

    @Synchronized
    fun delete(id: Long) {
        fileOf(id).delete()
        val meta = readMeta()
        if (meta.remove(id) != null) writeMeta(meta)
    }

    @Synchronized
    fun clear() {
        files().forEach { it.delete() }
        metaFile.delete()
    }

    private fun files(): List<File> = dir.listFiles { f -> f.name.endsWith(".json") }?.toList().orEmpty()

    private fun prune() {
        val updated = HashMap<Long, Long>()
        for (f in files()) {
            val id = f.name.removeSuffix(".json").toLongOrNull() ?: continue
            updated[id] = f.lastModified()
        }
        ChatLog.overflow(updated).forEach { fileOf(it).delete() }
    }

    private fun parse(file: File): Chat? = try {
        val o = JSONObject(file.readText())
        val arr = o.getJSONArray("messages")
        val list = ArrayList<StoredMsg>(arr.length())
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            list.add(StoredMsg(m.optBoolean("u"), m.optString("t"), m.optString("s"), m.optString("l")))
        }
        Chat(o.getLong("id"), o.optString("title", "Chat"), o.optLong("updated"), list)
    } catch (e: Exception) {
        null
    }
}
