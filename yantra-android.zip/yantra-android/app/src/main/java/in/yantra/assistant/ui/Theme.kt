package `in`.yantra.assistant.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.FontVariation
import `in`.yantra.assistant.util.AppSettings
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import `in`.yantra.assistant.R

/*
 * White and black, with orange, brown and sky blue used sparingly. Surfaces are plain white (or
 * plain black) and are told apart by a 1dp grey border and a faint shadow, never by tinted paper.
 */

// ---- light ---------------------------------------------------------------
val Paper = Color(0xFFF0F0F0)   // a touch dimmer than white, so white plates lift off it
val SurfaceLight = Color(0xFFFFFFFF)
val Ink = Color(0xFF000000)
val Ink2 = Color(0xFF666666)
val Ink3 = Color(0xFF6A6A6A)
val LineLight = Color(0xFFE2E2E2)
val Ember = Color(0xFFE8622A)   // orange: the one action colour
val Amber = Color(0xFFF6B955)
val Sky = Color(0xFF7DB6E6)     // sky blue: links and directions
val Clay = Color(0xFFD4622B)
val Plum = Color(0xFF6B4636)    // brown: quiet emphasis
val Night = Color(0xFF111111)

// ---- dark ----------------------------------------------------------------
val PaperDark = Color(0xFF000000)
val SurfaceDark = Color(0xFF111111)
val InkDark = Color(0xFFFFFFFF)
val Ink2Dark = Color(0xFFA8A8A8)
val Ink3Dark = Color(0xFF8A8A8A)
val LineDark = Color(0xFF2C2C2C)
val NightDark = Color(0xFF1A1A1A)

private val LightScheme = lightColorScheme(
    primary = Ember,
    onPrimary = Color.White,
    secondary = Plum,
    onSecondary = Color.White,
    tertiary = Sky,
    onTertiary = Ink,
    background = Paper,
    onBackground = Ink,
    surface = SurfaceLight,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF5F5F5),
    onSurfaceVariant = Ink2,
    outline = LineLight,
    outlineVariant = LineLight,
    error = Clay,
    onError = Color.White
)

private val DarkScheme = darkColorScheme(
    primary = Ember,
    onPrimary = Color.White,
    secondary = Color(0xFFB08A74),
    onSecondary = Color.Black,
    tertiary = Sky,
    onTertiary = Color.Black,
    background = PaperDark,
    onBackground = InkDark,
    surface = SurfaceDark,
    onSurface = InkDark,
    surfaceVariant = NightDark,
    onSurfaceVariant = Ink2Dark,
    outline = LineDark,
    outlineVariant = LineDark,
    error = Clay,
    onError = Color.White
)

val Bricolage = FontFamily(
    Font(R.font.bricolage_regular, FontWeight.Normal),
    Font(R.font.bricolage_medium, FontWeight.Medium),
    Font(R.font.bricolage_semibold, FontWeight.SemiBold),
    Font(R.font.bricolage_bold, FontWeight.Bold)
)

/** One weight of a variable font file: the file holds every weight, the setting picks one. */
@OptIn(ExperimentalTextApi::class)
private fun variable(resId: Int, weight: FontWeight) = Font(
    resId,
    weight,
    variationSettings = FontVariation.Settings(FontVariation.weight(weight.weight))
)

private val WEIGHTS = listOf(FontWeight.Normal, FontWeight.Medium, FontWeight.SemiBold, FontWeight.Bold)

val InterFamily = FontFamily(WEIGHTS.map { variable(R.font.inter_variable, it) })
val LibreBaskervilleFamily = FontFamily(WEIGHTS.map { variable(R.font.libre_baskerville_variable, it) })

/** The family for a saved [AppSettings] font key; anything unknown is Bricolage. */
fun fontFamilyFor(key: String): FontFamily = when (key) {
    AppSettings.FONT_INTER -> InterFamily
    AppSettings.FONT_BASKERVILLE -> LibreBaskervilleFamily
    else -> Bricolage
}

/** The font the person chose in Settings. [YantraTheme] provides it. */
val LocalAppFont = staticCompositionLocalOf<FontFamily> { Bricolage }

/** Use this where a screen sets its own `fontFamily`, so it follows the font choice. */
val AppFont: FontFamily
    @Composable @ReadOnlyComposable get() = LocalAppFont.current

private fun yantraType(f: FontFamily) = Typography(
    displayLarge = TextStyle(
        fontFamily = f, fontWeight = FontWeight.Bold,
        fontSize = 46.sp, lineHeight = 44.sp, letterSpacing = (-1.8).sp
    ),
    displayMedium = TextStyle(
        fontFamily = f, fontWeight = FontWeight.Bold,
        fontSize = 34.sp, lineHeight = 34.sp, letterSpacing = (-1.2).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = f, fontWeight = FontWeight.SemiBold,
        fontSize = 26.sp, lineHeight = 30.sp, letterSpacing = (-0.8).sp
    ),
    titleLarge = TextStyle(
        fontFamily = f, fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp, lineHeight = 24.sp, letterSpacing = (-0.3).sp
    ),
    titleMedium = TextStyle(
        fontFamily = f, fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp, lineHeight = 20.sp, letterSpacing = (-0.1).sp
    ),
    bodyLarge = TextStyle(
        fontFamily = f, fontWeight = FontWeight.Normal,
        fontSize = 16.sp, lineHeight = 25.sp, letterSpacing = 0.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = f, fontWeight = FontWeight.Normal,
        fontSize = 15.sp, lineHeight = 22.sp, letterSpacing = 0.sp
    ),
    bodySmall = TextStyle(
        fontFamily = f, fontWeight = FontWeight.Normal,
        fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.1.sp
    ),
    labelLarge = TextStyle(
        fontFamily = f, fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp, lineHeight = 18.sp, letterSpacing = 0.sp
    ),
    labelMedium = TextStyle(
        fontFamily = f, fontWeight = FontWeight.Medium,
        fontSize = 13.sp, lineHeight = 16.sp, letterSpacing = 0.2.sp
    )
)

@Composable
fun YantraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    font: String = AppSettings.FONT_BRICOLAGE,
    content: @Composable () -> Unit
) {
    val family = fontFamilyFor(font)
    val type = remember(family) { yantraType(family) }
    CompositionLocalProvider(LocalAppFont provides family) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkScheme else LightScheme,
            typography = type,
            content = content
        )
    }
}
