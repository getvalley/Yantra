package `in`.yantra.assistant.speech

/**
 * Turns on-screen text into something that sounds like a person reading it.
 *
 * What looks fine in a chat bubble sounds robotic when read aloud verbatim:
 * "Brightness 30% → 80%" becomes "brightness thirty percent, arrow, eighty
 * percent" and a bulleted list becomes a run of unpunctuated words. This
 * rewrites symbols into words and line breaks into pauses.
 *
 * Pure Kotlin, no Android imports, so it is unit-tested on the JVM.
 */
object SpeechText {

    /**
     * "5m 00s" is for the screen. Read aloud it is "5 meters" and the letter "s", so
     * spell the units out, and drop zero parts: "1h 0m 05s" becomes "1 hour 5 seconds".
     */
    private fun units(text: String): String {
        var t = text
            .replace(Regex("\\s*(?<![\\p{L}\\d])0+s\\b"), "")
            .replace(Regex("(?<![\\p{L}\\d])0+m\\s*"), "")
            .replace(Regex("(?<![\\p{L}\\d])0+h\\s*"), "")
        t = Regex("(?<![\\p{L}\\d])(\\d+)([hms])\\b").replace(t) { m ->
            val n = m.groupValues[1].toInt()
            val word = when (m.groupValues[2]) { "h" -> "hour"; "m" -> "minute"; else -> "second" }
            "$n $word" + if (n == 1) "" else "s"
        }
        return t
    }

    fun clean(text: String): String {
        var s = units(text)
            .replace("\u2192", " to ")          // →
            .replace("\u2022", "")              // • bullets
            .replace("\u2014", ", ")            // — em dash
            .replace("\u2013", " to ")          // – ranges
            .replace("&", " and ")
            .replace(Regex("(\\d)\\s*%"), "$1 percent")
            .replace(Regex("(\\d)\\s*\u00B0\\s*C\\b"), "$1 degrees Celsius")
            .replace(Regex("(\\d)\\s*\u00B0\\s*F\\b"), "$1 degrees Fahrenheit")
            .replace(Regex("[*_`#]+"), "")
            .replace(Regex("\\.{2,}|\u2026"), ", ")

        // a line break is a breath: after punctuation it is just a space,
        // otherwise it becomes a full stop
        s = s.replace(Regex("([.:;!?])\\s*\\n+\\s*"), "$1 ")
        s = s.replace(Regex("\\s*\\n+\\s*"), ". ")

        return s
            .replace(Regex("\\s+,"), ",")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
    }
}
