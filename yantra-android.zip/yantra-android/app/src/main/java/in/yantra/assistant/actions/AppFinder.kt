package `in`.yantra.assistant.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings

/**
 * Finds apps by what is installed on this phone, not by a list of package names.
 *
 * Two steps, in order:
 *  1. A kind of app ("browser", "camera", "messages", "calculator"...) is whatever app the
 *     phone itself uses for that job. Android answers that through intents, so a Samsung,
 *     Pixel or OnePlus phone each gets its own app, and the person's chosen default wins.
 *  2. Anything else ("youtube", "spotify", "my bank app") is matched against the labels the
 *     launcher shows, forgiving of spacing, filler words and small misspellings.
 */
object AppFinder {

    /** Every app with a launcher icon. */
    fun installed(ctx: Context): List<App> {
        val pm = ctx.packageManager
        return pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
    }

    /**
     * The app for [spoken]. With [roles] on, a kind of app resolves to the phone's default for it
     * (unless an app is literally called that). Null when nothing matches with confidence.
     */
    fun find(ctx: Context, spoken: String, roles: Boolean = true): App? {
        val apps = installed(ctx)
        if (roles) {
            val wanted = AppMatch.norm(AppMatch.clean(spoken))
            val literal = apps.firstOrNull { AppMatch.norm(it.label) == wanted }
            if (literal != null) return literal
            roleApp(ctx, apps, spoken)?.let { return it }
        }
        return AppMatch.best(apps, spoken)
    }

    /** "Did you mean ...?" candidates for a name that did not match. */
    fun suggestions(ctx: Context, spoken: String): List<String> =
        AppMatch.suggestions(installed(ctx), spoken)

    /** An intent that opens [app]'s main screen, or null when it has none. */
    fun launchIntent(ctx: Context, app: App): Intent? =
        ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** What the phone would open for this kind of request, as a launchable app. */
    private fun roleApp(ctx: Context, apps: List<App>, spoken: String): App? {
        val intent = roleIntent(AppMatch.clean(spoken)) ?: return null
        val pm = ctx.packageManager
        val byPkg = apps.associateBy { it.pkg }
        try {
            // the person's chosen default first
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName
                ?.let { pkg -> byPkg[pkg]?.let { return it } }
            // no default chosen ("android" is the chooser): the first real app that can do it
            return pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
                .map { it.activityInfo.packageName }
                .firstOrNull { it != ctx.packageName && byPkg.containsKey(it) }
                ?.let { byPkg[it] }
        } catch (e: Exception) {
            return null
        }
    }

    private fun main(category: String) = Intent(Intent.ACTION_MAIN).addCategory(category)

    private fun roleIntent(word: String): Intent? = when (word) {
        "browser", "web browser", "internet" ->
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE)
        "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        "gallery", "photos", "pictures", "images" -> main(Intent.CATEGORY_APP_GALLERY)
        "settings" -> Intent(Settings.ACTION_SETTINGS)
        "clock", "alarm", "alarms", "timer" -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
        "calculator" -> main(Intent.CATEGORY_APP_CALCULATOR)
        "maps", "map", "navigation" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0"))
        "phone", "dialer", "dialpad" -> Intent(Intent.ACTION_DIAL)
        "contacts" -> main(Intent.CATEGORY_APP_CONTACTS)
        "messages", "messaging", "sms", "texts" -> main(Intent.CATEGORY_APP_MESSAGING)
        "email", "mail" -> main(Intent.CATEGORY_APP_EMAIL)
        "music", "music player" -> main(Intent.CATEGORY_APP_MUSIC)
        "calendar" -> main(Intent.CATEGORY_APP_CALENDAR)
        "files", "file manager", "file browser" ->
            Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
        "play store", "app store", "store" -> Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=app"))
        else -> null
    }
}
