package `in`.yantra.assistant.ui

import androidx.compose.ui.graphics.ImageBitmap

/** An installed app the typed text clearly names: shown as "WhatsApp \u2014 Open" in the bar. */
data class AppHit(val label: String, val pkg: String, val icon: ImageBitmap?)
