package `in`.yantra.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp

/*
 * The app's version of the summon bubble: soft frosted glass with a rim that catches light
 * at the top, floating over the orb's four colours. Same language, drawn in plain Compose so it
 * costs nothing while scrolling. The wake-up bubble itself is the animated shader in GlassBlobView.
 */

@Composable
internal fun isDarkScheme(): Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f

/**
 * A glass surface. [tint] washes it with a colour (your messages use the ember); [strong] makes it
 * more solid, for a card that sits on another glass surface.
 */
@Composable
internal fun Modifier.glass(shape: Shape, tint: Color = Color.Transparent, strong: Boolean = false): Modifier {
    val dark = isDarkScheme()
    val fill = when {
        dark && strong -> 0.15f
        dark -> 0.08f
        strong -> 0.85f
        else -> 0.58f
    }
    val rim = if (dark) {
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.34f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.14f))
        )
    } else {
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.95f), Color(0x141B1815), Color(0x261B1815)))
    }
    return this
        .clip(shape)
        .background(Color.White.copy(alpha = fill))
        .background(tint)
        .border(1.dp, rim, shape)
}

/** The ground the glass floats on: the app's paper (or night) with the orb's colours bleeding in. */
@Composable
internal fun GlassBackdrop(modifier: Modifier = Modifier) {
    val dark = isDarkScheme()
    val base = MaterialTheme.colorScheme.background
    Box(
        modifier = modifier
            .background(base)
            .drawBehind {
                fun cloud(color: Color, alpha: Float, cx: Float, cy: Float, radius: Float) {
                    val centre = Offset(cx, cy)
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(color.copy(alpha = alpha), Color.Transparent),
                            center = centre,
                            radius = radius
                        ),
                        radius = radius,
                        center = centre
                    )
                }
                val w = size.width
                val h = size.height
                cloud(Ember, if (dark) 0.24f else 0.17f, w * 0.10f, h * 0.03f, w * 1.0f)
                cloud(Sky, if (dark) 0.15f else 0.20f, w * 1.00f, h * 0.36f, w * 0.85f)
                cloud(Amber, if (dark) 0.07f else 0.14f, w * 0.05f, h * 0.60f, w * 0.7f)
                cloud(Plum, if (dark) 0.34f else 0.07f, w * 0.30f, h * 0.97f, w * 0.95f)
            }
    )
}

/** How tall the bars are, matching the bubble's search bar. */
internal val GlassBarHeight = 68.dp
