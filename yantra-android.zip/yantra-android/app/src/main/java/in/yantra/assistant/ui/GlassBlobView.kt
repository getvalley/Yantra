package `in`.yantra.assistant.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.util.AttributeSet
import android.view.View
import androidx.annotation.RequiresApi
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Shared layout numbers, so the Compose text field in AssistPanel sits exactly
 * inside the glass bar this view draws.
 */
internal object GlassGeometry {
    /** Gap between the glass and each side of the screen. */
    const val EDGE_MARGIN_DP = 12f
    /** Half the height of the glass once it has turned into the search bar. */
    const val BAR_HALF_HEIGHT_DP = 38f
    /** Gap between the bottom of the status bar and the top of the glass. */
    const val TOP_GAP_DP = 6f
}

/**
 * The wake-up blob: a wide, fat bubble of liquid glass that drops out of the top of
 * the screen when Yantra is summoned. It spans the screen from side to side and,
 * when [bar] is set, slims down into the "Search or Ask" bar, and when
 * [answerHeight] is set, grows into a rounded panel that holds Yantra's answer.
 *
 * What you see: a thick bevelled rim that catches light, and a white wave with
 * rainbow fringes running through the middle. The wave grows with your voice
 * and flows faster while Yantra thinks; the glow outside swells too.
 *
 * On Android 13+ it is one AGSL shader. Older phones get a gradient version
 * drawn on the canvas, which is flatter but keeps the same shape and motion.
 *
 * Every moving value is integrated from the frame time, so switching between
 * idle, listening and working eases instead of jumping.
 */
class GlassBlobView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** The mic is open: the blob swells and the streak moves. */
    var listening: Boolean = false
        set(value) { field = value; kick() }

    /** Yantra is thinking: the streak flows and the blob holds a lively state. */
    var working: Boolean = false
        set(value) { field = value; kick() }

    /** Live voice level, 0..1, from the recogniser. Only used while [listening]. */
    var micLevel: Float = 0f

    /** Turn the bubble into the slim text bar. The wave fades; AssistPanel draws the field on top. */
    var bar: Boolean = false
        set(value) { field = value; kick() }

    /**
     * Height in px of the answer content drawn on top (0 = no answer). The glass morphs into a
     * rounded panel exactly this tall, and back to the bubble or bar when it returns to 0.
     */
    var answerHeight: Float = 0f
        set(value) { field = value; kick() }

    /** Smaller blob, for when the keyboard is up and room is short. */
    var compact: Boolean = false
        set(value) { field = value; kick() }

    /** Height of the status bar in px. The blob grows out of it. */
    var topInset: Float = 0f
        set(value) { field = value; invalidate() }

    /** Four colours: ember, amber, sky, plum. */
    var palette: IntArray = OrbClouds
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()
    private val wave = Path()
    private val shapeP = Path()

    private var gpu: GlassShader? = null

    private var time = 0f          // seconds
    private var level = 0f         // 0..1 eased voice energy
    private var work = 0f          // 0..1 eased "thinking"
    private var sizeScale = 1f     // 1 normal, COMPACT_SCALE compact
    private var barF = 0f          // 0 = wake bubble, 1 = search bar
    private var panelF = 0f        // 0 = bubble or bar, 1 = answer panel
    private var ansH = 0f          // eased answer height in px
    private var wavePhase = 0f     // wave position; speeds up with your voice, never jumps
    private var appear = 0f        // eased 0..1: 0 = above the screen, 1 = settled under the status bar
    private var appearT = 0f       // linear 0..1 progress of the float-in

    private var lastFrameAt = 0L
    private var running = false
    private var motionOk = true

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
        if (Build.VERSION.SDK_INT >= 33) {
            gpu = try { GlassShader() } catch (e: Throwable) { null }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isShown) resume()
    }

    override fun onDetachedFromWindow() {
        pause()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) resume() else pause()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && isAttachedToWindow) resume() else pause()
    }

    private fun resume() {
        if (running) return
        running = true
        lastFrameAt = 0L
        // "Remove animations": draw once, fully formed, and stay still
        motionOk = try {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
        } catch (e: Exception) {
            true
        }
        invalidate()
    }

    private fun pause() { running = false }

    private fun kick() {
        if (isAttachedToWindow && isShown) resume()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrameAt == 0L) 16L else (now - lastFrameAt).coerceIn(1L, 100L)
        lastFrameAt = now
        val dtS = dt / 1000f

        // what the blob should be feeling right now
        val target = when {
            listening -> max(0.30f, micLevel.coerceIn(0f, 1f))
            working -> 0.22f
            else -> 0f
        }
        val workTarget = if (working && !listening) 1f else 0f
        val scaleTarget = if (compact) COMPACT_SCALE else 1f
        val barTarget = if (bar) 1f else 0f
        val panelTarget = if (answerHeight > 0f) 1f else 0f

        if (motionOk) {
            // swell fast on a loud word, settle slowly
            val tau = if (target > level) 110f else 260f
            level += (target - level) * (1f - exp(-dt / tau))
            work += (workTarget - work) * (1f - exp(-dt / 260f))
            sizeScale += (scaleTarget - sizeScale) * (1f - exp(-dt / 140f))
            barF += (barTarget - barF) * (1f - exp(-dt / 110f))
            panelF += (panelTarget - panelF) * (1f - exp(-dt / 130f))
            if (answerHeight > 0f) {
                // first frame of an answer starts at full size, later changes ease
                ansH = if (ansH < 1f) answerHeight else ansH + (answerHeight - ansH) * (1f - exp(-dt / ANSWER_FOLLOW_MS))
            } else if (panelF < 0.01f) {
                ansH = 0f
            }
            time += dtS
            // the wave travels faster the louder you speak (integrated, so speed changes ease)
            wavePhase += dtS * (1f + 1.2f * work + 3.4f * level)

            // float-in: a plain ease-out over a fixed time. No spring, so a slow first frame
            // cannot make it overshoot or shake.
            appearT = min(1f, appearT + dt / APPEAR_MS)
            val inv = 1f - appearT
            appear = 1f - inv * inv * inv * inv
        } else {
            level = target
            work = workTarget
            sizeScale = scaleTarget
            barF = barTarget
            panelF = panelTarget
            ansH = answerHeight
            appear = 1f
            appearT = 1f
        }

        drawBlob(canvas)

        if (running && motionOk) postInvalidateOnAnimation()
    }

    private fun drawBlob(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val dp = resources.displayMetrics.density

        val breath = 1f + 0.012f * sin(time * 2f * PI.toFloat() / 4.8f)
        // the wake bubble is about a third of the screen; the bar spans it edge to edge
        val maxHx = w / 2f - GlassGeometry.EDGE_MARGIN_DP * dp
        val wakeHx = w * 0.17f * sizeScale * (1f + 0.05f * level) * breath
        val wakeHy = w * 0.13f * sizeScale * (1f + 0.07f * level) * breath
        val barHy = GlassGeometry.BAR_HALF_HEIGHT_DP * dp
        val mix = max(barF, panelF)
        val fullHx = wakeHx + (maxHx - wakeHx) * mix
        val baseHy = wakeHy + (barHy - wakeHy) * barF
        val fullHy = baseHy + (max(ansH, 1f) / 2f - baseHy) * panelF

        // it floats down from above the screen and settles just below the status bar,
        // at its final size, with a touch of growth on the way
        val finalCy = topInset + GlassGeometry.TOP_GAP_DP * dp + fullHy
        val startCy = -fullHy - 8f * dp

        val a = appear
        val cx = w / 2f
        val cy = startCy + (finalCy - startCy) * a
        val grow = 0.94f + 0.06f * a
        val hx = (fullHx * grow).coerceIn(4f, w / 2f - 2f * dp)
        val hy = max(fullHy * grow, 4f)
        val alpha = (a * 4f).coerceIn(0f, 1f)
        if (alpha <= 0f) return

        // corners: a full capsule for the bubble and bar, a softer rounded rectangle for the answer
        val capR = min(hx, hy)
        val rad = capR + (min(capR, ANSWER_CORNER_DP * dp) - capR) * panelF
        val bevel = BEVEL_DP * dp * (1f - 0.4f * panelF)

        val g = gpu
        if (g != null && Build.VERSION.SDK_INT >= 33) {
            g.draw(canvas, w, h, cx, cy, hx, hy, rad, bevel, time, wavePhase, level, work, alpha, barF, panelF, mix, palette)
        } else {
            drawFallback(canvas, cx, cy, hx, hy, rad, alpha, barF, panelF, mix)
        }
    }

    // ------------------------------------------------------------------
    // Fallback for Android 8 to 12: the same parts, drawn with gradients.
    // ------------------------------------------------------------------
    private fun drawFallback(c: Canvas, cx: Float, cy: Float, hx: Float, hy: Float, rad: Float, alpha: Float, bar: Float, panel: Float, shape: Float) {
        val r = rad
        rect.set(cx - hx, cy - hy, cx + hx, cy + hy)
        // the wake bubble is a smooth pebble (superellipse); bar and answer are rounded rectangles
        shapeP.reset()
        if (shape < 0.5f) {
            val steps = 96
            for (i in 0..steps) {
                val th = i / steps.toFloat() * 2f * PI.toFloat()
                val ct = cos(th)
                val st = sin(th)
                val x = cx + hx * (if (ct < 0f) -1f else 1f) * abs(ct).pow(2f / PEBBLE_N)
                val y = cy + hy * (if (st < 0f) -1f else 1f) * abs(st).pow(2f / PEBBLE_N)
                if (i == 0) shapeP.moveTo(x, y) else shapeP.lineTo(x, y)
            }
            shapeP.close()
        } else {
            shapeP.addRoundRect(rect, r, r, Path.Direction.CW)
        }
        val rainbow = intArrayOf(
            0xFFFF5E7E.toInt(), 0xFFFFC857.toInt(), 0xFF7CFF9B.toInt(),
            0xFF5ED8FF.toInt(), 0xFF8E7CFF.toInt(), 0xFFFF5E7E.toInt()
        )

        // soft glow outside the edge
        val glowA = ((0.08f + 0.35f * level + 0.10f * work) * 255f * alpha).toInt()
        c.save()
        c.translate(cx, cy)
        c.scale(1f, hy / hx)
        val gr = hx * 1.5f
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            0f, 0f, gr,
            intArrayOf(0, 0, withAlpha(0xFF9AB0FF.toInt(), glowA), 0),
            floatArrayOf(0f, 0.62f, 0.70f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawCircle(0f, 0f, gr, paint)
        c.restore()

        // body: faint glass
        paint.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            intArrayOf(withAlpha(Color.WHITE, (46 * alpha).toInt()), withAlpha(Color.WHITE, (14 * alpha).toInt()), withAlpha(Color.WHITE, (30 * alpha).toInt())),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(shapeP, paint)
        // dark top: smoked glass that clears toward the middle; the answer panel uses the same fade
        paint.shader = LinearGradient(
            0f, rect.top, 0f, cy + hy * (0.35f + 0.40f * bar + 1.65f * panel),
            intArrayOf(withAlpha(0xFF05050A.toInt(), ((224f + 11f * shape) * alpha).toInt()), 0),
            null, Shader.TileMode.CLAMP
        )
        c.drawPath(shapeP, paint)

        // the wave: a white line with rainbow fringes, drawn as a stroked sine path
        c.save()
        c.clipPath(shapeP)
        val amp = hy * (0.14f + 0.30f * level + 0.05f * work)
        wave.reset()
        val steps = 48
        for (i in 0..steps) {
            val u = i / steps.toFloat() * 2f - 1f
            val x = cx + u * hx
            val y = cy + hy * (0.22f + 0.38f * bar) + amp * sin(u * 2.6f + wavePhase)
            if (i == 0) wave.moveTo(x, y) else wave.lineTo(x, y)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        val shift = (time * 0.08f) % 1f
        paint.shader = LinearGradient(
            cx - hx, 0f, cx + hx, 0f,
            rainbow.map { withAlpha(it, (200 * alpha * (1f - 0.6f * bar) * (1f - panel)).toInt()) }.toIntArray(),
            null, Shader.TileMode.MIRROR
        ).also { sh -> val m = android.graphics.Matrix(); m.setTranslate(shift * 2f * hx, 0f); sh.setLocalMatrix(m) }
        paint.strokeWidth = hy * 0.55f
        c.drawPath(wave, paint)
        paint.shader = null
        paint.color = withAlpha(Color.WHITE, (150 * alpha * (1f - 0.6f * bar) * (1f - panel)).toInt())
        paint.strokeWidth = hy * 0.24f
        c.drawPath(wave, paint)
        c.restore()

        // bevelled rim, lit from the top left
        val sw = hy * 0.10f
        paint.strokeWidth = sw * 2f
        paint.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(withAlpha(Color.WHITE, (210 * alpha).toInt()), withAlpha(Color.WHITE, (24 * alpha).toInt()), withAlpha(Color.WHITE, (96 * alpha).toInt())),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.save()
        c.clipPath(shapeP)
        c.drawPath(shapeP, paint)
        c.restore()
        paint.style = Paint.Style.FILL
        paint.shader = null
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private companion object {
        const val COMPACT_SCALE = 0.62f
        /** How long the float-in from the top takes. */
        const val APPEAR_MS = 560f
        /** How closely the glass trails the answer content's height (small = tight, so it can morph with a drag). */
        const val ANSWER_FOLLOW_MS = 40f
        const val ANSWER_CORNER_DP = 38f
        const val BEVEL_DP = 21f
        const val PEBBLE_N = 2.35f
    }
}

/**
 * The glass itself, as an AGSL fragment shader (Android 13+).
 *
 * Everything is derived from one signed distance field: the distance to the
 * blob's edge. From it come the bevel depth, the surface normal, the fake
 * refraction that bends the streak near the rim, the rim light and the glow.
 */
@RequiresApi(33)
private class GlassShader {

    private val shader = RuntimeShader(SRC)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).also { it.shader = shader }

    fun draw(
        c: Canvas, w: Float, h: Float,
        cx: Float, cy: Float, hx: Float, hy: Float, rad: Float, bevel: Float,
        time: Float, phase: Float, level: Float, work: Float, alpha: Float, bar: Float, panel: Float, shape: Float,
        pal: IntArray
    ) {
        shader.setFloatUniform("uCenter", cx, cy)
        shader.setFloatUniform("uHalf", hx, hy)
        shader.setFloatUniform("uTime", time)
        shader.setFloatUniform("uPhase", phase)
        shader.setFloatUniform("uLevel", level)
        shader.setFloatUniform("uWork", work)
        shader.setFloatUniform("uAlpha", alpha)
        shader.setFloatUniform("uBar", bar)
        shader.setFloatUniform("uPanel", panel)
        shader.setFloatUniform("uShape", shape)
        shader.setFloatUniform("uRadius", rad)
        shader.setFloatUniform("uBevel", bevel)
        c.drawRect(0f, 0f, w, h, paint)
    }

    private companion object {
        const val SRC = """
uniform float2 uCenter;
uniform float2 uHalf;
uniform float uTime;
uniform float uPhase;
uniform float uLevel;
uniform float uWork;
uniform float uAlpha;
uniform float uBar;
uniform float uPanel;
uniform float uShape;
uniform float uRadius;
uniform float uBevel;

float sdBox(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + r;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}

// the wake bubble: a smooth pebble, a superellipse with no flat sides. Not an exact
// distance, but divided by the field's slope it is close enough for the bevel and normals.
float sdPebble(float2 p) {
    float n = 2.35;
    float2 a = max(abs(p) / uHalf, float2(0.0001));
    float2 pw = pow(a, float2(n));
    float s = pw.x + pw.y;
    float f = pow(s, 1.0 / n);
    float2 grad = pow(s, 1.0 / n - 1.0) * pow(a, float2(n - 1.0)) / uHalf;
    return (f - 1.0) / max(length(grad), 0.0001);
}

// distance to the edge: negative inside. Pebble for the bubble, rounded box for the bar and answer.
float shapeD(float2 p) {
    float hh = uHalf.y;
    float2 q = p / hh;
    float d = mix(sdPebble(p), sdBox(p, uHalf, uRadius), uShape);
    // the edge barely ripples, a little more when you speak
    d += 0.006 * hh * (0.4 + uLevel) * (sin(q.x * 3.1 + uTime * 1.2) + sin(q.y * 4.0 + uTime * 1.5));
    return d;
}

float3 rainbow(float x) {
    return 0.5 + 0.5 * cos(6.2832 * (x + float3(0.0, 0.33, 0.67)));
}

half4 main(float2 fc) {
    float2 p = fc - uCenter;
    float hw = uHalf.x;
    float hh = uHalf.y;

    float d = shapeD(p);
    if (d > hh * 1.7) return half4(0.0);

    float e = 1.5;
    float2 g = float2(
        shapeD(p + float2(e, 0.0)) - shapeD(p - float2(e, 0.0)),
        shapeD(p + float2(0.0, e)) - shapeD(p - float2(0.0, e))
    );
    g = g / (length(g) + 0.00001);

    float T = min(hh * 0.45, uBevel);
    float depth = clamp(-d / T, 0.0, 1.0);
    float bevel = 1.0 - depth;
    float cov = smoothstep(-1.0, 1.0, -d);

    // fake refraction: the wave bends near the rim
    float k = T * 0.9 * pow(max(bevel, 0.0), 1.6);
    float2 r = float2((p.x + g.x * k) / hw, (p.y + g.y * k) / hh);

    // the wave: one fat band, white in the middle, rainbow toward the edges
    float amp = 0.10 + 0.24 * uLevel + 0.04 * uWork;
    float wy = amp * sin(r.x * 2.6 + uPhase) + 0.05 * uLevel * sin(r.x * 5.4 - uPhase * 1.6) + 0.22 + 0.38 * uBar;
    float dy = r.y - wy;
    float bw = 0.30 + 0.06 * uLevel;
    float band = exp(-(dy / bw) * (dy / bw));
    float coreW = exp(-(dy / (bw * 0.55)) * (dy / (bw * 0.55)));
    float3 rb = rainbow(r.x * 0.30 + dy * 0.9 + uTime * 0.06);
    // in search-bar mode the wave sinks to a faint streak; the glass keeps the bubble's dark top and clear bottom
    float waveK = (1.0 - 0.6 * uBar) * (1.0 - uPanel);
    float3 env = ((rb * 0.6 + 0.4) * (band * 0.75) + coreW * 0.55) * waveK;

    // light from the top left
    float ndl = dot(g, float2(-0.55, -0.80));
    float fres = pow(max(bevel, 0.0), 2.4);
    float rim = fres * (0.35 + 0.65 * max(ndl, 0.0) + 0.25 * max(-ndl, 0.0));
    float innerEdge = exp(-((depth - 0.10) / 0.05) * ((depth - 0.10) / 0.05)) * 0.3 * (0.4 + 0.6 * max(ndl, 0.0));

    // dark top: smoked glass that clears toward the wave
    // the answer panel stays dark for longer: its fade is centred 75% of the way down, not about half
    float shift = 0.40 * uBar + 0.40 * uPanel;
    float dark = smoothstep(0.60 + shift, -0.40 + shift, r.y);
    float3 col = float3(0.03, 0.03, 0.06) * 0.9
               + env * (1.0 - 0.92 * dark)
               + (rim + innerEdge) * (1.0 - 0.35 * dark);
    // still glossy dark, just a touch of see-through on the wake bubble
    float smoke = mix(0.95, 1.0, uShape);
    float a = clamp(0.10 + 0.90 * dark * smoke + 0.50 * fres + 0.60 * band * waveK, 0.0, 0.97) * cov;

    // soft rainbow glow outside the edge
    float og = exp(-max(d, 0.0) / (0.28 * min(hh, uBevel * 2.2))) * (0.08 + 0.35 * uLevel + 0.10 * uWork) * (1.0 - cov);
    float3 gc = rainbow(atan(p.y, p.x) / 6.2832 + uTime * 0.05);

    float3 outRgb = (col * a + gc * og * 0.7) * uAlpha;
    float outA = clamp(a + og * 0.7, 0.0, 1.0) * uAlpha;
    return half4(half3(clamp(outRgb, 0.0, 1.0)), half(outA));
}
"""
    }
}
