package `in`.yantra.assistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.max
import kotlinx.coroutines.delay
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import `in`.yantra.assistant.ChatMsg

/**
 * The summon screen: nothing but the glass bubble.
 *
 * The app you were in stays fully visible and unblurred behind it. The bubble
 * drops out of the top of the screen, spans it from side to side, and is the
 * face of Yantra: it swells with your voice and flows while it thinks.
 *
 * Tap the bubble and it slims into a "Search or Ask" bar with a keyboard, so you
 * can type instead of talk. The mic icon on the bar goes back to voice. Sending
 * a typed command returns to the bubble, which flows while Yantra works; replies
 * are spoken. Tap anywhere outside the glass to close.
 *
 * When Yantra answers, the glass morphs into a rounded panel holding the answer text and,
 * for looked-up answers, a result card with the source (tap it to read more). Tap the
 * panel to ask a follow-up in the bar.
 */
@Composable
fun AssistPanel(
    messages: List<ChatMsg>,
    listening: Boolean,
    busy: Boolean,
    transcript: String,
    notice: String,
    blurred: Boolean,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onOpenLink: (String) -> Unit,
    onClose: () -> Unit,
    /** Live voice level 0..1. A lambda, so reading it never recomposes the panel. */
    micLevel: () -> Float = { 0f }
) {
    // messages[0] is the app's greeting; it is not part of this summon.
    val last = messages.lastOrNull()
    val pending = messages.size > 1 && last?.fromUser == true

    val noRipple = remember { MutableInteractionSource() }
    val density = LocalDensity.current
    val statusPx = WindowInsets.statusBars.getTop(density)
    val statusDp = with(density) { statusPx.toDp() }

    var typing by remember { mutableStateOf(false) }
    // the answer the person has already tapped away, so it does not pop back
    var dismissed by remember { mutableLongStateOf(0L) }
    val answer = last?.takeIf {
        messages.size > 1 && !it.fromUser && it.text.isNotBlank() &&
            it.stamp != dismissed && !typing && !listening
    }
    // keep the last answer on screen while the glass folds back, so the text does not vanish first
    var lastAnswer by remember { mutableStateOf<ChatMsg?>(null) }
    LaunchedEffect(answer) {
        if (answer != null) lastAnswer = answer else { delay(260); lastAnswer = null }
    }
    val shown = answer ?: lastAnswer
    var contentPx by remember { mutableIntStateOf(0) }
    val contentAlpha by animateFloatAsState(
        targetValue = if (answer != null) 1f else 0f,
        animationSpec = tween(durationMillis = if (answer != null) 220 else 110, delayMillis = if (answer != null) 140 else 0),
        label = "answerAlpha"
    )
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    fun openBar() {
        // stop the mic first: typing and a live recogniser should not race
        if (listening) onMic()
        dismissed = last?.stamp ?: 0L
        typing = true
    }

    fun closeBar() {
        typing = false
        query = ""
        keyboard?.hide()
    }

    fun submit() {
        val text = query.trim()
        if (text.isEmpty()) return
        closeBar()
        onSend(text)
    }

    // Back collapses the bar first, then a second press closes the panel
    BackHandler(enabled = typing) { closeBar() }

    LaunchedEffect(typing) {
        if (typing) {
            focus.requestFocus()
            keyboard?.show()
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            // a tap anywhere outside the glass closes it
            .clickable(interactionSource = noRipple, indication = null) { onClose() }
    ) {
        // where the glass sits: it grows out of the status bar, like the blob does
        val glassTop = max(statusDp * 0.5f, 8.dp)
        val wakeHeight = maxWidth * 0.23f
        val barHeight = (GlassGeometry.BAR_HALF_HEIGHT_DP * 2f).dp

        val contentDp = with(density) { contentPx.toDp() }
        val boxHeight = if (shown != null) max(statusDp + 220.dp, glassTop + contentDp + 48.dp) else statusDp + 220.dp
        Box(modifier = Modifier.fillMaxWidth().height(boxHeight)) {
            AndroidView(
                factory = { ctx ->
                    GlassBlobView(ctx).apply {
                        palette = OrbClouds
                        contentDescription = "Yantra. Tap to type."
                    }
                },
                modifier = Modifier.fillMaxSize(),
                update = { v ->
                    v.topInset = statusPx.toFloat()
                    v.listening = listening
                    v.working = busy || pending
                    v.micLevel = micLevel()
                    v.bar = typing
                    v.answerHeight = if (answer != null) contentPx.toFloat() else 0f
                }
            )

            if (shown != null) {
                AnswerContent(
                    msg = shown,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(
                            top = glassTop,
                            start = GlassGeometry.EDGE_MARGIN_DP.dp,
                            end = GlassGeometry.EDGE_MARGIN_DP.dp
                        )
                        .fillMaxWidth()
                        .onSizeChanged { contentPx = it.height }
                        .graphicsLayer { alpha = contentAlpha }
                        // tap the panel for a follow-up; taps on the glass do not close the panel
                        .clickable(interactionSource = noRipple, indication = null) { if (answer != null) openBar() },
                    onOpenLink = onOpenLink
                )
            } else if (!typing) {
                // the whole bubble is one big button: tap to open the search bar
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(
                            top = glassTop,
                            start = GlassGeometry.EDGE_MARGIN_DP.dp,
                            end = GlassGeometry.EDGE_MARGIN_DP.dp
                        )
                        .fillMaxWidth(0.36f)
                        .height(wakeHeight)
                        .clickable(interactionSource = noRipple, indication = null) { openBar() }
                )
            } else {
                // the bar: text field on the left, mic on the right, inside the glass
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(
                            top = glassTop,
                            start = GlassGeometry.EDGE_MARGIN_DP.dp,
                            end = GlassGeometry.EDGE_MARGIN_DP.dp
                        )
                        .fillMaxWidth()
                        .height(barHeight)
                        // swallow taps on the glass so they do not close the panel
                        .clickable(interactionSource = noRipple, indication = null) { },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 26.dp, end = 8.dp)
                            .focusRequester(focus),
                        singleLine = true,
                        textStyle = TextStyle(
                            color = Color.White,
                            fontFamily = Bricolage,
                            fontWeight = FontWeight.Medium,
                            fontSize = 19.sp
                        ),
                        cursorBrush = SolidColor(Color.White),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { submit() }),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (query.isEmpty()) {
                                    Text(
                                        text = "Search or Ask",
                                        color = Color.White.copy(alpha = 0.55f),
                                        fontFamily = Bricolage,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 19.sp
                                    )
                                }
                                inner()
                            }
                        }
                    )
                    Box(
                        modifier = Modifier
                            .padding(end = 14.dp)
                            .size(36.dp)
                            .clickable(interactionSource = noRipple, indication = null) {
                                // back to voice: collapse the bar and open the mic
                                closeBar()
                                onMic()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = "Talk instead",
                            tint = Color.White.copy(alpha = 0.75f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * What sits on the answer panel: Yantra's reply in large type and, for looked-up answers,
 * a result card with the source. The glass behind it is sized to this column's height.
 */
@Composable
private fun AnswerContent(
    msg: ChatMsg,
    modifier: Modifier = Modifier,
    onOpenLink: (String) -> Unit
) {
    val noRipple = remember { MutableInteractionSource() }
    val hasCard = msg.source.isNotBlank() || msg.link.isNotBlank()
    Column(modifier = modifier) {
        Text(
            text = msg.text,
            color = Color.White,
            fontFamily = Bricolage,
            fontWeight = FontWeight.Medium,
            fontSize = 20.sp,
            lineHeight = 27.sp,
            maxLines = 6,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 24.dp)
        )
        if (hasCard) {
            Spacer(Modifier.height(16.dp))
            val title = msg.source.ifBlank { "Open link" }
            Row(
                modifier = Modifier
                    .padding(start = 14.dp, end = 14.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White.copy(alpha = 0.14f))
                    .clickable(interactionSource = noRipple, indication = null) {
                        if (msg.link.isNotBlank()) onOpenLink(msg.link)
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title.first().uppercase(),
                        color = Color.White,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.Medium,
                        fontSize = 18.sp
                    )
                }
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (msg.link.isNotBlank()) {
                        Text(
                            text = "Tap to read more",
                            color = Color.White.copy(alpha = 0.7f),
                            fontFamily = Bricolage,
                            fontSize = 14.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        } else {
            Spacer(Modifier.height(22.dp))
        }
    }
}
