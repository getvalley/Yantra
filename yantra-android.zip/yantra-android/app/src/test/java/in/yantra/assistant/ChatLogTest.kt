package `in`.yantra.assistant

import `in`.yantra.assistant.chat.ChatLog
import `in`.yantra.assistant.chat.ChatSummary
import `in`.yantra.assistant.chat.StoredMsg
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatLogTest {

    private val day = 86_400_000L

    @Test
    fun titleIsTheFirstThingYouSaidTrimmedOnAWord() {
        assertEquals("Turn the flashlight on", ChatLog.titleFor("turn the flashlight on"))
        val long = ChatLog.titleFor("what is the distance between the earth and the moon in kilometres right now please")
        assertTrue(long.endsWith("\u2026"))
        assertTrue(long.length <= 49)
        assertEquals("New chat", ChatLog.titleFor("   "))
    }

    @Test
    fun anEmptyChatIsNotSaved() {
        assertNull(ChatLog.snapshot(1, 0, emptyList()))
        assertNull(ChatLog.snapshot(1, 0, listOf(StoredMsg(false, "a note"))))
        val chat = ChatLog.snapshot(7, 99, listOf(StoredMsg(true, "battery"), StoredMsg(false, "82 percent")))!!
        assertEquals("Battery", chat.title)
        assertEquals(7L, chat.id)
    }

    @Test
    fun onlyTheNewestMessagesAreKept() {
        val many = (1..250).map { StoredMsg(it % 2 == 1, "m$it") }
        val kept = ChatLog.trim(many)
        assertEquals(ChatLog.MAX_MESSAGES, kept.size)
        assertEquals("m250", kept.last().text)
    }

    @Test
    fun previewIsYantrasLastReplyOnOneLine() {
        val p = ChatLog.previewOf(listOf(StoredMsg(true, "hi"), StoredMsg(false, "Hello\nthere"), StoredMsg(true, "bye")))
        assertEquals("Hello there", p)
    }

    @Test
    fun oldestChatsGoFirstWhenThereAreTooMany() {
        val map = (1L..105L).associateWith { it }
        assertEquals(listOf(1L, 2L, 3L, 4L, 5L), ChatLog.overflow(map).sorted())
        assertTrue(ChatLog.overflow((1L..100L).associateWith { it }).isEmpty())
    }

    @Test
    fun sectionsFollowTheCalendarDayNotTwentyFourHours() {
        val now = 10 * day + 1_000 // just after midnight UTC
        // two seconds ago, but on the previous calendar day
        assertEquals("Yesterday", ChatLog.dayLabel(now - 2_000, now, 0))
        // the same two seconds in a zone where it is still the same local day
        assertEquals("Today", ChatLog.dayLabel(now - 2_000, now, -3_600_000L))
    }

    @Test
    fun sectionLabels() {
        val now = 10 * day + 12 * 3_600_000L // noon
        assertEquals("Today", ChatLog.dayLabel(now - 3_600_000L, now, 0))
        assertEquals("Yesterday", ChatLog.dayLabel(now - day, now, 0))
        assertEquals("Previous 7 days", ChatLog.dayLabel(now - 4 * day, now, 0))
        assertEquals("Earlier", ChatLog.dayLabel(now - 20 * day, now, 0))
    }

    @Test
    fun searchMatchesTitleOrPreview() {
        val a = ChatSummary(1, "Flashlight", "Done.", 0, 2)
        val b = ChatSummary(2, "Weather", "It is sunny in Pune.", 0, 2)
        assertEquals(listOf(b), ChatLog.filter(listOf(a, b), "pune"))
        assertEquals(listOf(a, b), ChatLog.filter(listOf(a, b), " "))
    }
}
