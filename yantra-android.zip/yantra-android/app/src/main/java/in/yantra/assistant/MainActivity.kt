package `in`.yantra.assistant

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import `in`.yantra.assistant.speech.Listener
import `in`.yantra.assistant.ui.ChatScreen
import `in`.yantra.assistant.ui.ClockSheet
import `in`.yantra.assistant.ui.HistoryScreen
import `in`.yantra.assistant.ui.SettingsScreen
import `in`.yantra.assistant.util.AppSettings
import `in`.yantra.assistant.ui.YantraTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val vm: AssistantViewModel by viewModels()
    private var listener: Listener? = null
    private var pendingSpeech by mutableStateOf(false)

    /** True on a fresh launch while Yantra is not the phone's default digital assistant. */
    private var askDefault by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.RECORD_AUDIO] == true) {
            if (pendingSpeech) {
                pendingSpeech = false
                startListening()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        listener = Listener(
            this,
            onPartial = { vm.markListening(true) },
            onResult = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.send(it)
            },
            onError = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.addNote(it)
            },
            onTranscript = { vm.updateTranscript(it) }
        )

        // only on a fresh start, not when the screen is recreated by a rotation
        askDefault = savedInstanceState == null && !isDefaultAssistant()

        requestStartupPermissions()

        setContent {
            // isSystemInDarkTheme() is @Composable, so it has to be called in the
            // composable scope — not inside the mutableStateOf lambda.
            val systemDark = isSystemInDarkTheme()
            val dark = when (vm.themeMode) {
                AppSettings.THEME_DARK -> true
                AppSettings.THEME_LIGHT -> false
                else -> systemDark
            }
            var showSettings by rememberSaveable { mutableStateOf(false) }
            var showHistory by rememberSaveable { mutableStateOf(false) }

            // back closes Settings first, then History, then leaves the app
            BackHandler(enabled = showSettings) { showSettings = false }
            BackHandler(enabled = showHistory && !showSettings) { showHistory = false }

            // keep the system bars in step with the app palette
            LaunchedEffect(dark) {
                val paper = if (dark) 0xFF0A0807.toInt() else 0xFFF5F2EC.toInt()
                window.statusBarColor = paper
                window.navigationBarColor = paper
                window.decorView.setBackgroundColor(paper)
                WindowCompat.getInsetsController(window, window.decorView)
                    .isAppearanceLightStatusBars = !dark
                WindowCompat.getInsetsController(window, window.decorView)
                    .isAppearanceLightNavigationBars = !dark
            }

            // Yantra asked a yes or no question: once it has been spoken, listen for a few seconds
            LaunchedEffect(vm.followUp) {
                if (vm.followUp > 0) listenBriefly()
            }

            YantraTheme(darkTheme = dark, font = vm.fontChoice) {
              Box(modifier = Modifier.fillMaxSize()) {
                ChatScreen(
                    messages = vm.messages,
                    listening = vm.listening,
                    busy = vm.busy,
                    timerLeft = vm.timerLeft,
                    transcript = vm.transcript,
                    dark = dark,
                    onToggleTheme = {
                        vm.chooseTheme(if (dark) AppSettings.THEME_LIGHT else AppSettings.THEME_DARK)
                    },
                    onSend = { text -> if (text.isNotBlank()) vm.send(text) },
                    onMic = { toggleMic() },
                    onOpenSettings = {
                        vm.refreshVoices()
                        showSettings = true
                    },
                    onOpenHistory = {
                        vm.refreshHistory()
                        showHistory = true
                    },
                    onNewChat = { vm.newChat() }
                )
                if (showHistory) {
                    HistoryScreen(
                        chats = vm.history,
                        openId = vm.openChatId,
                        busy = vm.busy,
                        onBack = { showHistory = false },
                        onOpen = { id ->
                            vm.openChat(id)
                            showHistory = false
                        },
                        onNewChat = {
                            vm.newChat()
                            showHistory = false
                        },
                        onDelete = { vm.deleteChat(it) },
                        onClearAll = { vm.clearHistory() }
                    )
                }
                vm.clockSheet?.let { kind ->
                    ClockSheet(
                        kind = kind,
                        clockApp = vm.clockAppName,
                        onDismiss = { vm.dismissClockSheet() },
                        onStart = { vm.startFromClockSheet(it) }
                    )
                }
                if (askDefault) {
                    AlertDialog(
                        onDismissRequest = { askDefault = false },
                        title = { Text("Make Yantra your default digital assistant") },
                        text = { Text("Then the assistant gesture or button on your phone opens Yantra.") },
                        confirmButton = {
                            TextButton(onClick = {
                                askDefault = false
                                openAssistantSettings()
                            }) { Text("Open settings") }
                        },
                        dismissButton = {
                            TextButton(onClick = { askDefault = false }) { Text("Not now") }
                        }
                    )
                }
                if (showSettings) {
                    SettingsScreen(
                        language = vm.language,
                        themeMode = vm.themeMode,
                        fontChoice = vm.fontChoice,
                        speakReplies = vm.speakReplies,
                        smartReplies = vm.smartReplies,
                        lookupAnswers = vm.lookupAnswers,
                        rate = vm.speechRate,
                        pitch = vm.speechPitch,
                        voices = vm.voiceChoices,
                        selectedVoice = vm.selectedVoice,
                        languageHasVoices = vm.languageHasVoices,
                        shortcutCount = vm.shortcutCount,
                        name = vm.displayName,
                        useModel = vm.useModel,
                        modelStatus = vm.modelStatus,
                        modelInstalled = vm.modelInstalled,
                        modelBusy = vm.modelBusy,
                        memoryCount = vm.memoryCount,
                        memoryLines = vm.memoryLines,
                        preferValley = vm.preferValley,
                        valleyInstalled = vm.valleyInstalled,
                        onBack = { showSettings = false },
                        onLanguage = { vm.chooseLanguage(it) },
                        onTheme = { vm.chooseTheme(it) },
                        onFont = { vm.chooseFont(it) },
                        onSpeak = { vm.toggleSpeak(it) },
                        onSmart = { vm.toggleSmart(it) },
                        onLookup = { vm.toggleLookup(it) },
                        onRate = { vm.changeRate(it) },
                        onPitch = { vm.changePitch(it) },
                        onPreviewSpeech = { vm.previewSpeech() },
                        onVoice = { vm.chooseVoice(it) },
                        onInstallVoices = { vm.installVoices() },
                        onName = { vm.saveName(it) },
                        onForgetShortcuts = { vm.forgetShortcuts() },
                        onUseModel = { vm.toggleModel(it) },
                        onImportModel = { vm.importModel(it) },
                        onRemoveModel = { vm.removeModel() },
                        onForgetMemory = { vm.forgetMemory() },
                        onForgetMemoryAt = { vm.forgetMemoryAt(it) },
                        onPreferValley = { vm.togglePreferValley(it) }
                    )
                }
              }
            }
        }
    }

    private fun isDefaultAssistant(): Boolean {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val roles = getSystemService(RoleManager::class.java)
                if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                    return roles.isRoleHeld(RoleManager.ROLE_ASSISTANT)
                }
            } catch (_: Exception) { /* fall back to the system setting */ }
        }
        val current = try { Settings.Secure.getString(contentResolver, "assistant") } catch (_: Exception) { null }
        return current?.startsWith("$packageName/") == true
    }

    /** The phone's "Digital assistant app" page, or the default apps list, or Settings. */
    private fun openAssistantSettings() {
        val tries = listOf(
            Intent(Settings.ACTION_VOICE_INPUT_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (i in tries) {
            try {
                startActivity(i)
                return
            } catch (_: Exception) { /* try the next one */ }
        }
    }

    private fun toggleMic() {
        if (vm.listening) {
            listener?.stop()
            vm.markListening(false)
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSpeech = true
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        startListening()
    }

    private fun startListening() {
        vm.markListening(true)
        listener?.start()
    }

    /** After a yes or no question: wait for it to be spoken, open the mic, give up quietly if nobody talks. */
    private suspend fun listenBriefly() {
        vm.speaker.awaitDone()
        delay(350)
        if (vm.listening) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return
        startListening()
        delay(7_000)
        if (vm.listening && vm.transcript.isBlank()) {
            listener?.stop()
            vm.markListening(false)
        }
    }

    private fun requestStartupPermissions() {
        val wanted = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) wanted.add(Manifest.permission.BLUETOOTH_CONNECT)

        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    override fun onDestroy() {
        super.onDestroy()
        listener?.stop()
    }
}
