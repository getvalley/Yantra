package `in`.yantra.assistant.actions

import `in`.yantra.assistant.router.Parsed

/**
 * One line of "what I did", shown when the answer bubble is pulled down.
 *
 * kind: "message" (a text someone sent), "place" (directions / call buttons), "action" (anything else)
 * link: opened by the main button ("Directions", or a tap on the card). "app:<package>" opens an app.
 * link2: opened by the second button ("Call"), usually a tel: address.
 */
data class Card(
    val kind: String,
    val title: String,
    val subtitle: String = "",
    /** Small grey line: which app it came from, or the opening hours. */
    val detail: String = "",
    val time: String = "",
    val link: String = "",
    val link2: String = ""
)

/** Turns a finished command into the cards the pulled-down panel lists. Pure, so it is unit tested. */
object Trace {

    private val LABELS = mapOf(
        "open-app" to "Opened app", "home" to "Went home",
        "call" to "Calling", "call-contact" to "Calling",
        "sms" to "Text message", "sms-contact" to "Text message",
        "whatsapp" to "WhatsApp message", "whatsapp-contact" to "WhatsApp message",
        "alarm" to "Alarm", "alarm-ui" to "Alarm", "timer-ui" to "Timer", "alarm-list" to "Alarms",
        "alarm-cancel" to "Alarm cancelled", "remind" to "Reminder",
        "weather" to "Weather", "world-time" to "Time", "countdown" to "Countdown",
        "navigate" to "Directions", "nearby" to "Nearby", "search" to "Search",
        "wifi" to "Wi-Fi", "bluetooth" to "Bluetooth", "flashlight" to "Torch",
        "brightness" to "Brightness", "volume" to "Volume", "dnd" to "Do Not Disturb",
        "clipboard-copy" to "Copied", "clipboard-read" to "Clipboard",
        "read-notifications" to "Notifications", "recent-messages" to "Recent messages",
        "screen-copy" to "From your screen", "screen-read" to "Your screen",
        "calendar-add" to "Calendar", "agenda" to "Agenda", "email" to "Email",
        "list-add" to "List", "list-show" to "List", "play" to "Playing", "media" to "Media"
    )

    fun label(action: String): String =
        LABELS[action] ?: action.replaceFirstChar { it.uppercase() }

    /** The cards for one command: its own, or a single generic one built from its reply. */
    fun cardsFor(p: Parsed, r: ActResult): List<Card> {
        if (r.cards.isNotEmpty()) return r.cards
        if (r.text.isBlank()) return emptyList()
        return when (p.action) {
            "navigate", "nearby" -> listOf(
                Card("place", p.a.replaceFirstChar { it.uppercase() }, r.text.trimEnd('.'), link = r.link)
            )
            "say", "empty", "unknown", "help" -> emptyList()
            else -> listOf(Card("action", label(p.action), r.text.take(160), link = r.link))
        }
    }

    /** "12:23 pm" the way the card shows it. */
    fun clock(millis: Long): String {
        val c = java.util.Calendar.getInstance().apply { timeInMillis = millis }
        val h = c.get(java.util.Calendar.HOUR)
        val h12 = if (h == 0) 12 else h
        val m = c.get(java.util.Calendar.MINUTE)
        val ap = if (c.get(java.util.Calendar.AM_PM) == java.util.Calendar.AM) "am" else "pm"
        return "$h12:${m.toString().padStart(2, '0')} $ap"
    }
}
