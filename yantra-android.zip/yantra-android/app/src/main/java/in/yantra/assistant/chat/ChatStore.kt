package `in`.yantra.assistant.chat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Previous chats, kept on the phone and nowhere else.
 *
 * One small JSON file per chat in the app's private storage (backup is off in the manifest),
 * so the main app and the summon bubble can both save without overwriting each other.
 * A write goes to a temporary file and is renamed into place, so a crash never leaves half a chat.
 * Anything that cannot be read is skipped rather than breaking the list.
 */
class ChatStore(context: Context) {

    private val dir = File(context.applicationContext.filesDir, "chats").apply { mkdirs() }

    private fun fileOf(id: Long) = File(dir, "$id.json")

    @Synchronized
    fun write(chat: Chat) {
        val msgs = JSONArray()
        for (m in chat.messages) {
            msgs.put(
                JSONObject()
                    .put("u", m.fromUser)
                    .put("t", m.text)
                    .apply {
                        if (m.source.isNotEmpty()) put("s", m.source)
                        if (m.link.isNotEmpty()) put("l", m.link)
                    }
            )
        }
        val json = JSONObject()
            .put("id", chat.id)
            .put("title", chat.title)
            .put("updated", chat.updated)
            .put("messages", msgs)
        val tmp = File(dir, "${chat.id}.tmp")
        tmp.writeText(json.toString())
        if (!tmp.renameTo(fileOf(chat.id))) {
            fileOf(chat.id).writeText(json.toString())
            tmp.delete()
        }
        prune()
    }

    @Synchronized
    fun read(id: Long): Chat? = parse(fileOf(id))

    /** Newest first. */
    @Synchronized
    fun list(): List<ChatSummary> =
        files().mapNotNull { parse(it) }.map { ChatLog.summary(it) }.sortedByDescending { it.updated }

    @Synchronized
    fun delete(id: Long) {
        fileOf(id).delete()
    }

    @Synchronized
    fun clear() {
        files().forEach { it.delete() }
    }

    private fun files(): List<File> = dir.listFiles { f -> f.name.endsWith(".json") }?.toList().orEmpty()

    private fun prune() {
        val updated = HashMap<Long, Long>()
        for (f in files()) {
            val id = f.name.removeSuffix(".json").toLongOrNull() ?: continue
            updated[id] = f.lastModified()
        }
        ChatLog.overflow(updated).forEach { fileOf(it).delete() }
    }

    private fun parse(file: File): Chat? = try {
        val o = JSONObject(file.readText())
        val arr = o.getJSONArray("messages")
        val list = ArrayList<StoredMsg>(arr.length())
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            list.add(StoredMsg(m.optBoolean("u"), m.optString("t"), m.optString("s"), m.optString("l")))
        }
        Chat(o.getLong("id"), o.optString("title", "Chat"), o.optLong("updated"), list)
    } catch (e: Exception) {
        null
    }
}
