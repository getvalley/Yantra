package `in`.yantra.assistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import `in`.yantra.assistant.chat.ChatLog
import `in`.yantra.assistant.chat.ChatSummary

/*
 * The menu that slides in from the left: search, pinned chats, recent chats, See all, and at the
 * bottom a Chat button (new chat) with your initials beside it, which open the app's settings.
 */

private const val RECENT_SHOWN = 6

/** Two lines, the lower one shorter. Round caps, so it matches the soft icons. */
@Composable
internal fun MenuLinesIcon(modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.78f)) {
    Canvas(modifier = modifier.size(22.dp)) {
        val stroke = 2.3.dp.toPx()
        val pad = 3.dp.toPx()
        val y1 = size.height * 0.36f
        val y2 = size.height * 0.64f
        drawLine(color, Offset(pad, y1), Offset(size.width - pad, y1), stroke, StrokeCap.Round)
        drawLine(color, Offset(pad, y2), Offset(size.width * 0.58f, y2), stroke, StrokeCap.Round)
    }
}

private fun initialsOf(name: String): String {
    val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    return when {
        parts.isEmpty() -> ""
        parts.size == 1 -> parts[0].take(1).uppercase()
        else -> (parts.first().take(1) + parts.last().take(1)).uppercase()
    }
}

@Composable
fun ChatDrawer(
    visible: Boolean,
    chats: List<ChatSummary>,
    openId: Long,
    name: String,
    onClose: () -> Unit,
    onOpenChat: (Long) -> Unit,
    onNewChat: () -> Unit,
    onSeeAll: () -> Unit,
    onSettings: () -> Unit
) {
    BackHandler(enabled = visible) { onClose() }
    val noRipple = remember { MutableInteractionSource() }

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(tween(200)), exit = fadeOut(tween(180))) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.36f))
                    .clickable(interactionSource = noRipple, indication = null) { onClose() }
            )
        }
        AnimatedVisibility(
            visible = visible,
            enter = slideInHorizontally(tween(260)) { -it } + fadeIn(tween(160)),
            exit = slideOutHorizontally(tween(220)) { -it } + fadeOut(tween(160))
        ) {
            BoxWithConstraints(modifier = Modifier.fillMaxHeight()) {
                DrawerPanel(
                    width = (maxWidth * 0.84f).coerceAtMost(344.dp),
                    chats = chats,
                    openId = openId,
                    name = name,
                    onClose = onClose,
                    onOpenChat = onOpenChat,
                    onNewChat = onNewChat,
                    onSeeAll = onSeeAll,
                    onSettings = onSettings
                )
            }
        }
    }
}

@Composable
private fun DrawerPanel(
    width: androidx.compose.ui.unit.Dp,
    chats: List<ChatSummary>,
    openId: Long,
    name: String,
    onClose: () -> Unit,
    onOpenChat: (Long) -> Unit,
    onNewChat: () -> Unit,
    onSeeAll: () -> Unit,
    onSettings: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(searching) { if (searching) runCatching { focus.requestFocus() } }

    val matches = remember(chats, query) { ChatLog.filter(chats, query) }
    val pinned = matches.filter { it.pinned }
    val recent = matches.filter { !it.pinned }
    val shownRecent = if (searching && query.isNotBlank()) recent else recent.take(RECENT_SHOWN)

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(width)
            .plate(Squircle(topStart = 0.dp, topEnd = 32.dp, bottomEnd = 32.dp, bottomStart = 0.dp))
            .statusBarsPadding()
            .navigationBarsPadding()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        // ---- header: the name, and the search button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 16.dp, top = 14.dp, bottom = 10.dp)
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (searching) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .plate(Squircle(100.dp), strong = true)
                        .padding(start = 18.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f).focusRequester(focus),
                        textStyle = TextStyle(color = colors.onBackground, fontFamily = AppFont, fontWeight = FontWeight.Medium, fontSize = 16.sp),
                        cursorBrush = SolidColor(colors.primary),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (query.isEmpty()) Text("Search chats", color = colors.onSurfaceVariant, fontFamily = AppFont, fontSize = 16.sp)
                                inner()
                            }
                        }
                    )
                    IconAction(Icons.Rounded.Close, "Close search") { searching = false; query = "" }
                }
            } else {
                Text(
                    text = "Yantra",
                    style = MaterialTheme.typography.headlineMedium,
                    color = colors.onBackground,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .plate(Squircle(100.dp))
                        .clickable { searching = true }
                        .semantics { contentDescription = "Search chats" },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Search, null, tint = colors.onBackground.copy(alpha = 0.78f), modifier = Modifier.size(22.dp))
                }
            }
        }

        // ---- the chats
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            if (pinned.isNotEmpty()) {
                item { SectionLabel("Pinned") }
                items(pinned, key = { "p${it.id}" }) { c ->
                    ChatRow(c.title, selected = c.id == openId, icon = true) { onOpenChat(c.id) }
                }
                item { Spacer(Modifier.height(14.dp)) }
            }
            item { SectionLabel("Chats") }
            if (shownRecent.isEmpty()) {
                item {
                    Text(
                        text = if (query.isNotBlank()) "No chats match." else "Your chats will show up here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    )
                }
            }
            items(shownRecent, key = { "r${it.id}" }) { c ->
                ChatRow(c.title, selected = c.id == openId, icon = false) { onOpenChat(c.id) }
            }
            item {
                Text(
                    text = "See all\u2026",
                    style = MaterialTheme.typography.bodyLarge,
                    color = colors.onSurfaceVariant,
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .clip(Squircle(16.dp))
                        .clickable { onSeeAll() }
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                )
            }
        }

        // ---- bottom: Chat (new chat) and your initials (settings)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .height(56.dp)
                    .plate(Squircle(100.dp), tint = colors.primary)
                    .clickable { onNewChat() }
                    .padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Rounded.Edit, null, tint = colors.onPrimary, modifier = Modifier.size(22.dp))
                Text("Chat", style = MaterialTheme.typography.titleMedium, color = colors.onPrimary)
            }
            Spacer(Modifier.weight(1f))
            val initials = initialsOf(name)
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .plate(Squircle(100.dp))
                    .clickable { onSettings() }
                    .semantics { contentDescription = "Settings" },
                contentAlignment = Alignment.Center
            ) {
                if (initials.isEmpty()) {
                    Icon(Icons.Rounded.Settings, null, tint = colors.onBackground.copy(alpha = 0.78f), modifier = Modifier.size(24.dp))
                } else {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(Squircle(100.dp))
                            .background(Ember.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(initials, style = MaterialTheme.typography.labelLarge, color = colors.onBackground)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 12.dp, top = 10.dp, bottom = 6.dp)
    )
}

@Composable
private fun ChatRow(title: String, selected: Boolean, icon: Boolean, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(Squircle(16.dp))
            .background(if (selected) colors.surfaceVariant else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon) {
            Icon(Icons.Rounded.ChatBubbleOutline, null, tint = colors.onBackground.copy(alpha = 0.72f), modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(14.dp))
        }
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = colors.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ------------------------------------------------------------------ the chat's own menu (three dots)

/** Rename, pin and delete: settings for this chat, not for the app. */
@Composable
internal fun ChatMenu(
    saved: Boolean,
    pinned: Boolean,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onPin: () -> Unit,
    onDelete: () -> Unit
) {
    val dy = with(androidx.compose.ui.platform.LocalDensity.current) { 52.dp.roundToPx() }
    Popup(
        alignment = Alignment.TopEnd,
        offset = IntOffset(0, dy),
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Column(
                modifier = Modifier
                    .widthIn(min = 230.dp)
                    .plate(Squircle(24.dp))
                    .padding(vertical = 8.dp)
            ) {
                MenuItem(Icons.Rounded.DriveFileRenameOutline, "Rename chat", saved, onRename)
                MenuItem(Icons.Rounded.PushPin, if (pinned) "Unpin chat" else "Pin chat", saved, onPin)
                MenuItem(Icons.Rounded.Delete, "Delete chat", saved, onDelete, danger = true)
                if (!saved) {
                    Text(
                        text = "Say something first, then this chat can be changed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.widthIn(max = 230.dp).padding(horizontal = 18.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuItem(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit, danger: Boolean = false) {
    val colors = MaterialTheme.colorScheme
    val tint = if (danger) colors.error else colors.onBackground
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = if (enabled) 1f else 0.38f }
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint.copy(alpha = 0.78f), modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = tint)
    }
}

@Composable
internal fun RenameChatDialog(current: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    val colors = MaterialTheme.colorScheme
    var text by remember { mutableStateOf(current) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Dialog(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.plate(Squircle(32.dp)).padding(22.dp)) {
            Text("Rename chat", style = MaterialTheme.typography.titleLarge, color = colors.onBackground)
            Spacer(Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .plate(Squircle(100.dp), strong = true)
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it.take(60) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    textStyle = TextStyle(color = colors.onBackground, fontFamily = AppFont, fontWeight = FontWeight.Medium, fontSize = 17.sp),
                    cursorBrush = SolidColor(colors.primary)
                )
            }
            Spacer(Modifier.height(18.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Cancel",
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.onSurfaceVariant,
                    modifier = Modifier.clip(Squircle(100.dp)).clickable { onDismiss() }.padding(horizontal = 18.dp, vertical = 12.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    "Save",
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.onPrimary,
                    modifier = Modifier.plate(Squircle(100.dp), tint = colors.primary).clickable { onSave(text) }.padding(horizontal = 22.dp, vertical = 12.dp)
                )
            }
        }
    }
}

@Composable
internal fun DeleteChatDialog(title: String, onDismiss: () -> Unit, onDelete: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Dialog(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.plate(Squircle(32.dp)).padding(22.dp)) {
            Text("Delete this chat?", style = MaterialTheme.typography.titleLarge, color = colors.onBackground)
            Spacer(Modifier.height(8.dp))
            Text(
                "\u201C$title\u201D will be removed from this phone.",
                style = MaterialTheme.typography.bodyMedium,
                color = colors.onSurfaceVariant
            )
            Spacer(Modifier.height(18.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Cancel",
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.onSurfaceVariant,
                    modifier = Modifier.clip(Squircle(100.dp)).clickable { onDismiss() }.padding(horizontal = 18.dp, vertical = 12.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    "Delete",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    modifier = Modifier.plate(Squircle(100.dp), tint = colors.error).clickable { onDelete() }.padding(horizontal = 22.dp, vertical = 12.dp)
                )
            }
        }
    }
}
