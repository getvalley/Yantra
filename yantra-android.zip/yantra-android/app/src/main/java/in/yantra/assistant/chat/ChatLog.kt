package `in`.yantra.assistant.chat

import java.util.Locale

/** One saved line of a conversation. The app's greeting is never saved; it is re-added on open. */
data class StoredMsg(
    val fromUser: Boolean,
    val text: String,
    val source: String = "",
    val link: String = ""
)

/** A whole saved conversation. */
data class Chat(
    val id: Long,
    val title: String,
    val updated: Long,
    val messages: List<StoredMsg>
)

/** What the history list needs, without the messages. */
data class ChatSummary(
    val id: Long,
    val title: String,
    val preview: String,
    val updated: Long,
    val count: Int,
    val pinned: Boolean = false,
    /** True when the person gave the chat a name, so saving more lines must not rename it. */
    val renamed: Boolean = false
)

/**
 * The pure rules behind "previous chats": naming, trimming and grouping by day.
 * No Android imports, so it is unit-tested on the JVM. The file work is in [ChatStore].
 */
object ChatLog {

    const val MAX_CHATS = 100
    const val MAX_MESSAGES = 200
    private const val TITLE_CHARS = 48
    private const val PREVIEW_CHARS = 90
    private const val DAY_MS = 86_400_000L

    /** The first thing you said, trimmed on a word and capitalised: the chat's name. */
    fun titleFor(firstUserText: String): String {
        val t = firstUserText.replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return "New chat"
        val cut = if (t.length <= TITLE_CHARS) t
        else t.take(TITLE_CHARS).substringBeforeLast(' ', t.take(TITLE_CHARS)).trimEnd(',', '.', ';') + "\u2026"
        return cut.replaceFirstChar { it.titlecase(Locale.getDefault()) }
    }

    /** One line of Yantra's last reply, for under the title. */
    fun previewOf(messages: List<StoredMsg>): String {
        val last = messages.lastOrNull { !it.fromUser && it.text.isNotBlank() }?.text
            ?: messages.lastOrNull()?.text.orEmpty()
        val one = last.replace(Regex("\\s+"), " ").trim()
        return if (one.length <= PREVIEW_CHARS) one else one.take(PREVIEW_CHARS).substringBeforeLast(' ', one.take(PREVIEW_CHARS)) + "\u2026"
    }

    /** Keeps the newest [MAX_MESSAGES]. */
    fun trim(messages: List<StoredMsg>): List<StoredMsg> =
        if (messages.size <= MAX_MESSAGES) messages else messages.takeLast(MAX_MESSAGES)

    /** Builds what gets saved, or null while nothing has been said (an empty chat is not kept). */
    fun snapshot(id: Long, now: Long, messages: List<StoredMsg>): Chat? {
        val first = messages.firstOrNull { it.fromUser } ?: return null
        return Chat(id, titleFor(first.text), now, trim(messages))
    }

    fun summary(chat: Chat) = ChatSummary(chat.id, chat.title, previewOf(chat.messages), chat.updated, chat.messages.size)

    /** Which of [ids] (with their updated times) to drop to stay within [MAX_CHATS]: the oldest. */
    fun overflow(updatedById: Map<Long, Long>): List<Long> =
        if (updatedById.size <= MAX_CHATS) emptyList()
        else updatedById.entries.sortedBy { it.value }.take(updatedById.size - MAX_CHATS).map { it.key }

    /** "Today", "Yesterday", "Previous 7 days" or "Earlier", for the section headers. [zoneOffsetMs] is the device's UTC offset. */
    fun dayLabel(updated: Long, now: Long, zoneOffsetMs: Long): String {
        val days = Math.floorDiv(now + zoneOffsetMs, DAY_MS) - Math.floorDiv(updated + zoneOffsetMs, DAY_MS)
        return when {
            days <= 0 -> "Today"
            days == 1L -> "Yesterday"
            days < 8 -> "Previous 7 days"
            else -> "Earlier"
        }
    }

    /** Case-insensitive search over title and preview. A blank query keeps everything. */
    fun filter(all: List<ChatSummary>, query: String): List<ChatSummary> {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return all
        return all.filter { it.title.lowercase(Locale.ROOT).contains(q) || it.preview.lowercase(Locale.ROOT).contains(q) }
    }
}
