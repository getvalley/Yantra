package `in`.yantra.assistant.actions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Telephony
import androidx.core.content.ContextCompat
import `in`.yantra.assistant.service.NotificationListener

/** One message from any app, in the shape the answer needs. */
data class InboxMsg(
    val app: String,
    val pkg: String,
    /** Who it is from, as the phone shows it (a contact name when there is one). */
    val name: String,
    /** The raw number for texts, empty for chat apps. */
    val address: String,
    val text: String,
    val at: Long
)

/**
 * "What did mum say", "messages from dadu": the newest matching messages from the Messages app
 * (the SMS inbox) and from chat apps (their notifications), side by side, so the same words in
 * two apps both show up.
 */
object Inbox {

    private val STOP = setOf(
        "me", "my", "the", "a", "an", "from", "of", "to", "about", "on", "in", "her", "him", "his",
        "that", "has", "have", "said", "say", "says", "text", "texts", "message", "messages", "msg",
        "latest", "recent", "new", "last", "any", "whatsapp", "sms", "and", "or", "i", "did", "do"
    )

    private val CHAT_APPS = mapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "org.telegram.messenger" to "Telegram",
        "org.thoughtcrime.securesms" to "Signal"
    )
    private val SMS_APPS = mapOf(
        "com.google.android.apps.messaging" to "Messages",
        "com.samsung.android.messaging" to "Messages",
        "com.android.mms" to "Messages"
    )

    /** The words that must all appear (in the sender or the text) for a message to match. */
    fun terms(who: String): List<String> =
        who.lowercase().split(Regex("[^a-z0-9\u0900-\u097F]+")).filter { it.isNotEmpty() && it !in STOP }

    private fun last10(s: String): String = s.filter { it.isDigit() }.takeLast(10)

    /**
     * Newest first, at most [perApp] from each app so one busy chat cannot push the other out.
     * [numbers] are the contact's phone numbers: a text from one of them matches by number,
     * because the Messages app stores a number where WhatsApp has a name.
     */
    fun select(all: List<InboxMsg>, who: String, numbers: Set<String> = emptySet(), perApp: Int = 3, total: Int = 6): List<InboxMsg> {
        val ts = terms(who)
        val tails = numbers.map { last10(it) }.filter { it.length >= 7 }.toSet()
        val hits = all.filter { m ->
            if (ts.isEmpty()) return@filter true
            val hay = (m.name + " " + m.text).lowercase()
            ts.all { it in hay } || (m.address.isNotEmpty() && last10(m.address).let { a -> a.length >= 7 && a in tails })
        }
        val byApp = hits.groupBy { it.app }.values.flatMap { list -> list.sortedByDescending { it.at }.take(perApp) }
        return byApp.sortedByDescending { it.at }.take(total)
    }

    // ------------------------------------------------------------ the phone

    fun find(ctx: Context, who: String): Result {
        val numbers = HashSet<String>()
        val ts = terms(who)
        if (ts.isNotEmpty()) {
            Contacts.search(ctx, ts.joinToString(" ")).ifEmpty { Contacts.search(ctx, ts.first()) }
                .forEach { numbers.add(it.second) }
        }
        val smsOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        val all = ArrayList<InboxMsg>()
        if (smsOk) all.addAll(readSms(ctx))
        val listener = NotificationListener.instance != null
        val seen = synchronized(NotificationListener.history) { NotificationListener.history.toList() }
        for (n in seen) {
            val chat = CHAT_APPS[n.pkg]
            val sms = SMS_APPS[n.pkg]
            // with the SMS inbox readable, the Messages notifications would only repeat it
            if (chat == null && (sms == null || smsOk)) continue
            all.add(InboxMsg(chat ?: sms!!, n.pkg, n.title, "", n.text, n.at))
        }
        return Result(select(all, who, numbers), smsOk, listener)
    }

    data class Result(val messages: List<InboxMsg>, val smsReadable: Boolean, val listening: Boolean)

    private fun readSms(ctx: Context): List<InboxMsg> {
        val out = ArrayList<InboxMsg>()
        val pkg = try { Telephony.Sms.getDefaultSmsPackage(ctx) } catch (e: Exception) { null } ?: "com.google.android.apps.messaging"
        val names = HashMap<String, String>()
        try {
            ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
                null, null, Telephony.Sms.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 200) {
                    val addr = c.getString(0) ?: continue
                    val body = c.getString(1) ?: continue
                    val name = names.getOrPut(addr) { contactName(ctx, addr) ?: addr }
                    out.add(InboxMsg("Messages", pkg, name, addr, body, c.getLong(2)))
                }
            }
        } catch (e: Exception) {
            // no permission after all, or a phone with a locked-down provider
        }
        return out
    }

    private fun contactName(ctx: Context, number: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            ctx.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    /** The reply and cards for "what did mum say". */
    fun answer(ctx: Context, who: String): ActResult {
        val r = find(ctx, who)
        val label = who.trim()
        if (r.messages.isEmpty()) {
            val why = buildString {
                append(if (label.isEmpty()) "I found no recent messages." else "I found no recent messages matching \"$label\".")
                if (!r.smsReadable) append(" Allow Yantra to read texts in Settings to include the Messages app.")
                if (!r.listening) append(" Turn on notification access to include WhatsApp.")
            }
            return ActResult(why)
        }
        val cards = r.messages.map {
            Card("message", it.name, it.text, it.app, Trace.clock(it.at), link = "app:" + it.pkg)
        }
        val apps = r.messages.map { it.app }.distinct()
        val head = r.messages.first()
        val lead = if (apps.size > 1) "Found ${r.messages.size} messages across ${apps.joinToString(" and ")}."
        else "Found ${r.messages.size} in ${apps.first()}."
        val shown = r.messages.take(3).joinToString("\n") { "${it.name} (${it.app}, ${Trace.clock(it.at)}): ${it.text.take(120)}" }
        val spoken = "${head.name} said ${head.text.take(140)}, on ${head.app}." +
            if (r.messages.size > 1) " I have ${r.messages.size - 1} more on screen." else ""
        return ActResult("$lead\n$shown", spoken, cards = cards)
    }
}
