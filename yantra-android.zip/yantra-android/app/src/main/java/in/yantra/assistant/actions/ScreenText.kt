package `in`.yantra.assistant.actions

import `in`.yantra.assistant.router.Parsed

/**
 * On-screen intelligence, the pure half: understanding "copy this instagram caption to my notes"
 * and picking the caption out of the text the accessibility service read off the screen.
 */
object ScreenText {

    private val VERB = "copy|save|add|put|send|share|note|write|jot|store|clip|keep"
    private val NOUNS = "caption|text|number|link|url|email|address|description|bio|comment|message|paragraph|quote|post|screen|page"

    /** "this ..." always; "the ..." only before a noun that can only mean something on the screen. */
    private val GRAB = Regex(
        "^(?:please )?($VERB)(?: down)? (?:(?:this|that|these)\\b|(?:the |my )(?=(?:\\w+ )?(?:$NOUNS)\\b))\\s*(.*)$"
    )
    private val DEST = Regex("^(.*)\\b(?:to|into|in|onto)\\s+(?:my |the |a |an )?(.+)$")
    private val TRAIL = Regex("\\s*\\b(?:on|from|in) (?:the |my |this |that )?(?:screen|page|post)\\b")
    private val READ = Regex(
        "^(?:whats on|what is on|read|summarize|summarise|describe|scan)(?: what s on| whats on)? (?:my |the |this )?(?:screen|page)$"
    )

    /** screen-copy(a = what to take, b = where it goes) or screen-read; null when it is something else. */
    fun parse(t: String): Parsed? {
        if (READ.matches(t) || t == "read this" || t == "read this page") return Parsed("screen-read")
        val m = GRAB.matchEntire(t) ?: return null
        val verb = m.groupValues[1]
        var rest = m.groupValues[2].trim()
        var dest = ""
        rest = TRAIL.replace(rest, "").trim()
        DEST.matchEntire(rest)?.let {
            rest = it.groupValues[1].trim()
            dest = it.groupValues[2].trim()
        }
        rest = rest.removePrefix("down").trim()
        dest = dest.removeSuffix(" app").removeSuffix(" application").trim()
        if (dest.startsWith("the ")) dest = dest.removePrefix("the ")
        if (dest.isEmpty()) {
            dest = when (verb) {
                "copy", "clip" -> "clipboard"
                "send", "share" -> "share"
                else -> "notes"
            }
        }
        if (dest in setOf("clipboard", "clip board", "the clipboard")) dest = "clipboard"
        return Parsed("screen-copy", a = rest, b = dest)
    }

    private val UI_WORDS = setOf(
        "like", "likes", "comment", "comments", "share", "send", "reply", "follow", "following", "more",
        "home", "search", "reels", "profile", "back", "menu", "add", "save", "sponsored", "suggested",
        "message", "messages", "notifications", "story", "your story", "new", "ok", "cancel"
    )
    private val PHONE = Regex("\\+?\\d[\\d\\s().-]{6,}\\d")
    private val EMAIL = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val URL = Regex("(?:https?://|www\\.)\\S+")

    /** Visible text worth keeping: drops one-word buttons, counters and repeats. */
    fun clean(blocks: List<String>): List<String> {
        val seen = LinkedHashSet<String>()
        for (b in blocks) {
            val s = b.replace(Regex("\\s+"), " ").trim()
            if (s.length < 2) continue
            if (s.lowercase() in UI_WORDS) continue
            if (Regex("^[\\d.,]+[kKmM]?( likes| comments| views)?$").matches(s)) continue
            seen.add(s)
        }
        return seen.toList()
    }

    /** What was asked for out of [blocks]; null when the screen has no such thing. */
    fun extract(blocks: List<String>, what: String): String? {
        val kept = clean(blocks)
        if (kept.isEmpty()) return null
        val w = what.lowercase()
        val joined = kept.joinToString("\n")
        return when {
            Regex("\\b(?:phone|number|mobile|contact)\\b").containsMatchIn(w) -> PHONE.find(joined)?.value?.trim()
            Regex("\\b(?:email|mail)\\b").containsMatchIn(w) -> EMAIL.find(joined)?.value
            Regex("\\b(?:link|url|website)\\b").containsMatchIn(w) -> URL.find(joined)?.value
            w.isBlank() || Regex("\\b(?:screen|page|everything|all|text)\\b").containsMatchIn(w) && !w.contains("caption") ->
                joined
            else -> caption(kept)
        }
    }

    /** The caption is the longest passage, minus the account name Instagram puts in front of it. */
    fun caption(kept: List<String>): String? {
        var best = kept.maxByOrNull { it.length } ?: return null
        val first = best.substringBefore(' ')
        if (best.contains(' ') && Regex("^[A-Za-z0-9._]{2,30}$").matches(first) && kept.any { it == first }) {
            best = best.substringAfter(' ').trim()
        }
        best = best.replace(Regex("\\s*(?:\u2026|\\.\\.\\.)?\\s*more$"), "").trim()
        return best.ifEmpty { null }
    }
}
