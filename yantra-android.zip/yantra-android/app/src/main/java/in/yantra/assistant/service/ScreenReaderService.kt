package `in`.yantra.assistant.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/**
 * Reads the text on the screen when the person asks about it ("copy this caption to my notes").
 * Android's assistant API would need Yantra to be a full voice-interaction service; this reads
 * the same text with the accessibility API instead, and only when a command asks for it.
 */
class ScreenReaderService : AccessibilityService() {

    private var lastPkg = ""
    private var lastAt = 0L

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val now = System.currentTimeMillis()
        // keep a fresh copy of whatever app is behind the panel; a busy feed fires events constantly
        if (now - lastAt < 1200) return
        lastAt = now
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() == packageName) return
        val blocks = collect(root)
        if (blocks.isNotEmpty()) {
            lastPkg = pkg
            cached = Snapshot(pkg, blocks, now)
        }
    }

    /** The text of the app behind Yantra, read right now. */
    fun read(): Snapshot? {
        try {
            for (w in windows.sortedBy { if (it.type == AccessibilityWindowInfo.TYPE_APPLICATION) 0 else 1 }) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val root = w.root ?: continue
                val pkg = root.packageName?.toString() ?: continue
                if (pkg == packageName) continue
                val blocks = collect(root)
                if (blocks.isNotEmpty()) return Snapshot(pkg, blocks, System.currentTimeMillis())
            }
        } catch (e: Exception) {
            // fall through to the copy kept from the last event
        }
        return cached?.takeIf { System.currentTimeMillis() - it.at < 60_000 }
    }

    private fun collect(root: AccessibilityNodeInfo): List<String> {
        val out = ArrayList<String>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 45 || out.size > 400) return
            if (!n.isVisibleToUser || n.isPassword) return
            val text = n.text?.toString()?.trim().orEmpty()
            val desc = n.contentDescription?.toString()?.trim().orEmpty()
            when {
                text.isNotEmpty() -> out.add(text)
                desc.length >= 25 -> out.add(desc)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return out
    }

    data class Snapshot(val pkg: String, val blocks: List<String>, val at: Long)

    companion object {
        @Volatile
        var instance: ScreenReaderService? = null

        @Volatile
        var cached: Snapshot? = null
    }
}
