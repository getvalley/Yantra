package `in`.yantra.assistant.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.provider.AlarmClock

/**
 * Hands alarms and timers to whatever Clock app the phone uses (Google Clock,
 * Samsung Clock, OnePlus Clock...). Android's [AlarmClock] intents are the
 * standard way to do it, so the alarm rings and the timer counts down in the
 * Clock app itself, even when Yantra is closed.
 *
 * Every function returns false when no Clock app answers, so the caller can
 * fall back to Yantra's own alarm.
 */
object ClockApp {

    /** Longest timer the AlarmClock hand-off allows: 24 hours. */
    const val MAX_TIMER_SECONDS = 24 * 60 * 60

    /** Starts a timer. [seconds] is clamped to 1 second .. 24 hours. */
    fun setTimer(ctx: Context, seconds: Int, label: String?): Boolean {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceIn(1, MAX_TIMER_SECONDS))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (!label.isNullOrBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, label.trim())
        return start(ctx, intent)
    }

    /** Creates an alarm for the next time the clock reads [hour]:[minute]. */
    fun setAlarm(ctx: Context, hour: Int, minute: Int, label: String?): Boolean {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (!label.isNullOrBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, label.trim())
        return start(ctx, intent)
    }

    fun showAlarms(ctx: Context): Boolean = start(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS))

    fun showTimers(ctx: Context): Boolean = start(ctx, Intent(AlarmClock.ACTION_SHOW_TIMERS))

    /** Why the last hand-off failed, in words ("no app answers alarm requests", "Clock refused it: ..."). */
    @Volatile
    var lastProblem: String? = null
        private set

    /** The Clock app's name for the picker ("Clock"), or null when there is none. */
    fun appName(ctx: Context): String? {
        val pm = ctx.packageManager
        val info = handlers(ctx, Intent(AlarmClock.ACTION_SET_TIMER)).firstOrNull()
            ?: handlers(ctx, Intent(AlarmClock.ACTION_SET_ALARM)).firstOrNull()
            ?: return AppFinder.find(ctx, "clock")?.label
        return info.loadLabel(pm).toString().takeIf { it.isNotBlank() }
    }

    /** Every app that says it can take [intent], not just the one Android would pick. */
    private fun handlers(ctx: Context, intent: Intent): List<ResolveInfo> = try {
        ctx.packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo?.exported == true }
    } catch (e: Exception) {
        emptyList()
    }

    /**
     * Sends [intent] to a Clock app. Tries every app that handles it, one by one and by exact
     * component (so no chooser and no guessing), and retries with the Clock app's own screen
     * when it will not take a silent request. Records why it failed in [lastProblem].
     */
    private fun start(ctx: Context, intent: Intent): Boolean {
        lastProblem = null
        val problems = ArrayList<String>()
        val targets = ArrayList<Intent>()

        for (ri in handlers(ctx, intent)) {
            val ai = ri.activityInfo
            targets += Intent(intent).setClassName(ai.packageName, ai.name)
        }
        if (targets.isEmpty()) {
            // nothing declared itself: try the phone's clock app by name before giving up
            AppFinder.find(ctx, "clock")?.let { app ->
                val aimed = Intent(intent).setPackage(app.pkg)
                if (aimed.resolveActivity(ctx.packageManager) != null) targets += aimed
                else problems += "${app.label} does not take alarm requests"
            }
        }
        if (targets.isEmpty() && problems.isEmpty()) problems += "no app on this phone answers alarm requests"

        for (t in targets) {
            t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (tryStart(ctx, t, problems)) return true
            // some clocks refuse to skip their own screen: let them show it
            if (t.getBooleanExtra(AlarmClock.EXTRA_SKIP_UI, false)) {
                val withUi = Intent(t).putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                if (tryStart(ctx, withUi, problems)) return true
            }
        }
        lastProblem = problems.distinct().joinToString("; ").ifEmpty { "it was refused" }
        return false
    }

    private fun tryStart(ctx: Context, intent: Intent, problems: MutableList<String>): Boolean = try {
        ctx.startActivity(intent)
        true
    } catch (e: Exception) {
        val who = intent.component?.packageName ?: intent.`package` ?: "the Clock app"
        problems += "$who refused it (${e.javaClass.simpleName})"
        false
    }
}
