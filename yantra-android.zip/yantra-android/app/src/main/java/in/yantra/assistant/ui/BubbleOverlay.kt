package `in`.yantra.assistant.ui

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The little bubble that stays on screen while Yantra works in other apps: "Opening Maps\u2026",
 * "Sent to 9876543210 on WhatsApp." It is a window of its own, so it is still there after
 * Maps or WhatsApp comes to the front. It never takes touches, so it cannot get in the way.
 *
 * It needs "Display over other apps". Without it every call here does nothing and Yantra
 * works as before. A visible overlay is also what lets Android accept an app launch from
 * Yantra after another app has taken the screen (the second step of "open maps then ...").
 */
object BubbleOverlay {

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var label: TextView? = null
    private var blob: BlobView? = null
    private val hideLater = Runnable { hide() }

    fun canShow(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    /** Shows the bubble, or updates its text when it is already up. Stays until [finish] or [hide]. */
    fun show(ctx: Context, text: String) {
        if (!canShow(ctx)) return
        val app = ctx.applicationContext
        main.post {
            main.removeCallbacks(hideLater)
            try {
                if (root == null) attach(app)
                label?.text = text
                blob?.listening = true
            } catch (e: Exception) {
                // no window could be added (permission revoked meanwhile): carry on without it
                root = null
            }
        }
    }

    /** Last words, then the bubble goes after [holdMs]. */
    fun finish(ctx: Context, text: String, holdMs: Long = 3_500L) {
        if (!canShow(ctx)) return
        main.post {
            if (root == null) return@post
            label?.text = text
            blob?.listening = false
            main.removeCallbacks(hideLater)
            main.postDelayed(hideLater, holdMs)
        }
    }

    fun hide() {
        main.post {
            main.removeCallbacks(hideLater)
            val v = root ?: return@post
            try { wm?.removeView(v) } catch (e: Exception) { /* already gone */ }
            root = null
            label = null
            blob = null
        }
    }

    private fun attach(app: Context) {
        val dp = app.resources.displayMetrics.density
        val manager = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val orb = BlobView(app).apply { layoutParams = LinearLayout.LayoutParams((36 * dp).toInt(), (36 * dp).toInt()) }
        val words = TextView(app).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = (240 * dp).toInt()
            setPadding((10 * dp).toInt(), 0, (6 * dp).toInt(), 0)
        }
        val pill = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8 * dp).toInt(), (6 * dp).toInt(), (12 * dp).toInt(), (6 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(0xE6121214.toInt())
                cornerRadius = 28 * dp
            }
            elevation = 8 * dp
            addView(orb)
            addView(words)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (56 * dp).toInt()
        }
        manager.addView(pill, lp)
        wm = manager
        root = pill
        label = words
        blob = orb
    }
}
