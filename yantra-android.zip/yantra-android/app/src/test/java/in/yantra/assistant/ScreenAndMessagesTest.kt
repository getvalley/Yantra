package `in`.yantra.assistant

import `in`.yantra.assistant.actions.ActResult
import `in`.yantra.assistant.actions.Card
import `in`.yantra.assistant.actions.Inbox
import `in`.yantra.assistant.actions.InboxMsg
import `in`.yantra.assistant.actions.ScreenText
import `in`.yantra.assistant.actions.Trace
import `in`.yantra.assistant.mind.Reasoner
import `in`.yantra.assistant.router.Parsed
import `in`.yantra.assistant.router.Router
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenAndMessagesTest {

    private fun r(text: String) = Router.route(text, `in`.yantra.assistant.router.Ctx())

    // ---- 1. maths
    @Test
    fun rootsInEveryWording() {
        for (q in listOf("sqrt 9", "sqrt of 9", "sqrt(9)", "square root 9", "square root of 9", "root 9", "square root of nine", "\u221A9"))
            assertEquals("for \"$q\"", "It is 3.", Reasoner.evaluate(q))
        assertEquals("It is 3.", Reasoner.evaluate("cube root of 27"))
        assertEquals("It is 10.", Reasoner.evaluate("whats sqrt 25 times 2"))
    }

    // ---- 8. temperature
    @Test
    fun temperatureIsWeather() {
        for (q in listOf("whats the temperature", "what is the temperature", "temperature", "how hot is it outside")) {
            assertEquals("for \"$q\"", "weather", r(q).action)
            assertEquals("for \"$q\"", "temp", r(q).b)
        }
        assertEquals("pune", r("temperature in pune").a)
    }

    // ---- 7. channel after the name
    @Test
    fun messageOnWhatsApp() {
        val p = r("Message Dadu on WhatsApp Hi")
        assertEquals("whatsapp-contact", p.action)
        assertEquals("dadu", p.a)
        assertEquals("hi", p.b)
        assertEquals("whatsapp-contact", r("send hi to dadu on whatsapp").action)
        assertEquals("sms-contact", r("text mum via sms saying I am late").action)
        assertEquals("i am late", r("text mum via sms saying I am late").b)
        // the old forms still work
        assertEquals("sms-contact", r("text mom saying hello").action)
    }

    // ---- 6. recent messages
    @Test
    fun askingForRecentMessages() {
        assertEquals("recent-messages", r("what did mum say").action)
        assertEquals("mum", r("what did mum say").a)
        assertEquals("recent-messages", r("messages from mum").action)
        assertEquals("recent-messages", r("did dadu text me").action)
        // not about the phone
        assertTrue(r("what did you say").action != "recent-messages")
    }

    @Test
    fun sameWordsInBothAppsShowBoth() {
        val all = listOf(
            InboxMsg("WhatsApp", "com.whatsapp", "Mum", "", "The black currant one", 300),
            InboxMsg("Messages", "msg", "+919812345678", "+919812345678", "Get the cordial please", 200),
            InboxMsg("WhatsApp", "com.whatsapp", "Dadu", "", "hi", 100)
        )
        val hits = Inbox.select(all, "mum", setOf("+91 98123 45678"))
        assertEquals(listOf("WhatsApp", "Messages"), hits.map { it.app })
        val byWord = Inbox.select(all, "cordial")
        assertEquals(1, byWord.size)
        assertEquals("Messages", byWord[0].app)
    }

    // ---- 3. on-screen intelligence
    @Test
    fun copyThisCaptionToNotes() {
        val p = r("Copy this Instagram caption to my notes")
        assertEquals("screen-copy", p.action)
        assertEquals("instagram caption", p.a)
        assertEquals("notes", p.b)
        assertEquals("notes", r("copy this instagram caption to my notes app").b)
        assertEquals("clipboard", r("copy this").b)
        assertEquals("notes", r("note this down").b)
        assertEquals("screen-read", r("whats on my screen").action)
        // plain clipboard copy of typed words is untouched
        assertEquals("clipboard-copy", r("copy the quick brown fox").action)
    }

    @Test
    fun captionPickedFromTheScreen() {
        val screen = listOf(
            "Home", "chef_amy", "Sponsored", "1,204 likes",
            "chef_amy Slow Sunday pasta with garlic and chilli. Recipe in the link. \u2026 more",
            "View all 32 comments", "Like", "Share"
        )
        assertEquals(
            "Slow Sunday pasta with garlic and chilli. Recipe in the link.",
            ScreenText.extract(screen, "instagram caption")
        )
        assertEquals("+91 98765 43210", ScreenText.extract(listOf("Call me", "+91 98765 43210"), "number"))
        assertNull(ScreenText.extract(listOf("Like", "Share"), "caption"))
    }

    // ---- 2. what it did
    @Test
    fun cardsForTheBubble() {
        val own = Card("message", "Mum", "The black currant one", "WhatsApp", "12:23 pm")
        assertEquals(listOf(own), Trace.cardsFor(Parsed("recent-messages"), ActResult("x", cards = listOf(own))))
        val made = Trace.cardsFor(Parsed("remind", a = "buy cordial"), ActResult("Okay, I will remind you."))
        assertEquals("Reminder", made[0].title)
        assertTrue(Trace.cardsFor(Parsed("say"), ActResult("Hey.")).isEmpty())
        assertNotNull(Trace.clock(0L))
    }
}
