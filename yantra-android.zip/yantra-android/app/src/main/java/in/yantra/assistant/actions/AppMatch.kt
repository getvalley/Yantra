package `in`.yantra.assistant.actions

import java.util.Locale

/** A launchable app: what the launcher shows, and its package. */
data class App(val label: String, val pkg: String)

/**
 * Works out which installed app a spoken name means, without a list of known
 * package names. It only looks at what is installed: the label the launcher
 * shows and the package id. Nothing here touches Android, so it is unit tested.
 *
 * Handles what speech recognition and people actually produce: "what's app",
 * "you tube", "gmail app", "insta", "whatsap".
 */
object AppMatch {

    /** Spoken shorthands. These are words, not packages: they only steer the label match. */
    private val NICKNAMES = mapOf(
        "yt" to "youtube",
        "insta" to "instagram",
        "ig" to "instagram",
        "wa" to "whatsapp",
        "fb" to "facebook",
        "gpay" to "google pay",
        "tg" to "telegram",
        "gmaps" to "maps",
        "google maps" to "maps",
        "chrome browser" to "chrome",
        "twitter" to "x",
        "yt music" to "youtube music"
    )

    private val FILLER = setOf("the", "app", "application", "my", "please", "a")

    /** Lowercase letters and digits only, any script: "What's App" -> "whatsapp". */
    fun norm(s: String): String =
        s.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), "")

    /** The spoken name without filler words, after nickname expansion. */
    fun clean(spoken: String): String {
        val words = spoken.lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N} ]+"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() && it !in FILLER }
        val joined = words.joinToString(" ")
        return NICKNAMES[joined] ?: joined
    }

    /**
     * Every app that plausibly matches [spoken], best first. A score of 40 or more is a
     * confident match; lower scores are only good enough for "did you mean".
     */
    fun rank(apps: List<App>, spoken: String): List<Pair<App, Int>> {
        val q = clean(spoken)
        val nq = norm(q)
        if (nq.isEmpty()) return emptyList()
        val qTokens = q.split(" ").filter { it.isNotEmpty() }
        return apps
            .map { it to score(it, nq, qTokens) }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<App, Int>> { it.second }.thenBy { it.first.label.length })
    }

    /** The best app, or null when nothing matches with confidence. */
    fun best(apps: List<App>, spoken: String): App? =
        rank(apps, spoken).firstOrNull()?.takeIf { it.second >= CONFIDENT }?.first

    /** Up to [max] close-but-not-sure names, for "I could not find X. Did you mean ...?" */
    fun suggestions(apps: List<App>, spoken: String, max: Int = 3): List<String> =
        rank(apps, spoken).filter { it.second >= MAYBE }.map { it.first.label }.distinct().take(max)

    const val CONFIDENT = 40
    const val MAYBE = 25

    private fun score(app: App, nq: String, qTokens: List<String>): Int {
        val nl = norm(app.label)
        if (nl.isEmpty()) return 0
        val pkgTail = app.pkg.lowercase(Locale.ROOT).split('.').drop(1).joinToString("")
        var best = 0

        fun offer(v: Int) { if (v > best) best = v }

        when {
            nl == nq -> offer(100)
            nl.startsWith(nq) -> offer(80 - (nl.length - nq.length).coerceAtMost(30))
            nl.contains(nq) && nq.length >= 3 -> offer(60 - (nl.length - nq.length).coerceAtMost(20))
            nq.contains(nl) && nl.length >= 4 -> offer(50)
        }

        // every word said appears somewhere in the label ("music youtube" -> "YouTube Music")
        if (qTokens.size > 1) {
            val labelWords = app.label.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+"))
            if (qTokens.all { t -> labelWords.any { it.startsWith(t) } }) offer(55)
        }

        // the package id, for apps whose label differs from what people say ("com.whatsapp")
        if (nq.length >= 4 && pkgTail.contains(nq)) offer(42)

        // misheard or mistyped: no slips on short names, one on mid-length, two on long ones
        if (nq.length >= 4) {
            val allowed = when {
                nq.length <= 5 -> 0
                nq.length <= 8 -> 1
                else -> 2
            }
            val d = distance(nl, nq)
            if (d <= allowed) offer(48 - d * 4)
            // also against the first word of the label ("Gmail Go" vs "gmal")
            val first = norm(app.label.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+")).firstOrNull() ?: "")
            if (first.length >= 4) {
                val d2 = distance(first, nq)
                if (d2 <= allowed) offer(44 - d2 * 4)
            }
            // loosely similar: worth suggesting, not worth opening
            if (best == 0 && d <= allowed + 2) offer(28 - d)
        }
        return best
    }

    /** Edit distance between two short strings. */
    internal fun distance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }
}
