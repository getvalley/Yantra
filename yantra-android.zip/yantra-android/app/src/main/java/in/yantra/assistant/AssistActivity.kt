package `in`.yantra.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import `in`.yantra.assistant.actions.App
import `in`.yantra.assistant.actions.AppFinder
import `in`.yantra.assistant.actions.AppMatch
import `in`.yantra.assistant.router.Ctx
import `in`.yantra.assistant.router.Router
import `in`.yantra.assistant.ui.AppHit
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import `in`.yantra.assistant.speech.Listener
import `in`.yantra.assistant.ui.AssistPanel
import `in`.yantra.assistant.ui.ClockSheet
import `in`.yantra.assistant.ui.YantraTheme
import `in`.yantra.assistant.util.AppSettings
import java.util.function.Consumer
import kotlinx.coroutines.delay

/**
 * The wake-up screen: opens on top of whatever app you were in, leaves it fully visible,
 * drops a blob of liquid glass out of the top of the screen (see GlassBlobView),
 * starts listening immediately, and disappears when dismissed.
 *
 * Summoned from the Quick Settings tile, or by the system assistant gesture
 * once Yantra is set as the default assistant app (this activity declares
 * ACTION_ASSIST for exactly that).
 */
class AssistActivity : ComponentActivity() {

    private val vm: AssistantViewModel by viewModels()
    private var listener: Listener? = null


    /** Live voice level for the glass blob. Read inside its draw, so it never recomposes the panel. */
    private var micLevel by mutableFloatStateOf(0f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // draw under the status and navigation bars: the scrim reaches every edge
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        listener = Listener(
            this,
            onPartial = { vm.markListening(true) },
            onResult = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.send(it)
            },
            onError = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.showNotice(it)
            },
            onTranscript = { vm.updateTranscript(it) },
            onLevel = { micLevel = it }
        )

        setContent {
            val systemDark = isSystemInDarkTheme()
            val dark = when (vm.themeMode) {
                AppSettings.THEME_DARK -> true
                AppSettings.THEME_LIGHT -> false
                else -> systemDark
            }
            // Yantra asked a yes or no question: once it has been spoken, listen for a few seconds
            LaunchedEffect(vm.followUp) {
                if (vm.followUp > 0) listenBriefly()
            }
            YantraTheme(darkTheme = dark) {
                AssistPanel(
                    messages = vm.messages,
                    listening = vm.listening,
                    busy = vm.busy,
                    transcript = vm.transcript,
                    notice = vm.notice,
                    blurred = false,
                    micLevel = { micLevel },
                    onSend = { text -> if (text.isNotBlank()) vm.send(text) },
                    onMic = { startListening() },
                    onOpenLink = { openLink(it) },
                    onOpenApp = { openApp() },
                    appHint = { appHint(it) },
                    onLaunchApp = { launchApp(it) },
                    onClose = { dismiss() }
                )
                // "set a timer" with no time: the small picker, saved to the Clock app
                vm.clockSheet?.let { kind ->
                    ClockSheet(
                        kind = kind,
                        clockApp = vm.clockAppName,
                        onDismiss = { vm.dismissClockSheet() },
                        onStart = { vm.startFromClockSheet(it) }
                    )
                }
            }
        }

        // a command handed over by Valley runs straight away; otherwise open listening
        val handed = commandFrom(intent)
        if (handed != null) vm.send(handed) else startListening()
    }

    /** "Yantra, ..." said inside Valley arrives here as text. */
    private fun commandFrom(source: Intent?): String? {
        if (source?.action != COMMAND_ACTION) return null
        return source.getStringExtra(COMMAND_TEXT)?.trim()?.takeIf { it.isNotEmpty() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        commandFrom(intent)?.let { vm.send(it) }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            vm.showNotice("Microphone permission is off. Open Yantra once to allow it, or type below.")
            return
        }
        if (vm.listening) {
            listener?.stop()
            vm.markListening(false)
            vm.updateTranscript("")
            return
        }
        // don't let our own voice reply leak into the recogniser
        vm.speaker.stop()
        vm.updateTranscript("")
        vm.markListening(true)
        listener?.start()
    }

    /** Swipe down on the bubble: open the full Yantra app and leave the wake-up screen. */
    private fun openApp() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
            dismiss()
        } catch (e: Exception) {
            // could not open the app: stay where we are
        }
    }

    /**
     * After a yes or no question: wait for it to finish being spoken, open the mic for
     * [FOLLOW_UP_MS], and if nobody starts talking, stop and leave the question on screen.
     */
    private suspend fun listenBriefly() {
        vm.speaker.awaitDone()
        // let the speaker let go of the audio before the recogniser opens, or it starts deaf
        delay(HANDOFF_MS)
        if (vm.listening) return
        startListening()
        delay(FOLLOW_UP_MS)
        if (vm.listening && vm.transcript.isBlank()) {
            listener?.stop()
            micLevel = 0f
            vm.markListening(false)
            vm.updateTranscript("")
        }
    }

    /** Links from the answer panel and its cards: web pages, "tel:" numbers, and "app:<package>". */
    private fun openLink(url: String) {
        try {
            val intent = when {
                url.startsWith("app:") ->
                    packageManager.getLaunchIntentForPackage(url.removePrefix("app:")) ?: return
                url.startsWith("tel:") -> Intent(Intent.ACTION_DIAL, Uri.parse(url))
                else -> Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            dismiss()
        } catch (e: Exception) {
            // nothing to open it with: stay where we are
        }
    }

    // ------------------------------------------------- typing an app's name

    private val installedApps by lazy { AppFinder.installed(this) }
    private val iconCache = HashMap<String, ImageBitmap>()

    /**
     * The app that the typed text is clearly the name of, so the bar can show "WhatsApp \u2014 Open".
     * Text the router understands as a command ("weather", "battery") is never taken for an app.
     */
    private fun appHint(typed: String): AppHit? {
        val text = typed.trim()
        if (text.isEmpty() || text.split(Regex("\\s+")).size > 3) return null
        if (Router.routeAll(text, Ctx()).firstOrNull()?.action != "unknown") return null
        val (app, score) = AppMatch.rank(installedApps, text).firstOrNull() ?: return null
        if (score < 60 || (text.length < 2 && score < 100)) return null
        val icon = iconCache[app.pkg] ?: try {
            packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap()
                .also { iconCache[app.pkg] = it }
        } catch (e: Exception) {
            null
        }
        return AppHit(app.label, app.pkg, icon)
    }

    private fun launchApp(hit: AppHit) {
        val intent = AppFinder.launchIntent(this, App(hit.label, hit.pkg)) ?: return
        try {
            startActivity(intent)
            dismiss()
        } catch (e: Exception) {
            // the app would not start: stay where we are
        }
    }

    private companion object {
        const val COMMAND_ACTION = "in.yantra.assistant.action.COMMAND"
        const val COMMAND_TEXT = "in.yantra.assistant.extra.TEXT"
        const val FOLLOW_UP_MS = 7_000L
        const val HANDOFF_MS = 350L
    }

    private fun dismiss() {
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        super.onDestroy()
        listener?.stop()
    }
}
