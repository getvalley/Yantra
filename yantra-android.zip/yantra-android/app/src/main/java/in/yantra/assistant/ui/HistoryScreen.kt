package `in`.yantra.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.yantra.assistant.chat.ChatLog
import `in`.yantra.assistant.chat.ChatSummary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** One line of the list: a day header or a chat. */
private sealed class Row_ {
    data class Header(val label: String) : Row_()
    data class Item(val chat: ChatSummary) : Row_()
}

/**
 * Previous chats, saved on this phone only. Tap one to carry on in it. Same glass as the chat screen.
 */
@Composable
fun HistoryScreen(
    chats: List<ChatSummary>,
    openId: Long,
    busy: Boolean,
    onBack: () -> Unit,
    onOpen: (Long) -> Unit,
    onNewChat: () -> Unit,
    onDelete: (Long) -> Unit,
    onClearAll: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf<ChatSummary?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val offset = TimeZone.getDefault().getOffset(now).toLong()
    val rows = remember(chats, query) {
        val out = ArrayList<Row_>()
        var last = ""
        for (c in ChatLog.filter(chats, query)) {
            val label = ChatLog.dayLabel(c.updated, now, offset)
            if (label != last) {
                out.add(Row_.Header(label))
                last = label
            }
            out.add(Row_.Item(c))
        }
        out
    }

    Box(modifier = Modifier.fillMaxSize()) {
        PaperBackdrop(Modifier.fillMaxSize())
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            // ---- header bubble: back, title, new chat
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 4.dp)
                    .plate(Squircle(32.dp))
                    .padding(start = 6.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconAction(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
                Text(
                    text = "Chats",
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.onBackground,
                    modifier = Modifier.weight(1f).padding(start = 6.dp)
                )
                Row(
                    modifier = Modifier
                        .clip(ButtonShape)
                        .background(colors.primary)
                        .clickable(enabled = !busy) { onNewChat() }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, tint = colors.onPrimary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("New chat", style = MaterialTheme.typography.labelLarge, color = colors.onPrimary)
                }
            }

            // ---- search
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .height(52.dp)
                    .plate(ButtonShape),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Rounded.Search,
                    contentDescription = null,
                    tint = colors.onBackground.copy(alpha = 0.5f),
                    modifier = Modifier.padding(start = 18.dp).size(20.dp)
                )
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                    singleLine = true,
                    textStyle = TextStyle(
                        color = colors.onBackground,
                        fontFamily = AppFont,
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp
                    ),
                    cursorBrush = SolidColor(colors.primary),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) {
                                Text(
                                    "Search chats",
                                    color = colors.onBackground.copy(alpha = 0.5f),
                                    fontFamily = AppFont,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 16.sp
                                )
                            }
                            inner()
                        }
                    }
                )
                if (query.isNotEmpty()) {
                    Box(
                        modifier = Modifier.padding(end = 6.dp).size(40.dp).clip(ButtonShape).clickable { query = "" },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear search", tint = colors.onBackground, modifier = Modifier.size(18.dp))
                    }
                }
            }

            if (busy) {
                Text(
                    text = "Yantra is working on a reply. Open a chat once it is done.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 26.dp, vertical = 4.dp)
                )
            }

            if (rows.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(modifier = Modifier.padding(horizontal = 40.dp)) {
                        Text(
                            text = if (chats.isEmpty()) "No chats yet." else "Nothing matches.",
                            style = MaterialTheme.typography.headlineMedium,
                            color = colors.onBackground
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = if (chats.isEmpty()) "What you ask Yantra shows up here. Chats are saved only on this phone."
                            else "Try a different word.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(rows) { row ->
                        when (row) {
                            is Row_.Header -> Text(
                                text = row.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = colors.onSurfaceVariant,
                                modifier = Modifier.padding(start = 12.dp, top = 12.dp, bottom = 0.dp)
                            )
                            is Row_.Item -> ChatCard(
                                chat = row.chat,
                                current = row.chat.id == openId,
                                now = now,
                                offset = offset,
                                enabled = !busy,
                                onOpen = { onOpen(row.chat.id) },
                                onDelete = { confirmDelete = row.chat }
                            )
                        }
                    }
                    item {
                        if (chats.isNotEmpty()) {
                            Text(
                                text = "Clear all chats",
                                style = MaterialTheme.typography.labelLarge,
                                color = colors.error,
                                modifier = Modifier
                                    .padding(vertical = 14.dp, horizontal = 12.dp)
                                    .clip(ButtonShape)
                                    .clickable { confirmClear = true }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }

    confirmDelete?.let { chat ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete this chat?") },
            text = { Text(chat.title) },
            confirmButton = {
                TextButton(onClick = { confirmDelete = null; onDelete(chat.id) }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all chats?") },
            text = { Text("Every saved chat is removed from this phone. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; onClearAll() }) { Text("Clear all") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ChatCard(
    chat: ChatSummary,
    current: Boolean,
    now: Long,
    offset: Long,
    enabled: Boolean,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .plate(
                Squircle(26.dp),
                tint = if (current) Ember.copy(alpha = if (isDarkScheme()) 0.18f else 0.08f) else androidx.compose.ui.graphics.Color.Transparent
            )
            .clickable(enabled = enabled) { onOpen() }
            .padding(start = 18.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = chat.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Text(
                    text = timeLabel(chat.updated, now, offset),
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.onSurfaceVariant,
                    modifier = Modifier.padding(start = 10.dp)
                )
            }
            if (chat.preview.isNotEmpty()) {
                Text(
                    text = chat.preview,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
        }
        Box(
            modifier = Modifier.size(44.dp).clip(ButtonShape).clickable { onDelete() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Delete,
                contentDescription = "Delete chat",
                tint = colors.onBackground.copy(alpha = 0.55f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

private fun timeLabel(updated: Long, now: Long, offset: Long): String {
    val pattern = when (ChatLog.dayLabel(updated, now, offset)) {
        "Today", "Yesterday" -> "h:mm a"
        "Previous 7 days" -> "EEE"
        else -> "d MMM"
    }
    return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(updated))
}
