package `in`.yantra.assistant.service

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Captures notifications so "read my notifications" can answer, and keeps a longer history of
 * chat messages (WhatsApp and friends have no API to read, only the notification they post).
 */
class NotificationListener : NotificationListenerService() {

    @Suppress("DEPRECATION")
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        val extras = n.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val pkg = sbn.packageName ?: ""
        val at = if (sbn.postTime > 0) sbn.postTime else System.currentTimeMillis()
        synchronized(cache) {
            cache.removeAll { it.pkg == pkg && it.title == title }
            cache.add(0, Item(pkg, title, text, at))
            while (cache.size > 30) cache.removeAt(cache.size - 1)
        }

        // the chat history skips the "3 new messages" summary line apps post on top of each chat
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val found = ArrayList<Item>()
        try {
            extras.getParcelableArray("android.messages")?.forEach { raw ->
                val b = raw as? Bundle ?: return@forEach
                val body = b.getCharSequence("text")?.toString().orEmpty()
                if (body.isBlank()) return@forEach
                val time = b.getLong("time", at).let { if (it > 0) it else at }
                val sender = b.getCharSequence("sender")?.toString().orEmpty()
                found.add(Item(pkg, title, body, time, sender))
            }
        } catch (e: Exception) {
            // an app with an odd bundle: fall back to the single line below
        }
        if (found.isEmpty() && text.isNotBlank()) found.add(Item(pkg, title, text, at))
        synchronized(history) {
            for (item in found) {
                if (history.none { it.pkg == item.pkg && it.title == item.title && it.text == item.text }) {
                    history.add(0, item)
                }
            }
            while (history.size > 300) history.removeAt(history.size - 1)
        }
    }

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    data class Item(
        val pkg: String,
        val title: String,
        val text: String,
        val at: Long = System.currentTimeMillis(),
        /** Who in the chat said it, when the app tells us (group chats). */
        val sender: String = ""
    )

    companion object {
        val cache: MutableList<Item> = mutableListOf()

        /** Newest first, every chat message seen since the listener connected (capped). */
        val history: MutableList<Item> = mutableListOf()

        /** The live listener, once the person has granted notification access. */
        @Volatile
        var instance: NotificationListener? = null
    }
}
