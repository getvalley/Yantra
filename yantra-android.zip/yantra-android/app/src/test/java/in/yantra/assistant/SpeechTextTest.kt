package `in`.yantra.assistant

import `in`.yantra.assistant.speech.SpeechText
import org.junit.Assert.assertEquals
import org.junit.Test

class SpeechTextTest {

    @Test
    fun timerUnitsAreSpelledOut() {
        assertEquals("Paused with 4 minutes 30 seconds left.", SpeechText.clean("Paused with 4m 30s left."))
        assertEquals("5 minutes left on the timer.", SpeechText.clean("5m 00s left on the timer."))
        assertEquals("1 hour 5 seconds", SpeechText.clean("1h 0m 05s"))
        assertEquals("1 minute 1 second", SpeechText.clean("1m 01s"))
    }

    @Test
    fun wordsEndingInThoseLettersAreLeftAlone() {
        assertEquals("Open items and chrome", SpeechText.clean("Open items and chrome"))
    }
}
