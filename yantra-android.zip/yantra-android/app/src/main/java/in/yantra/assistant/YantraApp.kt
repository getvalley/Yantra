package `in`.yantra.assistant

import android.app.Activity
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import java.lang.ref.WeakReference

class YantraApp : Application() {

    companion object {
        /**
         * The Yantra screen the person is looking at right now, or null when Yantra is in the
         * background. Launching the Clock app from a visible Activity is what Xiaomi, Oppo and
         * OnePlus allow; from the bare Application they can silently drop the launch.
         */
        @Volatile
        private var visible: WeakReference<Activity>? = null

        fun foreground(): Activity? = visible?.get()?.takeIf { !it.isFinishing && !it.isDestroyed }
    }

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityResumed(a: Activity) { visible = WeakReference(a) }
            override fun onActivityPaused(a: Activity) { if (visible?.get() === a) visible = null }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("yantra_alarms", "Alarms", NotificationManager.IMPORTANCE_HIGH)
            )
            nm.createNotificationChannel(
                NotificationChannel("yantra_general", "General", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }
}
