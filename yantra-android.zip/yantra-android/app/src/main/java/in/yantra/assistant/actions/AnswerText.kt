package `in`.yantra.assistant.actions

import java.util.Locale

/**
 * The pure half of "answer it here instead of opening Google".
 *
 * Decides whether a question is one we can honestly answer from an
 * encyclopedia or a dictionary, what to look up, whether the page that came
 * back is really about it, and how to trim the result for a phone screen and
 * for a voice. No Android imports, so it is unit-tested on the JVM.
 *
 * The rule is: answer only what an encyclopedia intro answers ("who is",
 * "what is", "where is", "define"), and say nothing otherwise, so a "how do
 * I..." or "what is the population of..." still goes to Google instead of
 * getting an answer that is related but wrong.
 */
object AnswerText {

    enum class Kind { DEFINE, TOPIC, RELATION }

    /**
     * A question with a one-line answer in Wikidata: "who owns X", "who founded X", "capital of X".
     * [props] are Wikidata properties tried in order; [phrase] is the sentence, with {t} for the
     * thing asked about and {x} for the answer.
     */
    data class Rel(val props: List<String>, val phrase: String)

    /**
     * @param topic what to look up
     * @param role  "who is the X of Y": also try to name the current office holder
     * @param strict the person said "search for" / "look up": only accept a page
     *               whose title covers everything they asked for
     */
    data class Plan(
        val kind: Kind,
        val topic: String,
        val role: Boolean = false,
        val strict: Boolean = false,
        /** "where is X": answer with a location, never with the "what is X" intro. */
        val where: Boolean = false,
        /** Set for [Kind.RELATION]: which fact to read from Wikidata. */
        val rel: Rel? = null
    )

    // ------------------------------------------------------------- planning

    private val PRONOUN_START = setOf(
        "you", "your", "yours", "my", "i", "me", "it", "its", "this", "that", "there", "here",
        "we", "they", "he", "she", "going", "happening", "wrong", "up"
    )

    /** Words that mean the person wants a specific, changing value, not an intro. */
    private val WANTS_A_VALUE = setOf(
        "height", "tall", "age", "old", "price", "cost", "population", "salary", "worth",
        "distance", "weight", "size", "speed", "date", "time", "timings", "schedule",
        "score", "scores", "hours", "open", "near", "nearby", "best", "top", "cheap",
        "cheapest", "review", "reviews", "recipe", "weather", "news", "today", "tomorrow",
        "tonight", "latest", "now", "rate", "rates", "result", "results"
    )

    private val STOP = setOf(
        "a", "an", "the", "of", "in", "on", "at", "for", "to", "and", "is", "are", "was",
        "were", "by", "with", "from"
    )

    fun clean(raw: String): String {
        var s = raw.lowercase(Locale.ROOT).trim()
            .replace('\u2019', '\'')
            .replace(Regex("[?!.,]+\$"), "")
            .replace(Regex("\\s+"), " ")
        s = s.replace(
            Regex("^(?:(?:hey|ok|okay) )?(?:yantra,? )?(?:please )?(?:(?:can|could|would) you )?(?:please )?"),
            ""
        )
        // "can you tell me who is ..." -> "who is ..."
        s = s.replace(Regex("^tell me (?=(?:who|what|where|whos|whats)\\b)"), "")
        return s.trim()
    }

    fun plan(raw: String): Plan? {
        val q = clean(raw)
        if (q.isEmpty()) return null

        Regex("^define (.+)\$").find(q)?.let { return define(it.groupValues[1]) }
        Regex("^(?:the )?(?:meaning|definition) of (.+)\$").find(q)?.let { return define(it.groupValues[1]) }

        relationPlan(q)?.let { return it }

        // "who is the prime minister of india": try to name the person
        Regex("^who(?: is|'s|s) (?:the )?(?:current |present |new )?(.+? (?:of|at|for) .+)\$").find(q)?.let {
            val role = it.groupValues[1]
            if (okTopic(role)) return Plan(Kind.TOPIC, role, role = true)
        }

        val loose = listOf(
            "^(?:(?:who|what)(?:'s| is| are| was| were)|whos|whats) (?:an? |the )?(.+)\$",
            "^where(?:'s| is| are| was| were) (?:an? |the )?(.+)\$",
            "^(?:tell me|talk to me|teach me|explain to me|tell me more) about (.+)\$",
            "^(?:explain|describe) (.+)\$",
            "^(?:what do you know|do you know anything) about (.+)\$",
            "^(?:info|information|details|facts) (?:on|about) (.+)\$"
        )
        for (p in loose) {
            Regex(p).find(q)?.let {
                val isWhere = p.startsWith("^where")
                var topic = it.groupValues[1].trim()
                if (isWhere) topic = topic.replace(Regex(" (?:located|situated|based|found|headquartered)\$"), "")
                if (okTopic(topic)) return Plan(Kind.TOPIC, topic, where = isWhere)
                return null
            }
        }

        Regex("^(?:search(?: for)?|look ?up|find) (.+)\$").find(q)?.let {
            val topic = it.groupValues[1].trim()
            if (okTopic(topic)) return Plan(Kind.TOPIC, topic, strict = true)
        }
        return null
    }

    private fun define(topic: String): Plan? {
        val t = topic.trim()
        return if (t.isNotEmpty() && t.length <= 60 && t.split(' ').size <= 5) Plan(Kind.DEFINE, t) else null
    }

    fun okTopic(topic: String): Boolean {
        val words = topic.trim().split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty() || words.size > 7 || topic.length > 80) return false
        if (words[0] in PRONOUN_START) return false
        if (words.any { it in WANTS_A_VALUE }) return false
        return words.any { w -> w.any { it.isLetter() } }
    }


    // ----------------------------------------------------- relation questions

    private val OWNER = Rel(listOf("P127", "P749"), "{t} is owned by {x}.")
    private val CAPITAL_Q = Regex("^(?:what(?:'s| is)|whats) (?:the )?capital(?: city)? of (.+)$")
    private val OWNED_BY_Q = Regex("^who(?: is|'s|s) (.+) owned by$")
    private val ROLE_Q = Regex(
        "^who(?: is|'s|s) (?:the )?(?:current |present |new )?(ceo|chief executive officer|chief executive|" +
            "chairman|founder|founders|owner|creator|inventor|author|director|composer) (?:of|at|for) (.+)$"
    )
    private val VERB_Q = Regex(
        "^who (?:currently |actually |originally )?(owns|founded|started|created|made|invented|discovered|" +
            "wrote|directed|composed|painted|designed|built|developed|runs|leads|heads) (.+)$"
    )

    private fun roleRel(role: String): Rel = when (role) {
        "ceo", "chief executive officer", "chief executive" -> Rel(listOf("P169"), "The CEO of {t} is {x}.")
        "chairman" -> Rel(listOf("P488"), "The chairman of {t} is {x}.")
        "founder", "founders" -> Rel(listOf("P112"), "{t} was founded by {x}.")
        "owner" -> OWNER
        "creator" -> Rel(listOf("P170", "P178"), "{t} was created by {x}.")
        "inventor" -> Rel(listOf("P61"), "{t} was invented by {x}.")
        "author" -> Rel(listOf("P50"), "{t} was written by {x}.")
        "director" -> Rel(listOf("P57"), "{t} was directed by {x}.")
        else -> Rel(listOf("P86"), "{t} was composed by {x}.")
    }

    private fun verbRel(verb: String): Rel = when (verb) {
        "owns" -> OWNER
        "founded", "started" -> Rel(listOf("P112"), "{t} was founded by {x}.")
        "created", "made" -> Rel(listOf("P170", "P178", "P176", "P112"), "{t} was $verb by {x}.")
        "designed", "built", "developed" -> Rel(listOf("P170", "P178"), "{t} was $verb by {x}.")
        "invented", "discovered" -> Rel(listOf("P61", "P170"), "{t} was $verb by {x}.")
        "wrote" -> Rel(listOf("P50", "P170"), "{t} was written by {x}.")
        "directed" -> Rel(listOf("P57"), "{t} was directed by {x}.")
        "composed" -> Rel(listOf("P86"), "{t} was composed by {x}.")
        "painted" -> Rel(listOf("P170"), "{t} was painted by {x}.")
        else -> Rel(listOf("P169"), "The CEO of {t} is {x}.") // runs, leads, heads
    }

    /** "who owns google", "who is the ceo of apple", "what is the capital of france". Null if it is none of these. */
    private fun relationPlan(q: String): Plan? {
        fun entity(raw: String): String? {
            val e = raw.trim().removePrefix("the ").trim()
            return if (okTopic(e)) e else null
        }
        CAPITAL_Q.find(q)?.let { m ->
            entity(m.groupValues[1])?.let { return Plan(Kind.RELATION, it, rel = Rel(listOf("P36"), "The capital of {t} is {x}.")) }
        }
        OWNED_BY_Q.find(q)?.let { m ->
            entity(m.groupValues[1])?.let { return Plan(Kind.RELATION, it, rel = OWNER) }
        }
        ROLE_Q.find(q)?.let { m ->
            entity(m.groupValues[2])?.let { return Plan(Kind.RELATION, it, rel = roleRel(m.groupValues[1])) }
        }
        VERB_Q.find(q)?.let { m ->
            entity(m.groupValues[2])?.let { return Plan(Kind.RELATION, it, rel = verbRel(m.groupValues[1])) }
        }
        return null
    }

    /** True when the page title is the thing that was asked about, not just close to it. */
    fun sameName(topic: String, title: String): Boolean {
        val t = sig(topic)
        return t.isNotEmpty() && t == sig(title, keepParen = false)
    }

    // ------------------------------------------------ is this page about it?

    private fun stem(w: String): String =
        if (w.length > 3 && w.endsWith("s") && !w.endsWith("ss")) w.dropLast(1) else w

    private fun sig(s: String, keepParen: Boolean = true): Set<String> {
        val text = if (keepParen) s else s.replace(Regex("\\([^)]*\\)"), " ")
        return text.lowercase(Locale.ROOT)
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.isNotEmpty() && it !in STOP }
            .map { stem(it) }
            .toSet()
    }

    /**
     * Search engines return something for anything. Take the page only when its
     * title covers what was asked (or, for a loose question, is what was asked
     * plus at most two extra words), so "train timings" does not become an
     * article called "Train".
     */
    fun accepts(topic: String, title: String, strict: Boolean): Boolean {
        val t = sig(topic)
        val full = sig(title)
        val base = sig(title, keepParen = false)
        if (t.isEmpty() || base.isEmpty()) return false
        if (full.containsAll(t)) return true
        if (!strict && t.containsAll(base)) return t.count { it !in base } <= 2
        return false
    }

    // ------------------------------------------------------------ trimming

    private val ABBREVIATIONS = setOf(
        "mr", "mrs", "ms", "dr", "prof", "st", "jr", "sr", "vs", "etc", "inc", "ltd", "co",
        "no", "gen", "col", "lt", "sgt", "capt", "mt", "fig", "approx", "ca"
    )

    /** Removes pronunciations, dates in brackets and citation marks; one line out. */
    fun strip(s: String): String {
        var t = s.replace('\u00A0', ' ')
        repeat(3) { t = t.replace(Regex("\\s*\\([^()]*\\)"), "") }
        t = t.replace(Regex("\\s*\\[[^\\]]*\\]"), "")
        t = t.replace(Regex("\\s*\\n+\\s*"), " ")
            .replace(Regex("\\s{2,}"), " ")
            .replace(Regex("\\s+([,.;:])"), "\$1")
        return t.trim()
    }

    fun sentences(text: String): List<String> {
        val out = ArrayList<String>()
        var start = 0
        val boundary = Regex("[.!?][\"\u201D')]*\\s+(?=[\"\u201C(]?[A-Z0-9])")
        for (hit in boundary.findAll(text)) {
            if (hit.value.startsWith(".")) {
                val before = text.substring(start, hit.range.first)
                val last = before.substringAfterLast(' ').trimStart('"', '\u201C', '(').lowercase(Locale.ROOT)
                val abbreviation = (last.length == 1 && last[0].isLetter()) ||
                    last in ABBREVIATIONS || last.contains('.')
                if (abbreviation) continue
            }
            out.add(text.substring(start, hit.range.last + 1).trim())
            start = hit.range.last + 1
        }
        if (start < text.length) out.add(text.substring(start).trim())
        return out.filter { it.isNotEmpty() }
    }

    /** Up to three sentences and about 380 characters: one phone screen. */
    fun tidy(extract: String, maxChars: Int = 520, maxSentences: Int = 3): String {
        val sents = sentences(strip(extract))
        if (sents.isEmpty()) return ""
        val out = StringBuilder()
        var n = 0
        for (s in sents) {
            if (n >= maxSentences) break
            if (n > 0 && out.length + 1 + s.length > maxChars) break
            if (n > 0) out.append(' ')
            out.append(s)
            n++
        }
        var text = out.toString()
        if (text.length > maxChars) text = text.take(maxChars).substringBeforeLast(' ') + "\u2026"
        return text
    }

    private val LOCATION_WORDS = Regex(
        "\\b(?:located|situated|headquarter(?:s|ed)|based in|lies|lying|capital of|city in|town in|village in|" +
            "country in|island in|north|south|east|west)\\b", RegexOption.IGNORE_CASE
    )

    /** Sentences that only add detail ("On the north coast lies Iran...") are never the headline answer. */
    private val DETAIL_START = Regex(
        "^(?:On|In|To|At|Along) (?:the )?(?:north|south|east|west)\\w*\\b", RegexOption.IGNORE_CASE
    )

    /** A sentence that places the thing: "is located in", "is a strait between", "off the coast of". */
    private val PLACING = Regex(
        "\\b(?:located|situated|headquarter(?:s|ed)|based in|found in|lies|lying|between|" +
            "off the coast|borders?|bordered|capital of|city in|town in|village in|country in|island in|" +
            "region of|state of|province of)\\b", RegexOption.IGNORE_CASE
    )

    /** "in Paris", "on the Champ de Mars": a preposition followed by a capitalised name. */
    private val PLACE_NAME = Regex("\\b(?:in|on|at|off|near) (?:the )?[A-Z][\\p{L}]+")

    /**
     * The sentence of a stripped extract that best says where something is, or null.
     * The opening sentences are tried first, in order, because an encyclopedia's lead
     * sentence is where it says where a thing is. A later sentence is used only when
     * the lead has no place in it, and a "north coast lies Iran" detail line never leads.
     */
    fun whereSentence(extract: String): String? {
        val all = sentences(strip(extract))
        val lead = all.take(3).filterNot { DETAIL_START.containsMatchIn(it) }
        lead.firstOrNull { PLACING.containsMatchIn(it) || PLACE_NAME.containsMatchIn(it) && !it.contains(Regex("\\b\\d{3,4}\\b")) }
            ?.let { return it }
        return all.filterNot { DETAIL_START.containsMatchIn(it) }
            .firstOrNull { LOCATION_WORDS.containsMatchIn(it) }
    }

    /** "It is headquartered in X." -> "The United Nations is headquartered in X." so the answer stands alone. */
    fun named(sentence: String, title: String): String {
        val m = Regex("^(?:It|They|This|The (?:strait|city|town|river|lake|mountain|country|island|region)) (is|are|lies|lie|sits|stands)\\b")
            .find(sentence) ?: return sentence
        // the verb starts at group 1; one step back keeps the space after the name
        return title + sentence.substring(m.groups[1]!!.range.first - 1)
    }

    /**
     * What to say aloud: the first two sentences, in full. The first is never
     * cut, however long: stopping mid-sentence is worse than a long answer. The
     * second is added only when the pair stays short.
     */
    fun speakable(text: String): String {
        var out = ""
        for (s in sentences(text).take(2)) {
            if (out.isNotEmpty() && out.length + s.length > 360) break
            out = if (out.isEmpty()) s else "$out $s"
        }
        return out
    }
}
