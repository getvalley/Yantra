package `in`.yantra.assistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.max
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import `in`.yantra.assistant.ChatMsg
import `in`.yantra.assistant.actions.Card

/**
 * The summon screen: nothing but the glass bubble.
 *
 * The app you were in stays fully visible and unblurred behind it. The bubble
 * drops out of the top of the screen, spans it from side to side, and is the
 * face of Yantra: it swells with your voice and flows while it thinks.
 *
 * Tap the bubble and it slims into a "Search or Ask" bar with a keyboard, so you
 * can type instead of talk. The mic icon on the bar goes back to voice. Sending
 * a typed command returns to the bubble, which flows while Yantra works; replies
 * are spoken. Tap anywhere outside the glass to close.
 *
 * When Yantra answers, the glass morphs into a rounded panel holding the answer text and,
 * for looked-up answers, a result card with the source (tap it to read more). Tap the
 * panel to ask a follow-up in the bar.
 */
@Composable
fun AssistPanel(
    messages: List<ChatMsg>,
    listening: Boolean,
    busy: Boolean,
    transcript: String,
    notice: String,
    blurred: Boolean,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onOpenLink: (String) -> Unit,
    onClose: () -> Unit,
    /** Swipe down on a bare bubble, or the expand icon on an answer: open the full app. */
    onOpenApp: () -> Unit = {},
    /** The installed app the typed text clearly names, for the "WhatsApp \u2014 Open" suggestion. */
    appHint: (String) -> AppHit? = { null },
    onLaunchApp: (AppHit) -> Unit = {},
    /** Live voice level 0..1. A lambda, so reading it never recomposes the panel. */
    micLevel: () -> Float = { 0f }
) {
    // messages[0] is the app's greeting; it is not part of this summon.
    val last = messages.lastOrNull()
    val pending = messages.size > 1 && last?.fromUser == true

    val noRipple = remember { MutableInteractionSource() }
    val density = LocalDensity.current
    val statusPx = WindowInsets.statusBars.getTop(density)
    val statusDp = with(density) { statusPx.toDp() }

    var typing by remember { mutableStateOf(false) }
    // the answer the person has already tapped away, so it does not pop back
    var dismissed by remember { mutableLongStateOf(0L) }
    val answer = last?.takeIf {
        messages.size > 1 && !it.fromUser && it.text.isNotBlank() &&
            it.stamp != dismissed && !typing && !listening
    }
    // keep the last answer on screen while the glass folds back, so the text does not vanish first
    var lastAnswer by remember { mutableStateOf<ChatMsg?>(null) }
    LaunchedEffect(answer) {
        if (answer != null) lastAnswer = answer else { delay(260); lastAnswer = null }
    }
    val shown = answer ?: lastAnswer
    var contentPx by remember { mutableIntStateOf(0) }
    val contentAlpha by animateFloatAsState(
        targetValue = if (answer != null) 1f else 0f,
        animationSpec = tween(durationMillis = if (answer != null) 220 else 110, delayMillis = if (answer != null) 140 else 0),
        label = "answerAlpha"
    )
    var query by remember { mutableStateOf("") }
    // pulled down: the answer also lists what was done (messages, places, reminders...)
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(answer?.stamp) { expanded = false }
    // typing an app's name: "WhatsApp \u2014 Open", right in the bar
    var hit by remember { mutableStateOf<AppHit?>(null) }
    LaunchedEffect(query) {
        if (query.isBlank()) { hit = null; return@LaunchedEffect }
        delay(70)
        hit = appHint(query)
    }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    fun openBar() {
        // stop the mic first: typing and a live recogniser should not race
        if (listening) onMic()
        dismissed = last?.stamp ?: 0L
        typing = true
    }

    fun closeBar() {
        typing = false
        query = ""
        keyboard?.hide()
    }

    fun submit() {
        val text = query.trim()
        if (text.isEmpty()) return
        // just an app's name: open it, as the bar says it will
        val app = hit
        if (app != null) {
            closeBar()
            onLaunchApp(app)
            return
        }
        closeBar()
        onSend(text)
    }

    // Back collapses the bar first, then a second press closes the panel
    BackHandler(enabled = typing) { closeBar() }

    LaunchedEffect(typing) {
        if (typing) {
            focus.requestFocus()
            keyboard?.show()
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            // a tap anywhere outside the glass closes it
            .clickable(interactionSource = noRipple, indication = null) { onClose() }
    ) {
        // where the glass sits: it grows out of the status bar, like the blob does
        val glassTop = statusDp + GlassGeometry.TOP_GAP_DP.dp
        val wakeHeight = maxWidth * 0.26f
        val barHeight = (GlassGeometry.BAR_HALF_HEIGHT_DP * 2f).dp

        // swipe on the bubble or the answer panel: up sends it away, down opens the app.
        // The glass follows the finger a little, and springs back if the swipe is too short.
        val scope = rememberCoroutineScope()
        val dragY = remember { Animatable(0f) }
        val closeNow by rememberUpdatedState(onClose)
        val openAppNow by rememberUpdatedState(onOpenApp)
        val maxUpPx = with(density) { 160.dp.toPx() }
        val maxDownPx = with(density) { 56.dp.toPx() }
        val swipePx = with(density) { 56.dp.toPx() }
        // down: show what was done first, then (or on a bare bubble) the app. Up: fold it, then close.
        val pullDown by rememberUpdatedState<() -> Unit> {
            val a = answer
            if (a != null && a.cards.isNotEmpty() && !expanded) {
                expanded = true
                scope.launch { dragY.animateTo(0f) }
            } else openAppNow()
        }
        val pullUp by rememberUpdatedState<() -> Unit> {
            if (expanded) {
                expanded = false
                scope.launch { dragY.animateTo(0f) }
            } else scope.launch {
                dragY.animateTo(-maxUpPx, tween(140))
                closeNow()
            }
        }
        val swipe = Modifier.pointerInput(Unit) {
            var total = 0f
            detectVerticalDragGestures(
                onDragStart = { total = 0f },
                onVerticalDrag = { change, amount ->
                    change.consume()
                    total += amount
                    scope.launch { dragY.snapTo((dragY.value + amount * 0.7f).coerceIn(-maxUpPx, maxDownPx)) }
                },
                onDragEnd = {
                    when {
                        total <= -swipePx -> pullUp()
                        total >= swipePx -> pullDown()
                        else -> scope.launch { dragY.animateTo(0f) }
                    }
                },
                onDragCancel = { scope.launch { dragY.animateTo(0f) } }
            )
        }

        val contentDp = with(density) { contentPx.toDp() }
        val boxHeight = if (shown != null) max(statusDp + 220.dp, glassTop + contentDp + 48.dp) else statusDp + 220.dp
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(boxHeight)
                .graphicsLayer { translationY = dragY.value }
        ) {
            AndroidView(
                factory = { ctx ->
                    GlassBlobView(ctx).apply {
                        palette = OrbClouds
                        contentDescription = "Yantra. Tap to type. Swipe up to close, swipe down to see what I did."
                    }
                },
                modifier = Modifier.fillMaxSize(),
                update = { v ->
                    v.topInset = statusPx.toFloat()
                    v.listening = listening
                    v.working = busy || pending
                    v.micLevel = micLevel()
                    v.bar = typing
                    v.answerHeight = if (answer != null) contentPx.toFloat() else 0f
                }
            )

            if (shown != null) {
                AnswerContent(
                    msg = shown,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(
                            top = glassTop,
                            start = GlassGeometry.EDGE_MARGIN_DP.dp,
                            end = GlassGeometry.EDGE_MARGIN_DP.dp
                        )
                        .fillMaxWidth()
                        .onSizeChanged { contentPx = it.height }
                        .graphicsLayer { alpha = contentAlpha }
                        // tap the panel for a follow-up; taps on the glass do not close the panel
                        .clickable(interactionSource = noRipple, indication = null) { if (answer != null) openBar() }
                        .then(swipe),
                    expanded = expanded,
                    onOpenLink = onOpenLink,
                    onOpenApp = onOpenApp
                )
            } else if (!typing) {
                // the whole bubble is one big button: tap to open the search bar
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(
                            top = glassTop,
                            start = GlassGeometry.EDGE_MARGIN_DP.dp,
                            end = GlassGeometry.EDGE_MARGIN_DP.dp
                        )
                        .fillMaxWidth(0.36f)
                        .height(wakeHeight)
                        .clickable(interactionSource = noRipple, indication = null) { openBar() }
                        .then(swipe)
                )
            } else {
                // the bar: text field on the left, mic on the right, inside the glass
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(
                            top = glassTop,
                            start = GlassGeometry.EDGE_MARGIN_DP.dp,
                            end = GlassGeometry.EDGE_MARGIN_DP.dp
                        )
                        .fillMaxWidth()
                        .height(barHeight)
                        // swallow taps on the glass so they do not close the panel
                        .clickable(interactionSource = noRipple, indication = null) { },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 26.dp, end = 8.dp)
                            .focusRequester(focus),
                        singleLine = true,
                        textStyle = TextStyle(
                            color = Color.White,
                            fontFamily = Bricolage,
                            fontWeight = FontWeight.Medium,
                            fontSize = 19.sp
                        ),
                        cursorBrush = SolidColor(Color.White),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { submit() }),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                val h = hit
                                if (h != null && query.isNotEmpty()) {
                                    // what Enter will do: the typed part hidden, the rest of the name and "\u2014 Open" faded
                                    val typed = query
                                    val rest = if (h.label.startsWith(typed, ignoreCase = true)) h.label.substring(typed.length)
                                    else "  \u2192 " + h.label
                                    Text(
                                        text = buildAnnotatedString {
                                            withStyle(SpanStyle(color = Color.Transparent)) { append(typed) }
                                            append(rest + " \u2014 Open")
                                        },
                                        color = Color.White.copy(alpha = 0.5f),
                                        fontFamily = Bricolage,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 19.sp,
                                        maxLines = 1
                                    )
                                }
                                if (query.isEmpty()) {
                                    Text(
                                        text = "Search or Ask",
                                        color = Color.White.copy(alpha = 0.55f),
                                        fontFamily = Bricolage,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 19.sp
                                    )
                                }
                                inner()
                            }
                        }
                    )
                    val h = hit
                    if (h != null && query.isNotBlank()) {
                        // the app that Enter opens
                        Box(
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .size(36.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .clickable(interactionSource = noRipple, indication = null) {
                                    closeBar()
                                    onLaunchApp(h)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            val icon = h.icon
                            if (icon != null) {
                                Image(bitmap = icon, contentDescription = "Open " + h.label, modifier = Modifier.size(34.dp))
                            } else {
                                Text(
                                    text = h.label.take(1).uppercase(), color = Color.White,
                                    fontFamily = Bricolage, fontWeight = FontWeight.Medium, fontSize = 18.sp
                                )
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .padding(end = 14.dp)
                                .size(36.dp)
                                .clickable(interactionSource = noRipple, indication = null) {
                                    // back to voice: collapse the bar and open the mic
                                    closeBar()
                                    onMic()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Mic,
                                contentDescription = "Talk instead",
                                tint = Color.White.copy(alpha = 0.75f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * What sits on the answer panel: Yantra's reply in large type and, for looked-up answers,
 * a result card with the source. The glass behind it is sized to this column's height.
 */
@Composable
private fun AnswerContent(
    msg: ChatMsg,
    modifier: Modifier = Modifier,
    expanded: Boolean,
    onOpenLink: (String) -> Unit,
    onOpenApp: () -> Unit
) {
    val noRipple = remember { MutableInteractionSource() }
    val hasCard = msg.source.isNotBlank() || msg.link.isNotBlank()
    val steps = msg.cards.take(5)
    Column(modifier = modifier) {
        Box {
            Text(
                text = msg.text,
                color = Color.White,
                fontFamily = Bricolage,
                fontWeight = FontWeight.Medium,
                fontSize = 17.sp,
                lineHeight = 23.sp,
                maxLines = if (expanded) 4 else 6,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 24.dp, end = if (expanded) 64.dp else 24.dp, top = 24.dp)
            )
            if (expanded) {
                // the full app is one tap away once the details are showing
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 14.dp, end = 12.dp)
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.16f))
                        .clickable(interactionSource = noRipple, indication = null) { onOpenApp() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.OpenInFull,
                        contentDescription = "Open the app",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
        if (expanded && steps.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            steps.forEachIndexed { i, card ->
                if (i > 0) Spacer(Modifier.height(8.dp))
                StepCard(card, onOpenLink)
            }
            Spacer(Modifier.height(18.dp))
        } else if (hasCard) {
            Spacer(Modifier.height(16.dp))
            val title = msg.source.ifBlank { "Open link" }
            Row(
                modifier = Modifier
                    .padding(start = 14.dp, end = 14.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    // solid dark base first so the screen behind the glass no longer shows through the card
                    .background(Color(0xFF1C1C1E).copy(alpha = 0.92f))
                    .background(Color.White.copy(alpha = 0.14f))
                    .clickable(interactionSource = noRipple, indication = null) {
                        if (msg.link.isNotBlank()) onOpenLink(msg.link)
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title.first().uppercase(),
                        color = Color.White,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.Medium,
                        fontSize = 18.sp
                    )
                }
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (msg.link.isNotBlank()) {
                        Text(
                            text = "Tap to read more",
                            color = Color.White.copy(alpha = 0.7f),
                            fontFamily = Bricolage,
                            fontSize = 14.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        } else {
            Spacer(Modifier.height(if (steps.isNotEmpty()) 12.dp else 22.dp))
            if (steps.isNotEmpty()) {
                // a small handle: there is more under this, pull down
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .size(width = 34.dp, height = 4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.3f))
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

/** One thing that was done or found: a message, a place with its buttons, or a plain action. */
@Composable
private fun StepCard(card: Card, onOpenLink: (String) -> Unit) {
    val noRipple = remember { MutableInteractionSource() }
    val isPlace = card.kind == "place"
    Column(
        modifier = Modifier
            .padding(start = 14.dp, end = 14.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            // solid dark base first so the screen behind the glass does not show through
            .background(Color(0xFF1C1C1E).copy(alpha = 0.92f))
            .background(Color.White.copy(alpha = 0.14f))
            .clickable(interactionSource = noRipple, indication = null) {
                if (!isPlace && card.link.isNotBlank()) onOpenLink(card.link)
            }
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = card.title.firstOrNull()?.uppercase() ?: "\u2022",
                    color = Color.White,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Medium,
                    fontSize = 18.sp
                )
            }
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp, end = 8.dp)) {
                Text(
                    text = card.title,
                    color = Color.White,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Medium,
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (card.subtitle.isNotBlank()) {
                    Text(
                        text = card.subtitle,
                        color = Color.White.copy(alpha = 0.85f),
                        fontFamily = Bricolage,
                        fontSize = 14.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (card.detail.isNotBlank()) {
                    Text(
                        text = card.detail,
                        color = Color.White.copy(alpha = 0.55f),
                        fontFamily = Bricolage,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (card.time.isNotBlank()) {
                Text(
                    text = card.time,
                    color = Color.White.copy(alpha = 0.7f),
                    fontFamily = Bricolage,
                    fontSize = 13.sp
                )
            }
        }
        if (isPlace && (card.link.isNotBlank() || card.link2.isNotBlank())) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (card.link2.isNotBlank()) {
                    PillButton("Call", Color.White.copy(alpha = 0.16f), Modifier.weight(1f)) { onOpenLink(card.link2) }
                }
                if (card.link.isNotBlank()) {
                    PillButton("Directions", Color(0xFF0A84FF), Modifier.weight(1f)) { onOpenLink(card.link) }
                }
            }
        }
    }
}

@Composable
private fun PillButton(label: String, fill: Color, modifier: Modifier, onClick: () -> Unit) {
    val noRipple = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(fill)
            .clickable(interactionSource = noRipple, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color.White,
            fontFamily = Bricolage,
            fontWeight = FontWeight.Medium,
            fontSize = 15.sp
        )
    }
}
