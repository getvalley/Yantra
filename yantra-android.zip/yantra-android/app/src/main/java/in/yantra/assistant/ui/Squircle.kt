package `in`.yantra.assistant.ui

import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

/*
 * The app's only corner shape. A squircle is a rounded rectangle whose curve eases into the
 * straight edge instead of meeting it at a fixed arc, so there is no point where the eye sees
 * the corner "start". The curve is the continuous-corner construction used by iOS icons: each
 * corner reaches 1.53x its radius along the edges.
 *
 * Ask for any radius. Anything larger than the box allows is shrunk to the largest that fits, so
 * Squircle(100.dp) is the roundest squircle a box can be (a button, a pill, a bar), never a circle.
 */

private const val REACH = 1.52866483f

/** All four corners the same. */
fun Squircle(radius: Dp): Shape = SquircleShape(radius, radius, radius, radius)

/** Corners set one by one, e.g. a chat bubble whose tail corner is tighter. */
fun Squircle(topStart: Dp, topEnd: Dp, bottomEnd: Dp, bottomStart: Dp): Shape =
    SquircleShape(topStart, topEnd, bottomEnd, bottomStart)

private data class SquircleShape(
    private val topStart: Dp,
    private val topEnd: Dp,
    private val bottomEnd: Dp,
    private val bottomStart: Dp
) : Shape {

    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val rtl = layoutDirection == LayoutDirection.Rtl
        val tl = with(density) { (if (rtl) topEnd else topStart).toPx() }
        val tr = with(density) { (if (rtl) topStart else topEnd).toPx() }
        val br = with(density) { (if (rtl) bottomStart else bottomEnd).toPx() }
        val bl = with(density) { (if (rtl) bottomEnd else bottomStart).toPx() }
        // asked for a full radius on every corner: that is a pill, so give it squircle ends
        val half = min(size.width, size.height) / 2f
        if (half > 0f && tl >= half - 0.5f && tr >= half - 0.5f && br >= half - 0.5f && bl >= half - 0.5f) {
            return Outline.Generic(pillPath(size.width, size.height))
        }
        return Outline.Generic(squirclePath(size.width, size.height, tl, tr, br, bl))
    }
}

/**
 * A pill whose two ends are squircles instead of half circles: the end caps follow the superellipse
 * |x|^n + |y|^n = 1 (n = 3.6), joined by straight edges. On a square box it is a plain squircle.
 */
internal fun pillPath(w: Float, h: Float): Path {
    val n = 3.6f
    val e = 2f / n
    val horizontal = w >= h
    val a = if (horizontal) h / 2f else w / 2f      // half the short side
    val steps = 28
    fun x(t: Double) = (sign(cos(t)) * abs(cos(t)).pow(e.toDouble())).toFloat()
    fun y(t: Double) = (sign(sin(t)) * abs(sin(t)).pow(e.toDouble())).toFloat()
    return Path().apply {
        if (horizontal) {
            val cxR = w - a; val cxL = a; val cy = h / 2f
            // right cap, top to bottom
            moveTo(cxL, 0f)
            lineTo(cxR, 0f)
            for (i in 1..steps) {
                val t = -Math.PI / 2 + Math.PI * i / steps
                lineTo(cxR + a * x(t), cy + a * y(t))
            }
            lineTo(cxL, h)
            // left cap, bottom to top
            for (i in 1..steps) {
                val t = Math.PI / 2 + Math.PI * i / steps
                lineTo(cxL + a * x(t), cy + a * y(t))
            }
        } else {
            val cx = w / 2f; val cyT = a; val cyB = h - a
            moveTo(w, cyT)
            lineTo(w, cyB)
            for (i in 1..steps) {
                val t = 0.0 + Math.PI * i / steps
                lineTo(cx + a * x(t), cyB + a * y(t))
            }
            lineTo(0f, cyT)
            for (i in 1..steps) {
                val t = Math.PI + Math.PI * i / steps
                lineTo(cx + a * x(t), cyT + a * y(t))
            }
        }
        close()
    }
}

internal fun squirclePath(w: Float, h: Float, tl: Float, tr: Float, br: Float, bl: Float): Path {
    // shrink every radius together until the corners that share an edge fit on it
    var s = 1f
    fun fit(edge: Float, a: Float, b: Float) {
        val need = REACH * (a + b)
        if (need > edge && need > 0f) s = min(s, edge / need)
    }
    fit(w, tl, tr); fit(w, bl, br); fit(h, tl, bl); fit(h, tr, br)

    return Path().apply {
        // clockwise from the top edge. Each corner: where it sits, which way its incoming edge
        // lies (u, pointing away from the corner) and which way the outgoing edge runs (v).
        moveTo(tl * s * REACH, 0f)
        corner(w, 0f, tr * s, -1f, 0f, 0f, 1f)
        corner(w, h, br * s, 0f, -1f, -1f, 0f)
        corner(0f, h, bl * s, 1f, 0f, 0f, -1f)
        corner(0f, 0f, tl * s, 0f, 1f, 1f, 0f)
        close()
    }
}

/**
 * One corner: a line to where the curve starts, then three cubics through the continuous-corner
 * profile. [along] measures from the corner down the incoming edge, [across] down the outgoing one.
 */
private fun Path.corner(
    cx: Float, cy: Float, r: Float,
    ux: Float, uy: Float, vx: Float, vy: Float
) {
    fun x(along: Float, across: Float) = cx + (ux * along + vx * across) * r
    fun y(along: Float, across: Float) = cy + (uy * along + vy * across) * r
    if (r <= 0f) { lineTo(cx, cy); return }
    lineTo(x(REACH, 0f), y(REACH, 0f))
    cubicTo(
        x(1.08849323f, 0f), y(1.08849323f, 0f),
        x(0.86840689f, 0f), y(0.86840689f, 0f),
        x(0.63149399f, 0.07491461f), y(0.63149399f, 0.07491461f)
    )
    cubicTo(
        x(0.37282392f, 0.16905899f), y(0.37282392f, 0.16905899f),
        x(0.16905899f, 0.37282392f), y(0.16905899f, 0.37282392f),
        x(0.07491461f, 0.63149399f), y(0.07491461f, 0.63149399f)
    )
    cubicTo(
        x(0f, 0.86840689f), y(0f, 0.86840689f),
        x(0f, 1.08849323f), y(0f, 1.08849323f),
        x(0f, REACH), y(0f, REACH)
    )
}
