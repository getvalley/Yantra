package `in`.yantra.assistant.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.flow.distinctUntilChanged
import java.util.Calendar
import kotlin.math.abs

enum class ClockKind { TIMER, ALARM }

/** What the person picked, ready to hand to the Clock app. */
sealed interface ClockPick {
    data class Timer(val seconds: Int, val label: String) : ClockPick
    data class Alarm(val hour: Int, val minute: Int, val label: String) : ClockPick
}

private val WheelItemHeight = 44.dp
private const val WHEEL_ROWS = 5

/**
 * The small menu that opens when "set a timer" or "set an alarm" comes with no time:
 * scroll wheels, a label, and a button that sends it to the phone's Clock app.
 */
@Composable
fun ClockSheet(
    kind: ClockKind,
    clockApp: String,
    onDismiss: () -> Unit,
    onStart: (ClockPick) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val focus = LocalFocusManager.current
    var label by remember { mutableStateOf("") }

    // timer
    var hours by remember { mutableIntStateOf(0) }
    var minutes by remember { mutableIntStateOf(10) }
    var seconds by remember { mutableIntStateOf(0) }

    // alarm: starts at the current time
    val now = remember { Calendar.getInstance() }
    var hour12 by remember { mutableIntStateOf(if (now.get(Calendar.HOUR) == 0) 12 else now.get(Calendar.HOUR)) }
    var alarmMinute by remember { mutableIntStateOf(now.get(Calendar.MINUTE)) }
    var pm by remember { mutableIntStateOf(now.get(Calendar.AM_PM)) } // 0 = AM, 1 = PM

    val timerTotal = hours * 3600 + minutes * 60 + seconds
    val canStart = kind == ClockKind.ALARM || timerTotal > 0

    fun start() {
        if (!canStart) return
        focus.clearFocus()
        if (kind == ClockKind.TIMER) {
            onStart(ClockPick.Timer(timerTotal, label.trim()))
        } else {
            val hour24 = (hour12 % 12) + if (pm == 1) 12 else 0
            onStart(ClockPick.Alarm(hour24, alarmMinute, label.trim()))
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        // tapping outside the card closes it; the card swallows its own taps
        Box(
            Modifier
                .fillMaxSize()
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() }
                .padding(12.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .plate(Squircle(32.dp))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { focus.clearFocus() }
                    .padding(horizontal = 16.dp, vertical = 16.dp)
            ) {
                // ---- header: close, title, start
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RoundButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = "Cancel", tint = colors.onSurface)
                    }
                    Text(
                        if (kind == ClockKind.TIMER) "Timer" else "Alarm",
                        Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.onSurface
                    )
                    RoundButton(onClick = { start() }, enabled = canStart) {
                        Icon(
                            if (kind == ClockKind.TIMER) Icons.Rounded.PlayArrow else Icons.Rounded.Check,
                            contentDescription = if (kind == ClockKind.TIMER) "Start timer" else "Save alarm",
                            tint = colors.primary
                        )
                    }
                }

                // ---- wheels
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp, bottom = 20.dp)
                        .height(WheelItemHeight * WHEEL_ROWS)
                ) {
                    Box(
                        Modifier
                            .align(Alignment.Center)
                            .fillMaxWidth()
                            .height(WheelItemHeight)
                            .clip(Squircle(16.dp))
                            .background(colors.surfaceVariant)
                            .border(1.dp, if (isDarkScheme()) PlateBorderDark else PlateBorderLight, Squircle(16.dp))
                    )
                    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        if (kind == ClockKind.TIMER) {
                            Wheel(List(24) { "$it" }, hours, "hours", { hours = it }, Modifier.weight(1f))
                            Wheel(List(60) { "$it" }, minutes, "min", { minutes = it }, Modifier.weight(1f))
                            Wheel(List(60) { "$it" }, seconds, "sec", { seconds = it }, Modifier.weight(1f))
                        } else {
                            Wheel(List(12) { "${it + 1}" }, hour12 - 1, null, { hour12 = it + 1 }, Modifier.weight(1f))
                            Wheel(List(60) { "%02d".format(it) }, alarmMinute, null, { alarmMinute = it }, Modifier.weight(1f))
                            Wheel(listOf("AM", "PM"), pm, null, { pm = it }, Modifier.weight(1f))
                        }
                    }
                }

                // ---- label and where it goes
                Column(
                    Modifier
                        .fillMaxWidth()
                        .plate(Squircle(24.dp), strong = true)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Label", style = MaterialTheme.typography.bodyLarge, color = colors.onSurface)
                        BasicTextField(
                            value = label,
                            onValueChange = { label = it.take(40) },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyLarge.copy(
                                color = colors.onSurfaceVariant, textAlign = TextAlign.End
                            ),
                            cursorBrush = SolidColor(colors.primary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { focus.clearFocus() }),
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 16.dp),
                            decorationBox = { inner ->
                                Box(contentAlignment = Alignment.CenterEnd) {
                                    if (label.isEmpty()) {
                                        Text(
                                            if (kind == ClockKind.TIMER) "Timer" else "Alarm",
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = colors.onSurfaceVariant.copy(alpha = 0.55f),
                                            textAlign = TextAlign.End
                                        )
                                    }
                                    inner()
                                }
                            }
                        )
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 18.dp), color = colors.outline)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Saves to", style = MaterialTheme.typography.bodyLarge, color = colors.onSurface)
                        Text(
                            clockApp,
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyLarge,
                            color = colors.onSurfaceVariant,
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundButton(onClick: () -> Unit, enabled: Boolean = true, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(52.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .plate(Squircle(100.dp), strong = true)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

/**
 * One scroll wheel. The row resting in the middle is the choice; rows fade and shrink
 * with their distance from it. [unit] (like "min") is drawn beside the chosen number.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Wheel(
    items: List<String>,
    initial: Int,
    unit: String?,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = MaterialTheme.colorScheme
    val state = rememberLazyListState(initialFirstVisibleItemIndex = initial.coerceIn(0, items.lastIndex))
    val fling = rememberSnapFlingBehavior(lazyListState = state)
    val itemPx = with(LocalDensity.current) { WheelItemHeight.toPx() }

    // with two rows of padding above and below, the first visible row is the middle one
    LaunchedEffect(state, items.size) {
        snapshotFlow {
            state.firstVisibleItemIndex + if (state.firstVisibleItemScrollOffset > itemPx / 2f) 1 else 0
        }.distinctUntilChanged().collect { onSelected(it.coerceIn(0, items.lastIndex)) }
    }

    Row(modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        LazyColumn(
            Modifier
                .weight(1f)
                .fillMaxSize(),
            state = state,
            flingBehavior = fling,
            contentPadding = PaddingValues(vertical = WheelItemHeight * (WHEEL_ROWS / 2))
        ) {
            itemsIndexed(items) { index, text ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(WheelItemHeight)
                        .graphicsLayer {
                            // How many rows this one is from the chosen row. Worked out from the scroll
                            // position, not from layoutInfo offsets, whose origin differs between
                            // Compose versions (it left the chosen row faded and the row two below bold).
                            val position = state.firstVisibleItemIndex +
                                state.firstVisibleItemScrollOffset / itemPx
                            val d = (abs(index - position) / 2f).coerceIn(0f, 1f)
                            alpha = 1f - 0.8f * d
                            val scale = 1f - 0.25f * d
                            scaleX = scale
                            scaleY = scale
                        },
                    contentAlignment = if (unit != null) Alignment.CenterEnd else Alignment.Center
                ) {
                    Text(
                        text,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Medium,
                        color = colors.onSurface,
                        modifier = Modifier.padding(end = if (unit != null) 6.dp else 0.dp)
                    )
                }
            }
        }
        if (unit != null) {
            Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.CenterStart) {
                Text(
                    unit,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.onSurface,
                    modifier = Modifier.padding(start = 2.dp)
                )
            }
        }
    }
}
