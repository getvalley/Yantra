package `in`.yantra.assistant

import `in`.yantra.assistant.actions.App
import `in`.yantra.assistant.actions.AppMatch
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppMatchTest {

    private val apps = listOf(
        App("YouTube", "com.google.android.youtube"),
        App("YouTube Music", "com.google.android.apps.youtube.music"),
        App("WhatsApp", "com.whatsapp"),
        App("WhatsApp Business", "com.whatsapp.w4b"),
        App("Gmail", "com.google.android.gm"),
        App("Google Maps", "com.google.android.apps.maps"),
        App("Instagram", "com.instagram.android"),
        App("Samsung Calculator", "com.sec.android.app.popupcalculator"),
        App("Monument Valley", "com.ustwo.monumentvalley"),
        App("Spotify", "com.spotify.music")
    )

    private fun pick(said: String) = AppMatch.best(apps, said)?.label

    @Test fun exactNameWins() {
        assertEquals("YouTube", pick("youtube"))
        assertEquals("YouTube Music", pick("youtube music"))
    }

    @Test fun plainNameBeatsLongerSiblings() {
        assertEquals("WhatsApp", pick("whatsapp"))
    }

    @Test fun spacingAndPunctuationDoNotMatter() {
        assertEquals("WhatsApp", pick("what's app"))
        assertEquals("YouTube", pick("you tube"))
    }

    @Test fun fillerWordsAreDropped() {
        assertEquals("Gmail", pick("the gmail app"))
    }

    @Test fun partOfALabelMatches() {
        assertEquals("Google Maps", pick("maps"))
        assertEquals("Samsung Calculator", pick("calculator"))
    }

    @Test fun nicknamesWork() {
        assertEquals("Instagram", pick("insta"))
        assertEquals("YouTube", pick("yt"))
        assertEquals("WhatsApp", pick("wa"))
    }

    @Test fun smallMisspellingsAreForgiven() {
        assertEquals("WhatsApp", pick("whatsap"))
        assertEquals("Instagram", pick("instagran"))
    }

    @Test fun wordOrderDoesNotMatter() {
        assertEquals("YouTube Music", pick("music youtube"))
    }

    @Test fun unknownNamesDoNotOpenSomethingRandom() {
        assertNull(pick("flipkart"))
        assertNull(pick("zzzz"))
        assertNull(pick(""))
    }

    @Test fun shortNamesAreNotGuessed() {
        // "clock" must not become some other five-letter app by one wrong letter
        assertNull(AppMatch.best(listOf(App("Block", "x.block")), "clock"))
    }

    @Test fun nearMissesAreSuggestedNotOpened() {
        // "clock" is one letter from "Block": offered as a maybe, never opened
        val list = listOf(App("Block", "x.block"))
        assertNull(AppMatch.best(list, "clock"))
        assertTrue(AppMatch.suggestions(list, "clock").contains("Block"))
    }

    @Test fun nonLatinLabelsStillCompare() {
        val list = listOf(App("\u0917\u0942\u0917\u0932", "com.google.x"))
        assertEquals("\u0917\u0942\u0917\u0932", AppMatch.best(list, "\u0917\u0942\u0917\u0932")?.label)
    }

    @Test fun distanceIsEditDistance() {
        assertEquals(0, AppMatch.distance("abc", "abc"))
        assertEquals(1, AppMatch.distance("whatsap", "whatsapp"))
        assertEquals(3, AppMatch.distance("", "abc"))
    }
}
