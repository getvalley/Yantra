package `in`.yantra.assistant.ui

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.OnBackPressedDispatcher
import androidx.activity.OnBackPressedDispatcherOwner
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import `in`.yantra.assistant.AssistantViewModel
import `in`.yantra.assistant.util.AppSettings

/**
 * The wake-up bubble, kept on screen over other apps.
 *
 * It is the very same [AssistPanel] the wake-up screen shows, drawn from the same view model
 * in a window of its own, so when "open maps then message ..." sends Yantra into Maps and
 * WhatsApp the glass bubble stays on top and finishes its work there. Tap outside it, or swipe
 * it up, and it closes, as on the wake-up screen; it also closes by itself a few seconds
 * after the last command, unless it is being used.
 *
 * It needs "Display over other apps". Without it every call here does nothing and Yantra works
 * as before. A visible overlay is also what lets Android accept an app launch from Yantra
 * after another app has taken the screen (the second step of a chained command).
 */
object BubbleOverlay {

    /** What the wake-up screen does for the panel, handed over so the overlay behaves the same. */
    class Hooks(
        val onOpenLink: (String) -> Unit,
        val onOpenApp: () -> Unit,
        val onMic: () -> Unit,
        val appHint: (String) -> AppHit?,
        val onLaunchApp: (AppHit) -> Unit,
        val micLevel: () -> Float,
        /** The overlay was closed by the person: let the wake-up screen finish too. */
        val onClosed: () -> Unit
    )

    private const val AUTO_CLOSE_MS = 8_000L

    private val main = Handler(Looper.getMainLooper())
    private var host: Any? = null
    private var hooks: Hooks? = null
    private var wm: WindowManager? = null
    private var view: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null
    private var owner: OverlayOwner? = null
    private val autoClose = Runnable { close(finishHost = true) }

    fun canShow(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    /** The wake-up screen offers itself as the owner of the bubble. */
    fun register(host: Any, hooks: Hooks) {
        this.host = host
        this.hooks = hooks
    }

    /** The wake-up screen is gone: so is the overlay, since its view model goes with it. */
    fun unregister(host: Any) {
        if (this.host !== host) return
        close(finishHost = false)
        this.host = null
        hooks = null
    }

    /** Puts the bubble over whatever app comes next. Does nothing if it is already up. */
    fun open(ctx: Context, vm: AssistantViewModel) {
        if (!canShow(ctx)) return
        val h = hooks ?: return
        val app = ctx.applicationContext
        main.post {
            main.removeCallbacks(autoClose)
            if (view != null) return@post
            try {
                attach(app, vm, h)
            } catch (e: Exception) {
                // no window could be added (permission revoked meanwhile): carry on without it
                view = null
                owner?.destroy()
                owner = null
            }
        }
    }

    /** The commands are done: leave the answer up for a while, then let the bubble go. */
    fun chainDone() {
        main.post {
            if (view == null) return@post
            main.removeCallbacks(autoClose)
            main.postDelayed(autoClose, AUTO_CLOSE_MS)
        }
    }

    /** Back on the wake-up screen: the overlay is not needed. */
    fun hide() = close(finishHost = false)

    fun close(finishHost: Boolean) {
        main.post {
            main.removeCallbacks(autoClose)
            val v = view ?: return@post
            try { wm?.removeView(v) } catch (e: Exception) { /* already gone */ }
            view = null
            params = null
            owner?.destroy()
            owner = null
            if (finishHost) hooks?.onClosed?.invoke()
        }
    }

    /**
     * Typing needs a window that can take focus, but a focused overlay would hide the app being
     * driven (WhatsApp's send button) from the accessibility service: so only while idle.
     */
    private fun setFocusable(on: Boolean) {
        val v = view ?: return
        val lp = params ?: return
        val flag = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.flags = if (on) lp.flags and flag.inv() else lp.flags or flag
        try { wm?.updateViewLayout(v, lp) } catch (e: Exception) { /* window went away */ }
    }

    private fun attach(app: Context, vm: AssistantViewModel, h: Hooks) {
        val manager = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val own = OverlayOwner()

        val cv = object : ComposeView(app) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                // someone is using it: do not close it under their finger
                main.removeCallbacks(autoClose)
                return super.dispatchTouchEvent(ev)
            }
        }
        cv.setViewTreeLifecycleOwner(own)
        cv.setViewTreeSavedStateRegistryOwner(own)
        cv.setViewTreeViewModelStoreOwner(own)
        cv.setContent {
            val systemDark = isSystemInDarkTheme()
            val dark = when (vm.themeMode) {
                AppSettings.THEME_DARK -> true
                AppSettings.THEME_LIGHT -> false
                else -> systemDark
            }
            LaunchedEffect(vm.busy) { setFocusable(!vm.busy) }
            CompositionLocalProvider(LocalOnBackPressedDispatcherOwner provides own) {
                YantraTheme(darkTheme = dark, font = vm.fontChoice) {
                    AssistPanel(
                        messages = vm.messages,
                        listening = vm.listening,
                        busy = vm.busy,
                        transcript = vm.transcript,
                        notice = vm.notice,
                        blurred = false,
                        micLevel = { h.micLevel() },
                        onSend = { text -> if (text.isNotBlank()) vm.send(text) },
                        onMic = { h.onMic() },
                        onOpenLink = { h.onOpenLink(it) },
                        onOpenApp = { h.onOpenApp() },
                        appHint = { h.appHint(it) },
                        onLaunchApp = { h.onLaunchApp(it) },
                        onClose = { close(finishHost = true) }
                    )
                }
            }
        }

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm = manager
        view = cv
        params = lp
        owner = own
        manager.addView(cv, lp)
    }

    /** What a ComposeView needs around it when it is not inside an activity. */
    private class OverlayOwner : SavedStateRegistryOwner, ViewModelStoreOwner, OnBackPressedDispatcherOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()
        override val onBackPressedDispatcher = OnBackPressedDispatcher()

        init {
            controller.performRestore(null)
            registry.currentState = Lifecycle.State.RESUMED
        }

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = store

        fun destroy() {
            registry.currentState = Lifecycle.State.DESTROYED
            store.clear()
        }
    }
}
