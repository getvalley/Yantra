package `in`.yantra.assistant.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.yantra.assistant.ChatMsg

// Phrased the way people talk, so the examples teach what works.
private val SUGGESTIONS = listOf(
    "turn the flashlight on",
    "make the screen a bit dimmer",
    "set a timer for ten minutes",
    "who is the prime minister of india",
    "call mom",
    "what's on my calendar",
    "battery"
)

/**
 * The main screen, in the language of the summon bubble: frosted glass over the orb's colours,
 * one orb as the microphone, and a "Search or Ask" bar for typing.
 *
 *   empty      a big breathing orb, a greeting, a few things to try
 *   talking    your lines as ember-tinted glass pills, Yantra's replies as glass panels
 *   listening  the same dark fade as the wake-up screen, with your words on it
 *
 * History (previous chats, saved on this phone) opens from the clock icon; the plus starts a new chat.
 */
@Composable
fun ChatScreen(
    messages: List<ChatMsg>,
    listening: Boolean,
    busy: Boolean,
    transcript: String = "",
    title: String,
    chatSaved: Boolean,
    chatPinned: Boolean,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onOpenDrawer: () -> Unit,
    onTogglePin: () -> Unit,
    onRenameChat: (String) -> Unit,
    onDeleteChat: () -> Unit
) {
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val colors = MaterialTheme.colorScheme
    val hero = messages.size <= 1
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    // scroll to the newest line when one arrives, or when another chat is opened
    LaunchedEffect(messages.size, messages.getOrNull(1)?.stamp, busy) {
        if (!hero) listState.animateScrollToItem(messages.size + if (busy) 1 else 0)
    }

    fun submit() {
        val t = input.trim()
        if (t.isNotEmpty()) {
            input = ""
            onSend(t)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        PaperBackdrop(Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            TopBar(
                title = title,
                chatSaved = chatSaved,
                chatPinned = chatPinned,
                onOpenDrawer = onOpenDrawer,
                onPin = onTogglePin,
                onRename = { renaming = true },
                onDelete = { deleting = true }
            )

            if (hero) {
                Hero(
                    listening = listening || busy,
                    onSend = onSend,
                    modifier = Modifier.weight(1f)
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Spacer(Modifier.height(4.dp)) }
                    items(messages.drop(1)) { msg -> Message(msg) }
                    if (busy) item { WorkingMessage() }
                    item { Spacer(Modifier.height(4.dp)) }
                }
            }

            // ---------------------------------------------------- the bar: Search or Ask, orb on the right
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .height(BarHeight)
                    .plate(Squircle(BarHeight / 2)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 26.dp, end = 8.dp),
                    singleLine = true,
                    textStyle = TextStyle(
                        color = colors.onBackground,
                        fontFamily = AppFont,
                        fontWeight = FontWeight.Medium,
                        fontSize = 18.sp
                    ),
                    cursorBrush = SolidColor(colors.primary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { submit() }),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (input.isEmpty()) {
                                Text(
                                    text = "Search or Ask",
                                    color = colors.onBackground.copy(alpha = 0.5f),
                                    fontFamily = AppFont,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 18.sp
                                )
                            }
                            inner()
                        }
                    }
                )
                if (input.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(Squircle(100.dp))
                            .background(colors.primary)
                            .clickable { submit() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowUpward,
                            contentDescription = "Send",
                            tint = colors.onPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(Modifier.width(6.dp))
                }
                // the orb is the microphone
                Box(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .size(52.dp)
                        .clip(Squircle(100.dp))
                        .semantics { contentDescription = "Microphone" }
                        .clickable { onMic() },
                    contentAlignment = Alignment.Center
                ) {
                    YantraOrb(listening = listening || busy, size = 52.dp, glow = false)
                }
            }
        }

        if (listening) ListeningOverlay(transcript = transcript, onStop = onMic)
        if (renaming) RenameChatDialog(
            current = title,
            onDismiss = { renaming = false },
            onSave = { renaming = false; onRenameChat(it) }
        )
        if (deleting) DeleteChatDialog(
            title = title,
            onDismiss = { deleting = false },
            onDelete = { deleting = false; onDeleteChat() }
        )
    }
}

// ----------------------------------------------------------------- pieces

/**
 * Three things and nothing else: the menu button (two lines, the lower one shorter) on the left, the
 * name of the chat in the middle (no timer or status here: the answer area says "Working"), and the chat's own menu (three dots) on the right. App settings,
 * new chat and history live in the menu that slides out from the left.
 */
@Composable
private fun TopBar(
    title: String,
    chatSaved: Boolean,
    chatPinned: Boolean,
    onOpenDrawer: () -> Unit,
    onPin: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .plate(Squircle(100.dp))
                .clickable(onClick = onOpenDrawer)
                .semantics { contentDescription = "Menu" },
            contentAlignment = Alignment.Center
        ) { MenuLinesIcon() }

        Column(
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = colors.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Box {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .plate(Squircle(100.dp))
                    .clickable { menuOpen = true }
                    .semantics { contentDescription = "Chat settings" },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = null,
                    tint = colors.onBackground.copy(alpha = 0.78f),
                    modifier = Modifier.size(22.dp)
                )
            }
            if (menuOpen) {
                ChatMenu(
                    saved = chatSaved,
                    pinned = chatPinned,
                    onDismiss = { menuOpen = false },
                    onRename = { menuOpen = false; onRename() },
                    onPin = { menuOpen = false; onPin() },
                    onDelete = { menuOpen = false; onDelete() }
                )
            }
        }
    }
}

@Composable
internal fun IconAction(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(Squircle(100.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.72f),
            modifier = Modifier.size(21.dp)
        )
    }
}

@Composable
private fun Hero(
    listening: Boolean,
    onSend: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = MaterialTheme.colorScheme
    // centred when it fits, scrolls when it does not (small phones, big fonts)
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                YantraOrb(listening = listening, size = 176.dp, fps = 60)
            }
            Spacer(Modifier.height(20.dp))
            Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                Text(
                    text = "Ask for\nanything.",
                    style = MaterialTheme.typography.displayLarge,
                    color = colors.onBackground
                )
            }
            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SUGGESTIONS.forEach { s ->
                    Text(
                        text = s,
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.onSurface,
                        modifier = Modifier
                            .plate(Squircle(100.dp))
                            .clickable { onSend(s) }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }
}

/**
 * One radius for every chat line. A line one row tall is a full pill with squircle ends; taller ones
 * keep the same corner, so a long answer is a squircle card instead of a fat pill.
 */
private val CHAT_RADIUS = 36.dp

/** Stands where the answer will appear while Yantra works: orange and grey sliding through the word. */
@Composable
private fun WorkingMessage() {
    val transition = rememberInfiniteTransition(label = "working")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 720f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "shift"
    )
    val grey = if (isDarkScheme()) Color(0xFF8A8A8A) else Color(0xFFA6A6A6)
    val brush = Brush.linearGradient(
        colors = listOf(grey, Ember, grey),
        start = Offset(shift, 0f),
        end = Offset(shift + 360f, 0f),
        tileMode = TileMode.Mirror
    )
    Text(
        text = "Working",
        style = MaterialTheme.typography.headlineMedium.copy(brush = brush),
        modifier = Modifier
            .fillMaxWidth()
            .plate(Squircle(CHAT_RADIUS), border = false)
            .padding(horizontal = 22.dp, vertical = 18.dp)
            .semantics { contentDescription = "Working" }
    )
}

/**
 * Your lines are ember-tinted glass pills on the right. Yantra's replies are glass panels, like the
 * answer panel the bubble turns into: large type when short, and a source card for looked-up answers.
 */
@Composable
private fun Message(msg: ChatMsg) {
    val colors = MaterialTheme.colorScheme
    val dark = isDarkScheme()
    if (msg.fromUser) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text(
                text = msg.text,
                style = MaterialTheme.typography.bodyLarge,
                color = colors.onBackground,
                modifier = Modifier
                    .padding(start = 56.dp)
                    .plate(
                        Squircle(CHAT_RADIUS),
                        tint = Ember.copy(alpha = if (dark) 0.20f else 0.10f),
                        border = false
                    )
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            )
        }
    } else {
        val short = msg.text.length <= 72 && !msg.text.contains('\n')
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .plate(Squircle(CHAT_RADIUS), border = false)
                .padding(start = 22.dp, end = 22.dp, top = 18.dp, bottom = if (msg.link.isNotEmpty()) 14.dp else 18.dp)
        ) {
            Text(
                text = msg.text,
                style = if (short) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.bodyLarge,
                color = colors.onBackground
            )
            if (msg.link.isNotEmpty()) SourceCard(source = msg.source, link = msg.link)
        }
    }
}

/** The same result card the bubble shows: the source's initial, its name, and "Tap to read more". */
@Composable
private fun SourceCard(source: String, link: String) {
    val colors = MaterialTheme.colorScheme
    val dark = isDarkScheme()
    val context = LocalContext.current
    val title = source.ifBlank { "Open link" }
    Row(
        modifier = Modifier
            .padding(top = 14.dp)
            .fillMaxWidth()
            .plate(Squircle(22.dp), strong = true, border = false)
            .clickable {
                try {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) { /* no browser */ }
            }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(Squircle(100.dp))
                .background(colors.surface)
                .border(1.dp, if (dark) PlateBorderDark else PlateBorderLight, Squircle(100.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title.first().uppercase(),
                color = colors.onBackground,
                fontFamily = AppFont,
                fontWeight = FontWeight.Medium,
                fontSize = 17.sp
            )
        }
        Column(modifier = Modifier.padding(start = 12.dp)) {
            Text(
                text = title,
                color = colors.onBackground,
                fontFamily = AppFont,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Tap to read more",
                color = colors.onBackground.copy(alpha = 0.6f),
                fontFamily = AppFont,
                fontSize = 14.sp
            )
        }
    }
}

/** The wake-up screen's dark fade, with your words on it. Always dark, like the original. */
@Composable
private fun ListeningOverlay(transcript: String, onStop: () -> Unit) {
    val noRipple = remember { MutableInteractionSource() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0.00f to Color.Black.copy(alpha = 0.62f),
                    0.50f to Color.Black.copy(alpha = 0.86f),
                    0.78f to Color.Black
                )
            )
            .clickable(interactionSource = noRipple, indication = null) { onStop() }
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 18.dp)
        ) {
            Text(
                text = transcript.ifEmpty { "Listening\u2026" },
                style = MaterialTheme.typography.headlineMedium,
                color = if (transcript.isEmpty()) Color.White.copy(alpha = 0.62f) else Color.White,
                maxLines = 5,
                modifier = Modifier.padding(horizontal = 28.dp)
            )
            Spacer(Modifier.height(32.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 26.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(Modifier.size(52.dp))
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    YantraOrb(listening = true, size = 104.dp, fps = 60)
                }
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(Squircle(100.dp))
                        .clickable { onStop() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Stop listening",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}
