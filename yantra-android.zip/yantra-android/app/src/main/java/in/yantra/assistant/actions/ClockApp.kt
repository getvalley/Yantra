package `in`.yantra.assistant.actions

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock

/**
 * Hands alarms and timers to whatever Clock app the phone uses (Google Clock,
 * Samsung Clock, OnePlus Clock...). Android's [AlarmClock] intents are the
 * standard way to do it, so the alarm rings and the timer counts down in the
 * Clock app itself, even when Yantra is closed.
 *
 * Every function returns false when no Clock app answers, so the caller can
 * fall back to Yantra's own alarm.
 */
object ClockApp {

    /** Longest timer the AlarmClock hand-off allows: 24 hours. */
    const val MAX_TIMER_SECONDS = 24 * 60 * 60

    /** Starts a timer. [seconds] is clamped to 1 second .. 24 hours. */
    fun setTimer(ctx: Context, seconds: Int, label: String?): Boolean {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceIn(1, MAX_TIMER_SECONDS))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (!label.isNullOrBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, label.trim())
        return start(ctx, intent)
    }

    /** Creates an alarm for the next time the clock reads [hour]:[minute]. */
    fun setAlarm(ctx: Context, hour: Int, minute: Int, label: String?): Boolean {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (!label.isNullOrBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, label.trim())
        return start(ctx, intent)
    }

    fun showAlarms(ctx: Context): Boolean = start(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS))

    fun showTimers(ctx: Context): Boolean = start(ctx, Intent(AlarmClock.ACTION_SHOW_TIMERS))

    /** The Clock app's name for the picker ("Clock"), or null when there is none. */
    fun appName(ctx: Context): String? {
        val pm = ctx.packageManager
        val info = try {
            pm.resolveActivity(Intent(AlarmClock.ACTION_SET_TIMER), 0)
                ?: pm.resolveActivity(Intent(AlarmClock.ACTION_SET_ALARM), 0)
        } catch (e: Exception) {
            null
        } ?: return null
        return info.loadLabel(pm).toString().takeIf { it.isNotBlank() }
    }

    private fun start(ctx: Context, intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            if (intent.resolveActivity(ctx.packageManager) == null) return false
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            // no Clock app, or it refused (ActivityNotFound, Security)
            false
        }
    }
}
