package `in`.yantra.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp

/*
 * Every box, bar and pill in the app is a plate: a solid fill, a 1dp grey border and a shadow so
 * small you feel it more than see it. No blur, no translucency, no gradients on the rim. The only
 * glass left is the summon bubble itself, which is the signature and stays a shader.
 */

@Composable
internal fun isDarkScheme(): Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f

/** The 1dp grey that outlines every plate. */
internal val PlateBorderLight = Color(0xFFE2E2E2)
internal val PlateBorderDark = Color(0xFF2C2C2C)

/**
 * A plate in [shape]. [tint] washes it with a colour (your messages use a little orange);
 * [strong] sits it one step darker, for a card on top of another plate. [border] = false drops the
 * 1dp line (chat lines have none; the faint shadow lifts them off the page).
 */
@Composable
internal fun Modifier.plate(
    shape: Shape,
    tint: Color = Color.Transparent,
    strong: Boolean = false,
    border: Boolean = true
): Modifier {
    val dark = isDarkScheme()
    val colors = MaterialTheme.colorScheme
    val fill = if (strong) colors.surfaceVariant else colors.surface
    return this
        .shadow(
            elevation = 3.dp,
            shape = shape,
            clip = false,
            ambientColor = Color.Black.copy(alpha = if (dark) 0.5f else 0.08f),
            spotColor = Color.Black.copy(alpha = if (dark) 0.5f else 0.10f)
        )
        .clip(shape)
        .background(fill)
        .background(tint)
        .then(if (border) Modifier.border(1.dp, if (dark) PlateBorderDark else PlateBorderLight, shape) else Modifier)
}

/** The ground the plates sit on: plain white, or plain black. */
@Composable
internal fun PaperBackdrop(modifier: Modifier = Modifier) {
    Box(modifier = modifier.background(MaterialTheme.colorScheme.background))
}

/** How tall the bars are. */
internal val BarHeight = 56.dp
